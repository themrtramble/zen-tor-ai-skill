# Zentor Skills Pack

Total skills: **22**

Yeh pack Zentor ke saare installed skills ka full snapshot hai — har skill ka `SKILL.md`, references, scripts aur templates included hain.

## Skills

| # | Folder | Skill name | Files | Size |
|---|--------|-----------|-------|------|
| 1 | `airtable` | airtable | 3 | 3 KB |
| 2 | `camoufox-cli` | camoufox-cli | 5 | 30 KB |
| 3 | `deep-research` | deep-research | 3 | 8 KB |
| 4 | `discord` | discord | 3 | 5 KB |
| 5 | `github` | github | 3 | 8 KB |
| 6 | `google_calendar` | google_calendar | 3 | 5 KB |
| 7 | `google_drive` | google_drive | 3 | 5 KB |
| 8 | `google_gmail` | google_gmail | 3 | 3 KB |
| 9 | `google_tasks` | google_tasks | 3 | 4 KB |
| 10 | `linear` | linear | 3 | 9 KB |
| 11 | `mcp-hub` | mcp-hub | 3 | 3 KB |
| 12 | `notion` | notion | 3 | 3 KB |
| 13 | `outlook` | outlook | 3 | 6 KB |
| 14 | `planning-with-files` | planning-with-files | 14 | 57 KB |
| 15 | `posthog` | posthog | 3 | 4 KB |
| 16 | `pptx` | pptx | 32 | 109 KB |
| 17 | `pptx-native` | pptx-native | 47 | 412 KB |
| 18 | `remotion` | remotion-best-practices | 43 | 113 KB |
| 19 | `sentry` | sentry | 3 | 3 KB |
| 20 | `slack-api` | slack-api | 3 | 4 KB |
| 21 | `video-frames` | video-frames | 4 | 3 KB |
| 22 | `zentor-document` | zentor-document | 3 | 2 KB |

## Descriptions

### airtable
- **name:** `airtable`
- **description:** Use this connector skill whenever the user asks an agent to find Airtable bases, inspect table schemas, search or read records, or create and update records through the official Airtable MCP server.

### camoufox-cli
- **name:** `camoufox-cli`
- **description:** Anti-detect browser automation CLI & Skills for AI agents. Use when the user needs to interact with websites with bot detection, CAPTCHAs, or anti-bot blocks, including navigating pages, filling forms, clicking buttons, taking screenshots, extracting data, testing web apps, or automating any browser task that requires bypassing fingerprint checks.

### deep-research
- **name:** `deep-research`
- **description:** "Iterative deep research for competitive analysis, trend tracking, phenomenon investigation, and multi-source intelligence synthesis. Trigger when the task involves understanding root causes, tracing how something evolved, comparing alternatives, or producing a well-sourced research report."

### discord
- **name:** `discord`
- **description:** Use this connector skill when the user asks to inspect an authorized Discord server, channel, or bounded message history through the Discord Provider Connector. Do not use it merely because the user is chatting through the Discord IM channel.

### github
- **name:** `github`
- **description:** Use this connector skill whenever the user asks an agent to work with GitHub repositories, issues, pull requests, code review, CI failures, release branches, or repo maintenance through the Moclaw connector. Use it for GitHub workflows that need to inspect repository state, create or update issues and PRs, review changes, or summarize CI and review status.

### google_calendar
- **name:** `google_calendar`
- **description:** Use this connector skill whenever the user asks to check their schedule, look up or search calendar events, or create, move, or cancel an event on Google Calendar.

### google_drive
- **name:** `google_drive`
- **description:** Use this connector skill whenever the user asks to find a file in Google Drive, read or write a Google Doc, read or write a Google Sheet, create a new document or spreadsheet, or delete one.

### google_gmail
- **name:** `google_gmail`
- **description:** Use this connector skill whenever the user asks to search, read, or draft Gmail email.

### google_tasks
- **name:** `google_tasks`
- **description:** Use this connector skill whenever the user asks what is on their to-do list, wants to add a task, mark one done, or change a task's title or due date in Google Tasks.

### linear
- **name:** `linear`
- **description:** Use this connector skill whenever the user asks an agent to work with Linear issues, teams, projects, cycles, workflow states, labels, comments, assignments, or engineering planning through the Moclaw connector. Use it for Linear workflows that need to inspect assigned work, create or update issues, connect code changes to Linear tickets, or summarize project execution status.

### mcp-hub
- **name:** `mcp-hub`
- **description:** Use `connector-cli mcp` to discover and call user-configured remote MCP servers through the server-side proxy. Use when the user asks for data or actions that may be provided by their connected MCP servers.

### notion
- **name:** `notion`
- **description:** Use this connector skill whenever the user asks an agent to work with Notion pages, shared page content, block trees, notes, docs, or page creation through the official Notion MCP server.

### outlook
- **name:** `outlook`
- **description:** Use this connector skill whenever the user asks an agent to search, read, triage, draft, send, reply to, or forward Outlook email, work with message attachments, or manage Outlook calendars and meetings through the Moclaw connector.

### planning-with-files
- **name:** `planning-with-files`
- **description:** Implements Manus-style file-based planning to organize and track progress on complex tasks. Creates planning files under .claude/planning/ by default instead of the project root. Use when asked to plan out, break down, or organize a multi-step project, research task, or any work requiring >5 tool calls. Supports automatic session recovery after /clear. user-invocable: true allowed-tools: "Read, Write, Edit, Bash, Glob, Grep"

### posthog
- **name:** `posthog`
- **description:** Use this connector skill whenever the user asks an agent to analyze or manage PostHog product analytics, feature flags, experiments, dashboards, surveys, data pipelines, AI observability, error tracking, or logs.

### pptx
- **name:** `pptx`
- **description:** | Create intentionally raster or image-backed slide decks with GPT Image 2, then package the generated slide images into a PPTX and HTML viewer. This is an opt-in image mode: use it only when the user explicitly asks for the output to be image-mode, raster, flattened, full-slide-image, or GPT Image slides; explicitly asks to keep an existing image-backed deck image-backed; or asks to package slide images as PowerPoint. Do not infer image mode merely because the input is screenshots, exported slides, an image directory, or a flattened PPTX. Do not use this skill for a generic request to create, read, inspect, edit, restyle, or export a PPT, PPTX, PowerPoint presentation, or slide deck. When the user does not explicitly request image-backed output, use pptx-native by default, even if they do not mention editability; pptx-native also owns reconstruction of image inputs into native slides. Trigger phrases: image-mode PPT, raster PPT output, keep this deck flattened, full-slide-image output, generate slide images, GPT Image slides, keep these rendered slides image-backed, edit a slide image as an image, package images as PowerPoint.

### pptx-native
- **name:** `pptx-native`
- **description:** >- The default PowerPoint skill. Use when the user asks to create, read, inspect, render, edit, restyle, reconstruct, or export a PPT, PPTX, PowerPoint presentation, or slide deck. Image input does not automatically require image output.

### remotion
- **name:** `remotion-best-practices`
- **description:** Best practices for Remotion - Video creation in React

### sentry
- **name:** `sentry`
- **description:** Use this connector skill whenever the user asks an agent to work with Sentry organizations, projects, issues, error triage, exception investigation, issue status changes, or production incident summaries.

### slack-api
- **name:** `slack-api`
- **description:** Use for bounded Slack conversation, message, user, reaction, schedule, and file tasks through the fixed Slack Web API Broker actions.

### video-frames
- **name:** `video-frames`
- **description:** Extract frames or short clips from videos using ffmpeg.

### zentor-document
- **name:** `zentor-document`
- **description:** Read uploaded PDF, DOCX, PPTX, and XLSX files inside the Sandbox. Use this skill whenever a user asks to inspect or extract content from one of these files.

## Structure

```
zentor-skills-pack/
├── README.md
├── manifest.json
├── SKILLS.md (this file)
└── skills/
    ├── airtable/
    ├── camoufox-cli/
    ├── deep-research/
    ├── discord/
    ├── github/
    ├── google_calendar/
    ├── google_drive/
    ├── google_gmail/
    ├── google_tasks/
    ├── linear/
    ├── mcp-hub/
    ├── notion/
    ├── outlook/
    ├── planning-with-files/
    ├── posthog/
    ├── pptx/
    ├── pptx-native/
    ├── remotion/
    ├── sentry/
    ├── slack-api/
    ├── video-frames/
    ├── zentor-document/
```

## Usage

Kisi bhi skill ko use karne ke liye uska `SKILL.md` parhain — usme exact commands, scripts ke paths aur workflows likhe hain.
Path references `SKILL.md` ke folder ke relative hain (e.g. `scripts/foo.sh` = `<skill>/scripts/foo.sh`).
