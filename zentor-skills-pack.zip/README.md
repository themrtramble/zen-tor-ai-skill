# Zentor Skills Pack

Zentor ke saare installed skills ka complete snapshot (22 skills, 234 files).

## Andar kya hai

| File | Kya hai |
|------|---------|
| `SKILLS.md` | Saari skills ki list + descriptions + structure |
| `manifest.json` | Machine-readable index (name, description, file count, size) |
| `skills/<skill-name>/SKILL.md` | Us skill ki main instruction file |
| `skills/<skill-name>/...` | References, scripts, templates, assets |

## Quick start

```bash
unzip zentor-skills-pack.zip
cat zentor-skills-pack/SKILLS.md      # index parhain
cat zentor-skills-pack/skills/github/SKILL.md   # ek skill parhain
```

Kisi bhi skill ka `SKILL.md` uske folder ka root hai — andar diye gaye relative
paths (jaise `scripts/foo.py`) usi skill folder ke andar resolve hote hain.

## Skills overview

Connectors: airtable, discord, github, google_calendar, google_drive, google_gmail,
google_tasks, linear, mcp-hub, notion, outlook, posthog, sentry, slack-api

Documents & media: pptx, pptx-native, remotion (video), video-frames, zentor-document

Research & workflow: deep-research, planning-with-files, camoufox-cli (anti-detect browser)
