import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import ppt

from ppt_skill.deck import Deck
from ppt_skill.pack import to_html, to_pptx
from PIL import Image
from pptx import Presentation


class DeckPackagingTest(unittest.TestCase):
    def test_tool_images_are_ordered_and_keep_speaker_notes(self):
        with tempfile.TemporaryDirectory() as tmp:
            deck = Deck("demo", root=Path(tmp))
            deck.root.mkdir()
            for slot in (10, 2, 1):
                Image.effect_noise((640, 360), 100).convert("RGB").save(deck.slide_path(slot))
            deck.prompt_path(2).parent.mkdir()
            deck.prompt_path(2).write_text("Slide 2 prompt", encoding="utf-8")
            self.assertEqual(deck.existing_slots(), [1, 2, 10])
            self.assertEqual(deck.slide_files(), [deck.slide_path(n) for n in (1, 2, 10)])
            self.assertEqual(deck.load_slot_notes(), {2: "Slide 2 prompt"})
            to_pptx(deck.slide_files(), deck.pptx_path(), notes=deck.load_slot_notes())
            slides = Presentation(deck.pptx_path()).slides
            self.assertEqual(len(slides), 3)
            self.assertEqual(slides[1].notes_slide.notes_text_frame.text, "Slide 2 prompt")
            for slide, slot in zip(slides, (1, 2, 10)):
                self.assertEqual(slide.shapes[0].image.blob, deck.slide_path(slot).read_bytes())
            to_html(deck.slide_files(), deck.html_path(), "Demo")
            html = deck.html_path().read_text()
            self.assertIn('["slide-01.png", "slide-02.png", "slide-10.png"]', html)


class DeckCheckTest(unittest.TestCase):
    def test_check_requires_complete_images_and_notes(self):
        for problem in (None, "missing", "extra", "corrupt", "missing_note", "empty_note", "invalid_count"):
            with self.subTest(problem=problem), tempfile.TemporaryDirectory() as tmp:
                deck = Deck("demo", root=Path(tmp))
                deck.root.mkdir()
                Image.effect_noise((640, 360), 100).convert("RGB").save(deck.slide_path(1))
                deck.prompt_path(1).parent.mkdir()
                deck.prompt_path(1).write_text("Full slide prompt", encoding="utf-8")
                if problem == "missing":
                    deck.slide_path(1).unlink()
                elif problem == "extra":
                    deck.slide_path(2).write_bytes(deck.slide_path(1).read_bytes())
                elif problem == "corrupt":
                    deck.slide_path(1).write_bytes(b"invalid image")
                elif problem == "missing_note":
                    deck.prompt_path(1).unlink()
                elif problem == "empty_note":
                    deck.prompt_path(1).write_text("  ", encoding="utf-8")
                args = ppt.build_parser().parse_args(["check", "demo", "--slides", "0" if problem == "invalid_count" else "1"])
                with patch.object(ppt, "Deck", return_value=deck):
                    if problem:
                        with self.assertRaisesRegex(SystemExit, "Check failed"):
                            args.func(args)
                    else:
                        args.func(args)


if __name__ == "__main__":
    unittest.main()
