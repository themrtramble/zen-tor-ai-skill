# GPT Image 2 PPT Skill

Generate PPT slide images via **GPT Image 2** through the Moclaw AI Gateway, focused on typographic quality. Agent image tools with a deck-driven packaging CLI.

## Design Philosophy

**Provide atomic commands; let the AI decide how to compose them.**

- `GenerateImage` / `EditImage` — Agent tools that call the AI Gateway to generate / edit images
- `pack` — locally bundle images into `.pptx` and `index.html`

No hardcoded "mode A / B / C" workflow — Claude decides per-slide based on context.

## Core Concept: deck

**A deck = one directory under `/home/user/.workspace/outputs/`**.
- Set each image call's `output_path` to an explicitly numbered file such as `slide-01.png`, `slide-02.png`, ...
- Save each slide's prompt and parameters in `prompts/slide-NN.md` for speaker notes; existing `deck.json` metadata remains readable
- The `pack` command produces a shareable `.pptx` and `index.html`

## Quick Start

```bash
# 1. Install dependencies
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
# requirements.txt pins python-pptx to the Maxgent fork commit containing the
# Keynote speaker-notes package compatibility fix.

```

Image generation uses the Agent Session's credentials; the CLI needs no `.env`.
Call the following Agent tools directly, not through the shell. Style is written into the prompt.

```text
# 3. Generate the first slide and wait for success
GenerateImage({"prompt": "Editorial magazine cover, huge serif title 'Q1 Product Review', off-white bg, thin hairline divider, small sans-serif subtitle '2026 · Product Team'. Crisp exact typography.", "aspect_ratio": "16:9", "quality": "high", "n": 1, "output_path": "outputs/q1-demo/slide-01.png"})

# 4. Subsequent slides reference slide 1 as the master; these two calls can run concurrently
EditImage({"prompt": "Keep layout identical. REPLACE title WITH: 'Key Results'. REPLACE subtitle WITH: 'Users +32% · Retention 78% · NPS 62'.", "input_paths": ["outputs/q1-demo/slide-01.png"], "quality": "high", "n": 1, "output_path": "outputs/q1-demo/slide-02.png"})
EditImage({"prompt": "Keep layout identical. REPLACE title WITH: 'Thank you'. REPLACE subtitle WITH: 'See you in Q2'.", "input_paths": ["outputs/q1-demo/slide-01.png"], "quality": "high", "n": 1, "output_path": "outputs/q1-demo/slide-03.png"})
```

Wait for both calls, then save each slide's prompt and parameters to `outputs/q1-demo/prompts/slide-NN.md`.
For larger decks, use batches of 2–3 independent calls and wait for each batch before starting the next.

```bash
# 5. Check status
.venv/bin/python ppt.py info q1-demo

# 6. Validate against the planned slide count, then pack only if the check passes
.venv/bin/python ppt.py check q1-demo --slides 3
.venv/bin/python ppt.py pack q1-demo
# → /home/user/.workspace/outputs/q1-demo/deck.pptx     (open in Keynote / PowerPoint)
# → /home/user/.workspace/outputs/q1-demo/index.html    (keyboard ← → navigation player)
open /home/user/.workspace/outputs/q1-demo/index.html
```

## Tools and Commands

| Command | Purpose | Example |
|------|------|------|
| `GenerateImage` | Text-to-image | Set `output_path="outputs/my/slide-01.png"`, `n=1` |
| `EditImage` | Image-to-image | Set `input_paths` and the target `output_path`, `n=1` |
| `pack <deck>` | Bundle into .pptx + .html | `ppt pack my` |
| `info <deck>` | Show deck status | `ppt info my` |
| `check <deck> --slides N` | Validate page numbers, PNGs, and prompt notes | `ppt check my --slides 3` |

### Model choice and timeout

Both image tools use GPT Image 2. Follow their schemas and timeout behavior;
do not pass CLI flags or assume a failed request can be resumed without another charge.

### `input_paths` for `EditImage`

Pass Workspace image paths, such as `outputs/mydeck/slide-01.png` or a local brand image.
Multiple references can be supplied in the array. Use the actual file path, not a slot number or remote URL.

### Refining a single slide

Call `EditImage` with `prompt="Change title to 'XX'."`,
`input_paths=["outputs/mydeck/slide-03.png"]`, `n=1`, and
`output_path="outputs/mydeck/slide-03.png"` to overwrite slide 3 after generation.
Update its prompt notes, run `ppt check mydeck --slides N` with the planned count, then `ppt pack mydeck`.

## Use as a skill

This ships as a kernel skill and is auto-discovered by the runtime — no install or symlink step is needed.

If you ever copy it into a workspace as a user skill, place it at `/home/user/.workspace/skills/<name>/`.

Then ask the agent to plan according to `SKILL.md` and invoke the image tools and packaging CLI.

## Project Structure

```
pptx/
├── ppt.py                    # CLI entrypoint
├── ppt_skill/                # core package
│   ├── deck.py               #   Deck class
│   └── pack.py               #   to_pptx / to_html
├── templates/viewer.html     # HTML player
├── style_refs/               # style reference samples (for inspiration, not a fixed menu)
└── requirements.txt
```

Generated decks are written outside the skill tree under
`/home/user/.workspace/outputs/<deck>/`.

## About Sizes

Use `aspect_ratio="16:9"` for slides. Pixel dimensions are determined by the image tool;
arbitrary sizes and 4K output are not guaranteed. The `output_path` extension must match the returned image format.

## Pricing Reference

Image generation is billed through the AI Gateway using the Agent Session's credentials.
See the [gateway image API contract](../../../apps/ai-gateway/docs/api-integration.zh.md#5-gpt-image-2openrouter-image-api)
for current billing behavior. Use `quality=high` for typography; switch to `medium`/`low` when precision is less critical.

For explicitly named slide files, use `n=1` on every call.
