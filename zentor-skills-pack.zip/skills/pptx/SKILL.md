---
name: pptx
description: |
  Create intentionally raster or image-backed slide decks with GPT Image 2, then package the generated slide images into a PPTX and HTML viewer. This is an opt-in image mode: use it only when the user explicitly asks for the output to be image-mode, raster, flattened, full-slide-image, or GPT Image slides; explicitly asks to keep an existing image-backed deck image-backed; or asks to package slide images as PowerPoint. Do not infer image mode merely because the input is screenshots, exported slides, an image directory, or a flattened PPTX. Do not use this skill for a generic request to create, read, inspect, edit, restyle, or export a PPT, PPTX, PowerPoint presentation, or slide deck. When the user does not explicitly request image-backed output, use pptx-native by default, even if they do not mention editability; pptx-native also owns reconstruction of image inputs into native slides.
  Trigger phrases: image-mode PPT, raster PPT output, keep this deck flattened, full-slide-image output, generate slide images, GPT Image slides, keep these rendered slides image-backed, edit a slide image as an image, package images as PowerPoint.
---

# GPT Image 2 PPT Skill

Uses GPT Image 2 (via the Moclaw AI Gateway) to generate PPT slide images. GPT Image 2 excels at precise text rendering, making it ideal for presentations that require accurate typography in any language.

## Opt-in routing

This skill is not the default PowerPoint workflow. Use it only when the user
explicitly chooses raster or image-backed output, including an explicit request
to keep an existing image-backed deck in that mode. The input format alone does
not opt in. A generic request such as “make a PPT”, “create a presentation”,
“edit this deck”, or “restyle these slides” routes to `pptx-native`. Ambiguity
also routes to `pptx-native`; the absence of an editability requirement is not
permission to flatten the deck.

---

## Image Generation and Packaging

Call the Agent tools directly (not shell commands):

- `GenerateImage` — text-to-image; pass the complete `prompt`, `aspect_ratio="16:9"`, `quality="high"`, and `n=1`.
- `EditImage` — image-to-image; pass `input_paths` referencing Workspace images and `n=1`.

Set `output_path="outputs/<deck>/slide-NN.png"` on every call to write directly to the intended slide.
Use a distinct path for each concurrent call. To edit in place, use the same input and output path.
Follow the tool schema; do not pass `size`, `output_format`, `model`, or `mask`.
If the tools are unavailable, report the blocker rather than sending HTTP requests yourself.

```bash
ppt pack <deck> [--title "Title"]
ppt info <deck>
ppt check <deck> --slides N
```

- `pack` — packages into deck.pptx + index.html
- `info` — view deck status
- `check` — checks consecutive slide numbers, valid PNGs, and nonempty prompt notes against the expected slide count

Save each slide's full prompt and parameters to `outputs/<deck>/prompts/slide-NN.md` for speaker notes.
Run `check` before `pack`; fix failures and rerun it before packaging.
Reference slides run first; remaining slides run in batches of 2–3 with a wait between batches (see workflow.md).
A failed image call cannot be assumed to resume on retry or avoid another charge.

Output directory: `/home/user/.workspace/outputs/<deck>/`, with explicitly numbered `slide-01.png`, `slide-02.png`, …

---

## Size Constraints

Use `aspect_ratio="16:9"` for slides. Pixel dimensions are determined by the image tool;
arbitrary sizes and 4K output are not guaranteed. The output file extension must match the returned image format.

---

## Rules Index

| File | Content | When to read |
|------|---------|-------------|
| [rules/workflow.md](rules/workflow.md) | 6-phase process, deck_spec format, batched concurrent generation | Before starting any task |
| [rules/prompt-guide.md](rules/prompt-guide.md) | Seven-section structure, language handling, font rules, full examples | When writing prompts |
| [rules/style-guide.md](rules/style-guide.md) | Style judgment, STYLE+COLOR templates, gen vs edit | When planning visual style |
| [rules/visual-types.md](rules/visual-types.md) | Design layers (charts / diagrams / illustrations / backgrounds / decorations) | When planning each slide's visual content |
| [rules/modify-scenarios.md](rules/modify-scenarios.md) | Edit page / insert page / delete page / reorder / restyle | When modifying an existing deck |

---

## Environment

Image generation uses the Agent Session's AI Gateway credentials through `GenerateImage` and `EditImage`.
The local packaging CLI does not need tokens or `.env`.

```bash
pip install -r requirements.txt   # python-pptx
```

`requirements.txt` pins `python-pptx` to the Maxgent fork commit that includes
the Keynote speaker-notes package compatibility fix.

---

## Project Structure

```
├── ppt.py                  # Local pack / info / check CLI
├── ppt_skill/
│   ├── deck.py             # Read slide order, metadata, and prompt notes
│   └── pack.py             # to_pptx (PNG validation + speaker notes) / to_html
├── rules/                  # AI execution rules
│   ├── workflow.md
│   ├── prompt-guide.md
│   ├── style-guide.md
│   ├── visual-types.md
│   └── modify-scenarios.md
├── style_refs/             # 14 style samples (for reference, not templates)
└── templates/viewer.html   # HTML viewer template
```

Generated content is written under `/home/user/.workspace/outputs/<deck>/`:

```
├── deck.json           # Optional existing metadata
├── slide-NN.png
├── prompts/slide-NN.md # Full prompt per slide (also used as speaker notes)
├── deck.pptx
└── index.html
```
