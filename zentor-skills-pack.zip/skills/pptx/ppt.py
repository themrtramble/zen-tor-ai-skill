#!/usr/bin/env python3
"""Package Workspace slide images. Image generation is owned by Agent tools.

Usage:
  ppt pack <deck> [--title T]
  ppt info <deck>
  ppt check <deck> --slides N
"""

import argparse
import sys

from ppt_skill.deck import Deck
from ppt_skill import pack


def cmd_pack(args: argparse.Namespace) -> None:
    deck = Deck(args.deck)
    images = deck.slide_files()
    if not images:
        sys.exit(f"Error: deck '{deck.name}' has no slides (looked in {deck.root})")
    title = args.title or deck.name
    notes = deck.load_slot_notes()

    pack.to_pptx(images, deck.pptx_path(), notes=notes)
    pack.to_html(images, deck.html_path(), title=title)


def cmd_check(args: argparse.Namespace) -> None:
    from PIL import Image

    deck = Deck(args.deck)
    try:
        if args.slides < 1:
            raise ValueError("--slides must be positive")
        expected = [deck.slide_path(slot) for slot in range(1, args.slides + 1)]
        if deck.slide_files() != expected:
            raise ValueError(f"Expected exactly slide-01.png through slide-{args.slides:02d}.png; found {[p.name for p in deck.slide_files()]}")
        for slot, path in enumerate(expected, 1):
            pack._validate_png(path)
            with Image.open(path) as image:
                image.verify()
            note = deck.prompt_path(slot)
            if not note.is_file() or not note.read_text(encoding="utf-8").strip():
                raise ValueError(f"Missing or empty prompt notes: {note}")
    except (OSError, ValueError, SyntaxError) as exc:
        sys.exit(f"Check failed: {exc}")
    print(f"Check passed: {args.slides} slides with valid PNGs and prompt notes")


def cmd_info(args: argparse.Namespace) -> None:
    deck = Deck(args.deck)
    meta = deck.load_meta()
    slots = deck.existing_slots()
    print(f"deck: {deck.name}")
    print(f"  path: {deck.root}")
    print(f"  slides: {len(slots)} ({', '.join(f'{s:02d}' for s in slots) or '—'})")
    if meta:
        print(f"  size: {meta.get('size')}")
        print(f"  quality: {meta.get('quality')}")
        print(f"  history entries: {len(meta.get('history') or [])}")


# ---------------------------------------------------------------------- parser

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ppt",
        description="Package Workspace slide images into PPTX and HTML",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    k = sub.add_parser("pack", help="Assemble the deck into deck.pptx + index.html")
    k.add_argument("deck", help="Deck name")
    k.add_argument("--title", help="HTML title (default: deck name)")
    k.set_defaults(func=cmd_pack)

    c = sub.add_parser("check", help="Validate slide numbers, PNGs, and prompt notes before packaging")
    c.add_argument("deck", help="Deck name")
    c.add_argument("--slides", type=int, required=True, help="Expected slide count from the deck outline")
    c.set_defaults(func=cmd_check)

    i = sub.add_parser("info", help="Show deck contents and metadata")
    i.add_argument("deck", help="Deck name")
    i.set_defaults(func=cmd_info)

    return p


def main() -> None:
    args = build_parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
