# Modify Scenarios

Insert, delete, reorder, or restyle slides in an existing deck.

---

## Core Mechanism

`pack` assembles slides in `slide-NN.png` filename order. The CLI has no dedicated insert/delete/reorder commands — **directly manipulate files in `outputs/{deck}/`, then repack.**

After every modification, repack:

```bash
ppt pack {deck}
```

---

## Edit a Slide's Content

The most common scenario. Overwrite the same slot:

Call `EditImage` with:

```json
{"prompt": "{new prompt}", "input_paths": ["outputs/{deck}/slide-{NN}.png"], "output_path": "outputs/{deck}/slide-{NN}.png", "n": 1}
```

After success, update `prompts/slide-{NN}.md` and run `ppt pack {deck}`.

- Use the same path for `input_paths` and `output_path`: reference the slide itself and change only what's specified
- In the prompt, write `REPLACE ... with: "..."` and `Do not change anything else`
- Keep edit chains under 3 layers — beyond that, drift accumulates; use `GenerateImage` with the same `output_path` to regenerate from scratch

---

## Delete a Slide

```bash
rm outputs/{deck}/slide-{NN}.png
rm outputs/{deck}/prompts/slide-{NN}.md   # optional, keeps prompts/ clean
ppt pack {deck}
```

After deletion, the remaining numbers may not be contiguous (e.g., 01 02 04 05). `pack` assembles in existing file order — gaps don't affect sequence. Rename files to close the gap if needed, then repack.

---

## Insert a New Slide

**Append at the end**: use `GenerateImage` or `EditImage` with the next slot's `output_path`; pack will append it automatically.

**Insert in the middle** (e.g., between slide-02 and slide-03):
1. Shift slide-03 and later files back by one number (move matching `.md` files too)
2. Generate the new slide with `output_path="outputs/{deck}/slide-03.png"`
3. ppt pack

```bash
# Shift 03 04 05 back by one
for i in 05 04 03; do
  mv outputs/{deck}/slide-0${i}.png outputs/{deck}/slide-0$((i+1)).png
done
```

Call `GenerateImage` with `prompt="{new slide prompt}"`, `aspect_ratio="16:9"`,
`n=1`, and `output_path="outputs/{deck}/slide-03.png"`, then save its prompt notes and run `ppt pack {deck}`.

---

## Reorder Slides

Rename files directly; pack sorts by the new numbers:

```bash
# Example: swap slide-04 and slide-05
mv outputs/{deck}/slide-04.png outputs/{deck}/slide-04-tmp.png
mv outputs/{deck}/slide-05.png outputs/{deck}/slide-04.png
mv outputs/{deck}/slide-04-tmp.png outputs/{deck}/slide-05.png
ppt pack {deck}
```

---

## Restyle the Entire Deck

Switching the whole deck to a new visual language:

1. Regenerate slide-01 with a new STYLE + COLOR
2. Re-edit all other slides with `EditImage.input_paths=["outputs/{deck}/slide-01.png"]` to inherit the new style
3. ppt pack

Call `GenerateImage` with the new cover prompt, `aspect_ratio="16:9"`, `n=1`, and
`output_path="outputs/{deck}/slide-01.png"`. Wait for success.

Then call `EditImage` in batches of 2–3, referencing slide-01 and assigning each
slide its own `output_path`. Wait for each whole batch before starting the next
(see workflow.md "Phase 4: Batched Concurrent Generation"). Update each slide's prompt notes, then run:

```bash
ppt pack {deck}
```

---

## Check Current State

Before making changes, use `ppt info` to see what slots exist:

```bash
ppt info {deck}
# Output: slides: 5 (01, 02, 03, 04, 05)
```
