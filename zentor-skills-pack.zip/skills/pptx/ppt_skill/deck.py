"""Read slide files, metadata and speaker notes for local packaging."""

import json
import re
from pathlib import Path
from typing import Any

WORKSPACE_ROOT = Path("/home/user/.workspace")
OUTPUTS_ROOT = WORKSPACE_ROOT / "outputs"
DECK_META_NAME = "deck.json"
SLIDE_PATTERN = re.compile(r"^slide-(\d+)\.png$")

IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".webp")


class Deck:
    """A deck is a directory under workspace outputs/ containing slide-NN.png files and a deck.json."""

    def __init__(self, name: str, root: Path | None = None) -> None:
        self.name = name
        self.root = (root or OUTPUTS_ROOT) / name
        self.meta_path = self.root / DECK_META_NAME

    # ------------------------------------------------------------------ paths
    def slide_path(self, slot: int) -> Path:
        return self.root / f"slide-{slot:02d}.png"

    def prompt_path(self, slot: int) -> Path:
        return self.root / "prompts" / f"slide-{slot:02d}.md"

    def pptx_path(self) -> Path:
        return self.root / "deck.pptx"

    def html_path(self) -> Path:
        return self.root / "index.html"

    # ---------------------------------------------------------------- listing
    def existing_slots(self) -> list[int]:
        if not self.root.exists():
            return []
        slots = []
        for p in self.root.iterdir():
            m = SLIDE_PATTERN.match(p.name)
            if m:
                slots.append(int(m.group(1)))
        return sorted(slots)

    def slide_files(self) -> list[Path]:
        """Ordered slide PNGs. Fall back to any sorted images if naming isn't NN."""
        if not self.root.exists():
            return []
        numbered = sorted(
            (p for p in self.root.iterdir() if SLIDE_PATTERN.match(p.name)),
            key=lambda p: int(SLIDE_PATTERN.match(p.name).group(1)),
        )
        if numbered:
            return numbered
        return sorted(
            p for p in self.root.iterdir()
            if p.is_file() and p.suffix.lower() in IMAGE_EXTS
        )

    def load_meta(self) -> dict[str, Any]:
        """Read deck.json. Returns {} if missing or unreadable."""
        if not self.meta_path.exists():
            return {}
        try:
            return json.loads(self.meta_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}

    def load_slot_notes(self) -> dict[int, str]:
        """Return slot → full prompt-file text for every slot that has a prompts/slide-NN.md."""
        notes: dict[int, str] = {}
        for slot in self.existing_slots():
            p = self.prompt_path(slot)
            if p.exists():
                notes[slot] = p.read_text(encoding="utf-8")
        return notes
