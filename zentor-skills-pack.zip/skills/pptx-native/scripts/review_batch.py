#!/usr/bin/env python3
"""Apply one OfficeCLI batch, lint, and capture fresh per-slide screenshots."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from components.helpers import get_slide_count
from layout_lint import lint_pptx
from reconstruct import ReconstructionError, resolve_officecli


def check_bullets(paragraphs: list[dict], maximum: int) -> dict:
    """Count explicit native and literal list markers across every text box."""
    counts: dict[int, int] = {}
    elements: dict[int, list[dict]] = {}
    for paragraph in paragraphs:
        path = paragraph["path"]
        match = re.match(r"^/slide\[(\d+)\]/", path)
        if not match or "/notes" in path:
            continue
        slide = int(match[1])
        text = paragraph.get("text") or ""
        formatting = paragraph.get("format") or {}
        native = bool(formatting.get("bulletRaw") or formatting.get("list") not in (None, "", "none"))
        literal = sum(bool(re.match(r"^\s*(?:[•●▪◦‣⁃]|[-–—*]\s+)\S?", line))
                      for line in text.splitlines())
        count = max(int(native and bool(text.strip())), literal)
        counts.setdefault(slide, 0)
        if count:
            counts[slide] += count
            elements.setdefault(slide, []).append({"path": path, "count": count, "text": text[:160]})
    issues = [{"slide": slide, "count": count, "maximum": maximum, "elements": elements[slide]}
              for slide, count in sorted(counts.items()) if count > maximum]
    return {"ok": not issues, "maximum": maximum, "counts": counts, "issues": issues,
            "scope": "Explicit native and literal bullets; unmarked lists need visual review."}


def check_append_targets(items: list[dict], existing: int, pages: list[int]) -> None:
    """Reject an append batch that targets old slides or omits new slides from review."""
    added = sum(item.get("command") == "add" and item.get("type") == "slide" for item in items)
    if not added:
        return
    for item in items:
        for key in ("path", "parent", "part"):
            match = re.match(r"^/(?:slide|noteSlide)\[(\d+)\](?=/|$)", str(item.get(key, "")))
            if match and not existing < int(match[1]) <= existing + added:
                raise ValueError(f"append batch targets {item[key]}; new slides must be "
                                 f"{existing + 1}–{existing + added}. Read the current slide count before building commands; "
                                 "repair existing slides in a separate batch. No commands were applied.")
    missing = set(range(existing + 1, existing + added + 1)) - set(pages)
    if missing:
        raise ValueError(f"--pages must include every appended slide: {sorted(missing)}. No commands were applied.")


def review_batch(pptx: str, pages: list[int], output: str, commands: str | None = None,
                 max_bullets: int | None = None) -> dict:
    deck = str(Path(pptx).resolve())
    if not pages or any(page < 1 for page in pages):
        raise ValueError("pages must contain positive slide numbers")
    if max_bullets is not None and max_bullets < 0:
        raise ValueError("max_bullets must be non-negative")
    directory = Path(output).resolve()
    directory.mkdir(parents=True, exist_ok=True)
    run_dir = Path(tempfile.mkdtemp(prefix="review-", dir=directory))
    result = {"ok": False, "record": str(run_dir / "result.json"), "screenshots": [], "pages": pages}

    def run(args: list[str], name: str, *, check: bool = True) -> subprocess.CompletedProcess[str]:
        process = subprocess.run(
            [binding["path"], *args], capture_output=True, text=True, timeout=600,
            env={**os.environ, "OFFICECLI_SKIP_UPDATE": "1"},
        )
        (run_dir / f"{name}.json").write_text(json.dumps({
            "exit_code": process.returncode, "stdout": process.stdout, "stderr": process.stderr,
        }, ensure_ascii=False, indent=2))
        if check and process.returncode:
            raise RuntimeError(f"OfficeCLI {name} failed; inspect {run_dir / f'{name}.json'}")
        return process

    try:
        # Failed checks must not expose an earlier screenshot as the current result.
        for page in pages:
            (directory / f"slide-{page:02}.png").unlink(missing_ok=True)
        binding = resolve_officecli(None)
        existing = get_slide_count(Path(deck), binding["path"]) if Path(deck).exists() else 0
        if commands:
            source = Path(commands).resolve()
            items = json.loads(source.read_text())
            if not isinstance(items, list) or not items:
                raise ValueError("input must be a non-empty OfficeCLI command array; "
                                 "to recheck unchanged slides, omit --input and pass --pages")
            check_append_targets(items, existing, pages)
            (run_dir / "commands.json").write_text(json.dumps(items, ensure_ascii=False, indent=2))
            result["input"] = str(source)
            # Persist intent before mutation. Never retry this batch automatically.
            (run_dir / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2))
            process = run(["batch", deck, "--input", str(source), "--stop-on-error", "--json"], "batch", check=False)
            batch = json.loads(process.stdout)
            if not isinstance(batch, dict):
                raise ValueError("OfficeCLI batch returned a non-object JSON response")
            data = batch.get("data") or {}
            result["batch"] = {
                "success": batch.get("success"), "summary": data.get("summary"),
                "record": str(run_dir / "batch.json"),
                "first_failure": next((item for item in data.get("results", [])
                                       if item.get("success") is False), None),
            }
            if (process.returncode or batch.get("success") is not True
                    or data.get("summary", {}).get("failed", 0)
                    or data.get("summary", {}).get("atomicRolledBack")
                    or data.get("atomicRolledBack") or batch.get("atomicRolledBack")):
                raise RuntimeError("Batch did not succeed; inspect the saved result before any further write")
        run(["save", deck], "save")
        report = lint_pptx(deck)
        result["lint"] = report
        if max_bullets is not None:
            response = json.loads(run(["query", deck, "paragraph", "--json"], "paragraphs").stdout)
            data = response.get("data") or {}
            if response.get("success") is not True or not isinstance(data.get("results"), list):
                raise ValueError("OfficeCLI paragraph query failed; inspect paragraphs.json")
            if data.get("matches") != len(data["results"]):
                raise ValueError("OfficeCLI returned an incomplete paragraph query")
            result["bullets"] = check_bullets(data["results"], max_bullets)
            if not result["bullets"]["ok"]:
                return result
        if report.get("ok") is not True or report.get("error_count", 1) != 0 or report.get("error"):
            return result
        for page in dict.fromkeys(pages):
            screenshot = run_dir / f"slide-{page:02}.png"
            run(["view", deck, "screenshot", "--page", str(page), "--out", str(screenshot),
                 "--screenshot-width", "1280", "--screenshot-height", "720", "--render", "html"],
                f"screenshot-{page:02}")
            if not screenshot.is_file() or screenshot.stat().st_size == 0:
                raise RuntimeError(f"OfficeCLI did not produce slide {page}'s screenshot")
            current = directory / screenshot.name
            result["screenshots"].append({"slide": page, "path": str(current)})
            shutil.copyfile(screenshot, current)
        result["ok"] = True
        return result
    except (OSError, ValueError, RuntimeError, ReconstructionError, subprocess.SubprocessError) as exc:
        result["error"] = str(exc)
        return result
    finally:
        if not result["ok"]:
            for screenshot in result["screenshots"]:
                Path(screenshot["path"]).unlink(missing_ok=True)
            result["screenshots"] = []
        (run_dir / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2))


def receipt(result: dict) -> dict:
    """Keep the current run's paths visible; full diagnostics remain in record."""
    output = {key: result[key] for key in ("ok", "record", "screenshots", "pages")}
    if "error" in result:
        output["error"] = result["error"]
    if "batch" in result:
        batch = result["batch"]
        output["batch"] = {key: batch.get(key) for key in ("success", "summary", "record")}
        failure = batch.get("first_failure")
        if failure:
            output["batch"]["first_failure"] = {
                key: failure.get(key) for key in ("index", "error", "code")
            }
            output["batch"]["first_failure"]["path"] = (failure.get("item") or {}).get("path")
    if "lint" in result:
        report = result["lint"]
        issues = report.get("issues", [])
        output["lint"] = {key: report.get(key) for key in ("ok", "error_count", "error")}
        output["lint"]["issues"] = [
            {key: issue.get(key) for key in ("level", "code", "elements", "message", "hint")}
            for issue in issues[:8]
        ]
        output["lint"]["remaining_issues"] = max(0, len(issues) - 8)
    if "bullets" in result:
        output["bullets"] = {
            key: result["bullets"][key] for key in ("ok", "maximum", "counts")
        }
    return output


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pptx")
    parser.add_argument("--pages", type=int, nargs="+", required=True)
    parser.add_argument("--out", default="review")
    parser.add_argument("--input", help="Apply this batch once before checking; omit for check-only use")
    parser.add_argument("--max-bullets", type=int, help="Maximum explicit list items per slide; use the user's limit")
    args = parser.parse_args()
    result = review_batch(args.pptx, args.pages, args.out, args.input, args.max_bullets)
    print(json.dumps(receipt(result), ensure_ascii=False))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
