#!/usr/bin/env python3
"""Export selected OfficeCLI-created slides as commands for appending to compatible blank presentations."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

from reconstruct import ReconstructionError, resolve_officecli


def rebase_slide(items: list[dict], source: int, target: int) -> list[dict]:
    """Relocate command targets only; preserve content, notes, pictures, and text inside XML."""
    if not isinstance(items, list) or not items or items[0] != {"command": "meta", "dumpVersion": 2}:
        raise ValueError("Expected an OfficeCLI dumpVersion 2 command array")
    commands = copy.deepcopy(items[1:])
    slides = 0
    for item in commands:
        command = item.get("command")
        if command not in {"add", "set", "raw-set"}:
            raise ValueError(f"Unsupported exported command: {command}")
        if command == "add":
            kind = item.get("type")
            if kind not in {"slide", "placeholder", "textbox", "shape", "picture", "table", "paragraph", "notes", "chart"}:
                raise ValueError(f"Unsupported exported element: {kind}; create it in the final deck")
            if kind == "slide":
                slides += 1
            if kind == "picture" and not str(item.get("props", {}).get("src", "")).startswith("data:image/"):
                raise ValueError("Exported pictures must contain embedded image data")
        for key in ("path", "parent", "part"):
            if key not in item:
                continue
            value = item[key]
            if value == "/" and command == "add" and item.get("type") == "slide":
                continue
            match = re.match(r"^/(slide|noteSlide)\[(\d+)\](?=/|$)", value)
            if not match or int(match[2]) != source:
                raise ValueError(f"Export refers outside source slide {source}: {key}={value}")
            item[key] = f"/{match[1]}[{target}]" + value[match.end():]
        if command == "raw-set" and re.search(r"\br:(?:embed|link|id)\s*=", item.get("xml", "")):
            raise ValueError("Raw XML contains external part relationships; create this page in the final deck")
    if slides != 1:
        raise ValueError(f"Expected exactly one slide creation, found {slides}")
    return commands


def export_slides(source: str, pages: list[int], start: int, output: str) -> dict:
    if not pages or min(pages) < 1 or len(set(pages)) != len(pages) or start < 1:
        raise ValueError("pages must be distinct positive numbers; start must be positive")
    deck = Path(source).resolve(strict=True)
    directory = Path(output).resolve()
    directory.mkdir(parents=True, exist_ok=True)
    run_dir = Path(tempfile.mkdtemp(prefix="export-", dir=directory))
    result = {"ok": False, "record": str(run_dir / "result.json"), "source": str(deck),
              "mapping": [{"source": page, "target": start + i} for i, page in enumerate(pages)]}
    try:
        binding = resolve_officecli(None)

        def run(args: list[str], name: str) -> None:
            process = subprocess.run([binding["path"], *args], capture_output=True, text=True,
                                     timeout=600, env={**os.environ, "OFFICECLI_SKIP_UPDATE": "1"})
            (run_dir / f"{name}-process.json").write_text(json.dumps({
                "exit_code": process.returncode, "stdout": process.stdout, "stderr": process.stderr,
            }, ensure_ascii=False))
            if process.returncode:
                raise RuntimeError(f"OfficeCLI {name} failed; inspect {run_dir / f'{name}-process.json'}")

        run(["save", str(deck)], "save")
        result["source_sha256"] = hashlib.sha256(deck.read_bytes()).hexdigest()
        commands = [{"command": "meta", "dumpVersion": 2}]
        for i, page in enumerate(pages):
            path = run_dir / f"slide-{page}.json"
            run(["dump", str(deck), f"/slide[{page}]", "--out", str(path)], f"dump-{page}")
            commands.extend(rebase_slide(json.loads(path.read_text()), page, start + i))
        path = run_dir / "commands.json"
        path.write_text(json.dumps(commands, ensure_ascii=False))
        result.update(ok=True, commands=str(path), command_count=len(commands) - 1)
    except (OSError, ValueError, RuntimeError, ReconstructionError, subprocess.TimeoutExpired) as exc:
        result["error"] = str(exc)
    finally:
        (run_dir / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2))
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pptx")
    parser.add_argument("--pages", type=int, nargs="+", required=True)
    parser.add_argument("--start", type=int, required=True, help="First final slide number after appending")
    parser.add_argument("--out", default="exports")
    args = parser.parse_args()
    try:
        result = export_slides(args.pptx, args.pages, args.start, args.out)
    except (OSError, ValueError) as exc:
        result = {"ok": False, "error": str(exc)}
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
