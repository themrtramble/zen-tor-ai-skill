#!/usr/bin/env python3
"""Native PPTX layout lint driven by OfficeCLI commands.

  officecli validate deck.pptx --json
  officecli view deck.pptx issues --json
  officecli get deck.pptx / --depth 2 --json
  officecli view deck.pptx outline --json

Do not parse OOXML. Query JSON geometry is the layout source.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from typing import Any

from reconstruct import (
    SHORT_TEXT_MAX_CHARACTERS,
    SHORT_TEXT_MAX_SLIDE_WIDTH_RATIO,
    ReconstructionError,
    _is_none_paint,
    _length_to_points,
    _run_json,
    resolve_officecli,
)


SKIP_TYPES = frozenset({"presentation", "slide", "paragraph", "run", "notes"})
OPAQUE_FILL_TYPES = frozenset({"textbox", "shape", "title", "picture", "chart", "table"})
CANVAS_OVERFLOW_PT = 2.0
CONTAINMENT_PT = 4.0
OVERLAP_AREA_RATIO = 0.08

def _issue(
    *,
    level: str,
    code: str,
    elements: list[str],
    message: str,
    hint: str,
    **extra: Any,
) -> dict[str, Any]:
    payload = {
        "level": level,
        "code": code,
        "elements": elements,
        "message": message,
        "hint": hint,
    }
    payload.update(extra)
    return payload


def _pt(value: Any) -> float | None:
    return _length_to_points(value)


def _walk(node: dict[str, Any], slide_path: str | None, acc: list[dict[str, Any]]) -> None:
    node_type = node.get("type")
    path = node.get("path")
    if node_type == "slide" and isinstance(path, str):
        slide_path = path
    fmt = node.get("format") if isinstance(node.get("format"), dict) else {}
    if (
        isinstance(node_type, str)
        and node_type not in SKIP_TYPES
        and isinstance(path, str)
        and slide_path is not None
        and all(key in fmt for key in ("x", "y", "width", "height"))
    ):
        x = _pt(fmt.get("x"))
        y = _pt(fmt.get("y"))
        width = _pt(fmt.get("width"))
        height = _pt(fmt.get("height"))
        if None not in (x, y, width, height):
            zorder = fmt.get("zorder")
            acc.append(
                {
                    "path": path,
                    "slide": slide_path,
                    "type": node_type,
                    "name": fmt.get("name"),
                    "id": fmt.get("id"),
                    "text": node.get("text") if isinstance(node.get("text"), str) else "",
                    "x": x,
                    "y": y,
                    "width": width,
                    "height": height,
                    "zorder": zorder if isinstance(zorder, int) else 0,
                    "fill": fmt.get("fill"),
                    "line": fmt.get("line"),
                    "isTitle": fmt.get("isTitle") is True,
                    "geometry": fmt.get("geometry"),
                }
            )
    for child in node.get("children") or []:
        if isinstance(child, dict):
            _walk(child, slide_path, acc)


def _presentation_size(root: dict[str, Any]) -> tuple[float, float]:
    fmt = root.get("format") if isinstance(root.get("format"), dict) else {}
    width = _pt(fmt.get("slideWidth"))
    height = _pt(fmt.get("slideHeight"))
    if width is None or height is None or width <= 0 or height <= 0:
        raise ReconstructionError(
            "Presentation slideWidth/slideHeight must use cm, mm, in, pt, px, or emu."
        )
    return width, height


def _area(element: dict[str, Any]) -> float:
    return max(element["width"], 0) * max(element["height"], 0)


def _intersects(left: dict[str, Any], right: dict[str, Any]) -> bool:
    return (
        left["x"] < right["x"] + right["width"]
        and left["x"] + left["width"] > right["x"]
        and left["y"] < right["y"] + right["height"]
        and left["y"] + left["height"] > right["y"]
    )


def _intersection_area(left: dict[str, Any], right: dict[str, Any]) -> float:
    width = min(left["x"] + left["width"], right["x"] + right["width"]) - max(left["x"], right["x"])
    height = min(left["y"] + left["height"], right["y"] + right["height"]) - max(left["y"], right["y"])
    return max(width, 0) * max(height, 0)


def _contains(outer: dict[str, Any], inner: dict[str, Any], tolerance: float = CONTAINMENT_PT) -> bool:
    return (
        inner["x"] >= outer["x"] - tolerance
        and inner["y"] >= outer["y"] - tolerance
        and inner["x"] + inner["width"] <= outer["x"] + outer["width"] + tolerance
        and inner["y"] + inner["height"] <= outer["y"] + outer["height"] + tolerance
    )


def _is_full_slide(element: dict[str, Any], slide_width: float, slide_height: float) -> bool:
    return (
        element["x"] <= CANVAS_OVERFLOW_PT
        and element["y"] <= CANVAS_OVERFLOW_PT
        and element["width"] >= slide_width - CANVAS_OVERFLOW_PT * 2
        and element["height"] >= slide_height - CANVAS_OVERFLOW_PT * 2
    )


def _has_text(element: dict[str, Any]) -> bool:
    return bool(str(element.get("text") or "").strip())


def _is_opaque(element: dict[str, Any]) -> bool:
    if element["type"] in {"picture", "chart", "table"}:
        return True
    return not _is_none_paint(element.get("fill"))


def detect_out_of_canvas(
    elements: list[dict[str, Any]], slide_width: float, slide_height: float
) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    for element in elements:
        overflow = {
            "left": max(-element["x"], 0),
            "top": max(-element["y"], 0),
            "right": max(element["x"] + element["width"] - slide_width, 0),
            "bottom": max(element["y"] + element["height"] - slide_height, 0),
        }
        details = [
            f"{side} {amount:.1f}pt"
            for side, amount in overflow.items()
            if amount > CANVAS_OVERFLOW_PT
        ]
        if not details:
            continue
        issues.append(
            _issue(
                level="error",
                code="element_out_of_canvas",
                elements=[element["path"]],
                message=(
                    f"{element['type']} {element['path']} exceeds the "
                    f"{slide_width:.1f}x{slide_height:.1f}pt canvas ({', '.join(details)})"
                ),
                hint="Move the element inside the slide or reduce width/height.",
                overflow=overflow,
            )
        )
    return issues


def detect_bbox_overlap(
    elements: list[dict[str, Any]], slide_width: float, slide_height: float
) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    for index, left in enumerate(elements):
        for right in elements[index + 1 :]:
            if left["slide"] != right["slide"]:
                continue
            if _is_full_slide(left, slide_width, slide_height) or _is_full_slide(
                right, slide_width, slide_height
            ):
                continue
            if not _intersects(left, right):
                continue
            if _contains(left, right) and left["zorder"] <= right["zorder"]:
                continue
            if _contains(right, left) and right["zorder"] <= left["zorder"]:
                continue
            smaller = min(_area(left), _area(right))
            if smaller <= 0 or _intersection_area(left, right) / smaller < OVERLAP_AREA_RATIO:
                continue
            left_text, right_text = _has_text(left), _has_text(right)
            covering = (
                (_is_opaque(left) and left["zorder"] > right["zorder"] and right_text)
                or (_is_opaque(right) and right["zorder"] > left["zorder"] and left_text)
            )
            text_pair = left_text and right_text
            if not covering and not text_pair:
                continue
            issues.append(
                _issue(
                    level="error",
                    code="bbox_overlap",
                    elements=[left["path"], right["path"]],
                    message=f"{left['path']} overlaps {right['path']}",
                    hint="Move or resize so the visual bounds no longer collide.",
                )
            )
    return issues


def detect_blank_slides(
    elements: list[dict[str, Any]], slide_paths: list[str]
) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    for slide_path in slide_paths:
        visible = [
            element
            for element in elements
            if element["slide"] == slide_path
            and (
                element["type"] in {"picture", "chart", "table", "connector"}
                or _has_text(element)
                or _is_opaque(element)
            )
        ]
        if visible:
            continue
        issues.append(
            _issue(
                level="error",
                code="blank_slide",
                elements=[slide_path],
                message=f"{slide_path} has no visible content",
                hint="Add text, a picture, a chart, or a table before delivery.",
            )
        )
    return issues


def detect_duplicate_ids(elements: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for element in elements:
        key = element.get("id")
        if key is None or key == "":
            continue
        grouped.setdefault(f"{element['slide']}::{key}", []).append(element)
    return [
        _issue(
            level="error",
            code="duplicate_element_id",
            elements=[element["path"] for element in duplicates],
            message=f"drawing id {key.split('::', 1)[1]} is used {len(duplicates)} times on the same slide",
            hint="Keep OfficeCLI-assigned ids; do not copy id onto a new element.",
        )
        for key, duplicates in grouped.items()
        if len(duplicates) > 1
    ]


def detect_short_transparent_text(
    elements: list[dict[str, Any]], slide_width: float
) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    for element in elements:
        if element["type"] not in {"textbox", "shape"} or element["isTitle"]:
            continue
        text = str(element.get("text") or "")
        compact = "".join(text.replace("\r\n", "\n").replace("\r", "\n").split())
        if (
            not compact
            or "\n" in text
            or len(compact) > SHORT_TEXT_MAX_CHARACTERS
            or not _is_none_paint(element.get("fill"))
            or not _is_none_paint(element.get("line"))
        ):
            continue
        ratio = element["width"] / slide_width
        if ratio <= SHORT_TEXT_MAX_SLIDE_WIDTH_RATIO:
            continue
        issues.append(
            _issue(
                level="error",
                code="short_transparent_text_too_wide",
                elements=[element["path"]],
                message=(
                    f"{element['path']} short transparent text uses {ratio:.1%} of the slide width"
                ),
                hint="Size the shape to the text block; adjust x for alignment instead of slide-wide geometry.",
            )
        )
    return issues


def _officecli_issues(payload: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        return []
    data = payload.get("data")
    raw = data.get("issues") if isinstance(data, dict) else None
    if not isinstance(raw, list):
        return []
    issues: list[dict[str, Any]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        path = item.get("path")
        message = item.get("message") or "OfficeCLI reported an issue."
        issues.append(
            _issue(
                level="error" if item.get("severity", 1) else "warning",
                code="officecli_issue",
                elements=[path] if isinstance(path, str) else [],
                message=str(message),
                hint="Fix using OfficeCLI set/move/remove on the reported stable path.",
                officecliId=item.get("id"),
            )
        )
    return issues


def _validation_issues(payload: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        return []
    data = payload.get("data")
    if isinstance(data, str) and "no errors" in data.casefold():
        return []
    if isinstance(data, dict):
        count = int(data.get("count") or 0)
        errors = data.get("errors") if isinstance(data.get("errors"), list) else []
        if count == 0 and not errors:
            return []
        return [
            _issue(
                level="error",
                code="officecli_validate",
                elements=[],
                message=str(item) if not isinstance(item, dict) else str(item.get("message") or item),
                hint="Fix OpenXML structure until officecli validate reports no errors.",
            )
            for item in (errors or [f"{count} OpenXML validation error(s)"])
        ]
    if payload.get("success") is False:
        return [
            _issue(
                level="error",
                code="officecli_validate",
                elements=[],
                message=str(payload.get("message") or "officecli validate failed"),
                hint="Fix OpenXML structure until officecli validate reports no errors.",
            )
        ]
    return []


def lint_query(
    query: dict[str, Any],
    *,
    issues_payload: dict[str, Any] | None = None,
    validation_payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    data = query.get("data") if isinstance(query, dict) else None
    results = data.get("results") if isinstance(data, dict) else None
    if not isinstance(results, list) or not results or not isinstance(results[0], dict):
        raise ReconstructionError("officecli get / --json did not return a presentation node.")
    root = results[0]
    slide_width, slide_height = _presentation_size(root)
    elements: list[dict[str, Any]] = []
    _walk(root, None, elements)
    slide_paths = [
        child["path"]
        for child in root.get("children") or []
        if isinstance(child, dict) and child.get("type") == "slide" and isinstance(child.get("path"), str)
    ]
    issues = [
        *_validation_issues(validation_payload),
        *_officecli_issues(issues_payload),
        *detect_out_of_canvas(elements, slide_width, slide_height),
        *detect_bbox_overlap(elements, slide_width, slide_height),
        *detect_blank_slides(elements, slide_paths),
        *detect_duplicate_ids(elements),
        *detect_short_transparent_text(elements, slide_width),
    ]
    errors = [issue for issue in issues if issue["level"] == "error"]
    return {
        "ok": not errors,
        "error_count": len(errors),
        "issue_count": len(issues),
        "slide_size_pt": {"width": slide_width, "height": slide_height},
        "element_count": len(elements),
        "issues": issues,
    }


def _flush_to_disk(binding: dict[str, Any], path: str) -> None:
    """Best-effort `officecli save` so lint reads the writer's latest state.

    OfficeCLI's auto-spawned resident process applies `batch`/`set` mutations in
    memory and flushes to disk lazily, while this script reads the on-disk file
    with the resident disabled. Run `save` with the ambient environment (the
    same one the writer used) so a running resident flushes before we read.
    """
    subprocess.run(
        [binding["path"], "save", path],
        check=False,
        capture_output=True,
        text=True,
        env={**os.environ, "OFFICECLI_SKIP_UPDATE": "1"},
    )


def lint_pptx(path: str, officecli_bin: str | None = None) -> dict[str, Any]:
    binding = resolve_officecli(officecli_bin)
    _flush_to_disk(binding, path)
    validation = _run_json(binding, ["validate", path, "--json"], "OfficeCLI validation")
    issues = _run_json(binding, ["view", path, "issues", "--json"], "OfficeCLI issues")
    query = _run_json(binding, ["get", path, "/", "--depth", "2", "--json"], "OfficeCLI get")
    return lint_query(query, issues_payload=issues, validation_payload=validation)


def inspect_pptx(path: str, officecli_bin: str | None = None) -> dict[str, Any]:
    binding = resolve_officecli(officecli_bin)
    _flush_to_disk(binding, path)
    outline = _run_json(binding, ["view", path, "outline", "--json"], "OfficeCLI outline")
    query = _run_json(binding, ["get", path, "/", "--depth", "1", "--json"], "OfficeCLI get")
    return {"outline": outline, "query": query}


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Lint a native PPTX with OfficeCLI validate/get/view issues."
    )
    parser.add_argument("pptx")
    parser.add_argument("--officecli-bin")
    parser.add_argument(
        "--inspect",
        action="store_true",
        help="Dump officecli view outline + get instead of linting.",
    )
    return parser


def main() -> int:
    args = _parser().parse_args()
    try:
        if args.inspect:
            report = inspect_pptx(args.pptx, officecli_bin=args.officecli_bin)
        else:
            report = lint_pptx(args.pptx, officecli_bin=args.officecli_bin)
    except ReconstructionError as exc:
        report = {"ok": False, "error": str(exc)}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
