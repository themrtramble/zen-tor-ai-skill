"""OfficeCLI comparison panels for old-versus-new or competitor analysis."""

from __future__ import annotations

from typing import Any, Mapping

from ._base import EMU_PER_INCH, ComponentBuilder, combine_text, lighten, line_spec, parse_box


def add_comparison(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    panels: list[Mapping[str, Any]],
    style,
    *,
    vs_label: str = "VS",
    name: str | None = None,
) -> list[dict[str, Any]]:
    """Return OfficeCLI commands for two to four comparison panels."""
    if not 2 <= len(panels) <= 4:
        raise ValueError("comparison requires 2-4 panels")
    ox, oy, width, height = parse_box(origin, size)
    builder = ComponentBuilder(slide, "comparison", style, name=name)
    palette = builder.style.palette
    fonts = builder.style.fonts
    ordered = _reorder_for_featured(panels)
    rows, columns = (2, 2) if len(ordered) == 4 else (1, len(ordered))
    gap = int(0.25 * EMU_PER_INCH)
    cell_width = (width - gap * (columns - 1)) // columns
    cell_height = (height - gap * (rows - 1)) // rows
    band_height = min(int(0.78 * EMU_PER_INCH), cell_height // 3)

    for index, panel in enumerate(ordered):
        row, column = divmod(index, columns)
        x = ox + column * (cell_width + gap)
        y = oy + row * (cell_height + gap)
        featured = bool(panel.get("featured"))
        band_color = palette.primary if featured else palette.muted
        border_color = palette.primary if featured else lighten(palette.muted, 0.3)
        builder.shape("title-band", x, y, cell_width, band_height, fill=band_color, line="none")
        kicker = str(panel.get("kicker", "")).upper()
        if kicker:
            builder.text("kicker", kicker, x + int(0.18 * EMU_PER_INCH), y + int(0.06 * EMU_PER_INCH), cell_width - int(0.36 * EMU_PER_INCH), int(0.20 * EMU_PER_INCH), size=9, color=palette.bg, bold=True)
            title_y = y + int(0.27 * EMU_PER_INCH)
        else:
            title_y = y + int(0.17 * EMU_PER_INCH)
        builder.text("panel-title", str(panel.get("title", "")), x + int(0.18 * EMU_PER_INCH), title_y, cell_width - int(0.36 * EMU_PER_INCH), int(0.34 * EMU_PER_INCH), size=18, color=palette.bg, bold=True, font=fonts.header, valign="center")

        body_y = y + band_height
        body_height = cell_height - band_height
        builder.shape("body", x, body_y, cell_width, body_height, fill=palette.bg, line=line_spec(border_color, 1))
        content_x = x + int(0.20 * EMU_PER_INCH)
        content_width = cell_width - int(0.40 * EMU_PER_INCH)
        cursor_y = body_y + int(0.14 * EMU_PER_INCH)
        if panel.get("tagline"):
            builder.text("tagline", str(panel["tagline"]), content_x, cursor_y, content_width, int(0.30 * EMU_PER_INCH), size=11, color=palette.muted, italic=True)
            cursor_y += int(0.36 * EMU_PER_INCH)
        scale_reserved = int(0.62 * EMU_PER_INCH) if panel.get("scale") else 0
        available = max(body_y + body_height - cursor_y - scale_reserved - int(0.12 * EMU_PER_INCH), int(0.5 * EMU_PER_INCH))
        items = list(panel.get("items", []))
        item_height = min(available // max(len(items), 1), int(0.78 * EMU_PER_INCH))
        for item_index, item in enumerate(items, start=1):
            item_y = cursor_y + (item_index - 1) * item_height
            number = item.get("number", item_index)
            heading = f"{number:02d}  {item.get('title', '')}" if isinstance(number, int) else f"{number}  {item.get('title', '')}"
            builder.text("item-title", heading, content_x, item_y, content_width, min(int(0.26 * EMU_PER_INCH), item_height), size=12, color=palette.primary if featured else palette.on_bg, bold=True, font=fonts.header)
            if item.get("desc"):
                builder.text("item-desc", str(item["desc"]), content_x, item_y + int(0.27 * EMU_PER_INCH), content_width, max(item_height - int(0.29 * EMU_PER_INCH), int(0.18 * EMU_PER_INCH)), size=10, color=palette.muted)
        if panel.get("scale"):
            scale = panel["scale"]
            builder.text("scale", combine_text([f"{scale.get('value', '')} {scale.get('unit', '')}".strip()]), content_x, body_y + body_height - scale_reserved, content_width, scale_reserved, size=22, color=palette.primary if featured else palette.muted, bold=True, font=fonts.header, valign="bottom")

    if len(ordered) == 2:
        badge = int(0.56 * EMU_PER_INCH)
        builder.shape(
            "vs", ox + cell_width + (gap - badge) // 2, oy + (height - badge) // 2,
            badge, badge, geometry="ellipse", fill=palette.primary, line="none",
            text=vs_label, font=fonts.header, size=13, color=palette.bg, bold=True,
            align="center", valign="center", margin=0,
        )
    return builder.commands


def _reorder_for_featured(panels: list[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
    if len(panels) == 2 and panels[0].get("featured") and not panels[1].get("featured"):
        return [panels[1], panels[0]]
    return list(panels)
