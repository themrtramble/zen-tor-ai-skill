"""Generate or apply composite component commands with OfficeCLI."""

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Mapping

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from components import COMPONENTS, apply_commands, write_commands
else:
    from . import COMPONENTS, apply_commands, write_commands


class InvalidSpecification(ValueError):
    """All independently detected input errors from a compilation pass."""

    def __init__(self, issues: list[str]):
        self.issues = issues
        super().__init__("Invalid component specification:\n" + "\n".join(issues))


def build_commands(document: Mapping[str, Any] | list[Any]) -> list[dict[str, Any]]:
    """Compile component specifications, reporting errors before any write."""
    if isinstance(document, Mapping) and "slides" in document:
        raise ValueError("use component specifications; compose slides with the Python component functions")
    issues: list[str] = []
    if isinstance(document, list):
        specifications = document
        default_style: Mapping[str, Any] | None = None
    else:
        specifications = document.get("components", [])
        default_style = document.get("style")
    commands: list[dict[str, Any]] = []
    for index, specification in enumerate(specifications, start=1):
        if not isinstance(specification, Mapping):
            issues.append(f"component[{index}]: component must be an object")
            continue
        component_name = str(specification.get("component", ""))
        slide = str(specification.get("slide", "/slide[1]"))
        props = specification.get("props", {})
        name = props.get("name", component_name) if isinstance(props, Mapping) else component_name
        try:
            function = COMPONENTS.get(component_name)
            if function is None:
                available = ", ".join(sorted(COMPONENTS))
                raise ValueError(f"unknown component {component_name!r}; expected one of: {available}")
            style = specification.get("style", default_style)
            if style is None:
                raise ValueError("component has no style")
            keyword_arguments = dict(props)
            keyword_arguments.update(
                slide=slide,
                origin=tuple(specification["origin"]),
                size=tuple(specification["size"]),
                style=style,
            )
            commands.extend(function(**keyword_arguments))
        except (KeyError, TypeError, ValueError) as exc:
            issues.append(f"{slide} component[{index}] {component_name} {name!r}: {exc}")
    if issues:
        raise InvalidSpecification(issues)
    return commands


def _officecli_path(value: str) -> str:
    if "/" in value:
        return value
    resolved = shutil.which(value)
    if resolved is None:
        raise FileNotFoundError(f"OfficeCLI executable not found: {value}")
    return resolved


def _create_deck(deck: Path, slide_count: int, officecli: str) -> None:
    if deck.exists():
        raise FileExistsError(f"refusing to overwrite existing deck: {deck}")
    deck.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([officecli, "create", str(deck)], check=True, capture_output=True, text=True)
    slide_commands = [
        {"command": "set", "path": "/", "props": {"slideWidth": "13.333in", "slideHeight": "7.5in"}},
        *[
            {"command": "add", "parent": "/", "type": "slide", "props": {"layout": "blank", "name": f"slide-{index:02d}", "background": "FFFFFF"}}
            for index in range(1, slide_count + 1)
        ],
    ]
    apply_commands(deck, slide_commands, officecli=officecli)


def _required_slides(commands: list[Mapping[str, Any]]) -> int:
    highest = 1
    for command in commands:
        path = str(command.get("parent") or command.get("path") or "")
        match = re.search(r"/slide\[(\d+)]", path)
        if match:
            highest = max(highest, int(match.group(1)))
    return highest


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build OfficeCLI command arrays for composite PPTX components.")
    parser.add_argument("action", choices=("plan", "apply"))
    parser.add_argument("--spec", required=True, type=Path, help="JSON component specification")
    parser.add_argument("--out", type=Path, help="output JSON command plan for action=plan")
    parser.add_argument("--deck", type=Path, help="target PPTX for action=apply")
    parser.add_argument("--create", action="store_true", help="create a blank deck with enough slides before applying")
    parser.add_argument("--officecli", default="officecli")
    arguments = parser.parse_args(argv)
    document = json.loads(arguments.spec.read_text(encoding="utf-8"))
    commands = build_commands(document)
    if arguments.action == "plan":
        if arguments.out is None:
            json.dump(commands, sys.stdout, ensure_ascii=False, indent=2)
            sys.stdout.write("\n")
        else:
            write_commands(commands, arguments.out)
        return 0
    if arguments.deck is None:
        parser.error("--deck is required for action=apply")
    officecli = _officecli_path(arguments.officecli)
    if arguments.create:
        _create_deck(arguments.deck, _required_slides(commands), officecli)
    result = apply_commands(arguments.deck, commands, officecli=officecli)
    print(json.dumps({"deck": str(arguments.deck), "commands": len(commands), "result": result}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
