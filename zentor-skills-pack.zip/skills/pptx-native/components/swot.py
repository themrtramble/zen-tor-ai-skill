"""OfficeCLI SWOT matrix with semantic axes and compact quadrant content."""

from __future__ import annotations

from typing import Any, Mapping, Sequence

from ._base import EMU_PER_INCH, ComponentBuilder, darken, lighten, line_spec, parse_box, to_emu

_LAYOUT = [
    ("strengths", "highHigh", 0, 0, "primary"),
    ("weaknesses", "highLow", 1, 0, "accent"),
    ("opportunities", "lowHigh", 0, 1, "secondary"),
    ("threats", "lowLow", 1, 1, "muted"),
]
_TITLES = {
    "strengths": "Strengths", "weaknesses": "Weaknesses",
    "opportunities": "Opportunities", "threats": "Threats",
    "highHigh": "High probability / High impact", "highLow": "High probability / Low impact",
    "lowHigh": "Low probability / High impact", "lowLow": "Low probability / Low impact",
}
_SWOT_AXIS_LABELS = {
    "column_left": "Helpful",
    "column_right": "Harmful",
    "row_top": "Internal",
    "row_bottom": "External",
}
_PROBABILITY_AXIS_LABELS = {
    "column_left": "High impact",
    "column_right": "Low impact",
    "row_top": "High probability",
    "row_bottom": "Low probability",
}


def add_swot(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    quadrants: Mapping[str, Any] | Sequence[Any],
    style,
    *,
    axis_labels: Mapping[str, str] | None = None,
    show_axes: bool = True,
    item_gap: Any = "0.06in",
    name: str | None = None,
) -> list[dict[str, Any]]:
    """Return OfficeCLI commands for a traditional editable SWOT matrix."""
    ox, oy, width, height = parse_box(origin, size)
    builder = ComponentBuilder(slide, "swot", style, name=name)
    palette = builder.style.palette
    normalized = _normalize(quadrants)
    is_swot = any(key in normalized for key in ("strengths", "weaknesses", "opportunities", "threats"))
    labels = dict(_SWOT_AXIS_LABELS if is_swot else _PROBABILITY_AXIS_LABELS)
    labels.update(axis_labels or {})

    axis_width = int(0.68 * EMU_PER_INCH) if show_axes else 0
    axis_height = int(0.38 * EMU_PER_INCH) if show_axes else 0
    matrix_x = ox + axis_width
    matrix_y = oy + axis_height
    matrix_width = width - axis_width
    matrix_height = height - axis_height
    cell_width = matrix_width // 2
    cell_height = matrix_height // 2
    divider_color = lighten(palette.muted, 0.38)
    divider = line_spec(divider_color, 1.1)

    if show_axes:
        builder.text(
            "axis-column-left", labels["column_left"], matrix_x, oy,
            cell_width, axis_height, size=9.5, color=palette.muted,
            bold=True, align="center", valign="center",
        )
        builder.text(
            "axis-column-right", labels["column_right"], matrix_x + cell_width, oy,
            matrix_width - cell_width, axis_height, size=9.5, color=palette.muted,
            bold=True, align="center", valign="center",
        )
        builder.text(
            "axis-row-top", labels["row_top"], ox, matrix_y,
            axis_width, cell_height, size=9.5, color=palette.muted,
            bold=True, align="center", valign="center",
        )
        builder.text(
            "axis-row-bottom", labels["row_bottom"], ox, matrix_y + cell_height,
            axis_width, matrix_height - cell_height, size=9.5, color=palette.muted,
            bold=True, align="center", valign="center",
        )

    for semantic, probability, column, row, role in _LAYOUT:
        data = normalized.get(semantic) or normalized.get(probability)
        if not data:
            continue
        color = getattr(palette, role)
        x = matrix_x + column * cell_width
        y = matrix_y + row * cell_height
        quadrant_width = matrix_width - cell_width if column else cell_width
        quadrant_height = matrix_height - cell_height if row else cell_height
        builder.shape(
            "quadrant", x, y, quadrant_width, quadrant_height,
            fill=lighten(color, 0.91), line="none",
        )

        using_swot_key = semantic in normalized
        title = str(data.get("title") or _TITLES.get(semantic if using_swot_key else probability) or "")
        prefix = f"{semantic[0].upper()}  " if using_swot_key else ""
        content_x = x + int(0.20 * EMU_PER_INCH)
        content_width = quadrant_width - int(0.40 * EMU_PER_INCH)
        title_y = y + int(0.15 * EMU_PER_INCH)
        builder.text(
            "title", f"{prefix}{title}", content_x, title_y,
            content_width, int(0.34 * EMU_PER_INCH), size=14,
            color=darken(color, 0.25), bold=True, font=builder.style.fonts.header,
        )

        items = list(data.get("items", []))[:5]
        if not items:
            continue
        content_y = y + int(0.62 * EMU_PER_INCH)
        bottom_padding = int(0.16 * EMU_PER_INCH)
        available = max(y + quadrant_height - bottom_padding - content_y, 1)
        gap = max(0, to_emu(item_gap))
        if len(items) > 1:
            gap = min(gap, available // (len(items) - 1))
        item_height = min(
            int(0.36 * EMU_PER_INCH),
            max(int(0.20 * EMU_PER_INCH), (available - gap * (len(items) - 1)) // len(items)),
        )
        for index, item in enumerate(items):
            builder.text(
                "item", f"•  {item}", content_x,
                content_y + index * (item_height + gap),
                content_width, item_height, size=10.5,
                color=palette.on_bg, valign="center",
            )

    builder.shape(
        "matrix-border", matrix_x, matrix_y, matrix_width, matrix_height,
        fill="none", line=divider,
    )
    builder.line_segment(
        "divider-vertical",
        (matrix_x + cell_width, matrix_y),
        (matrix_x + cell_width, matrix_y + matrix_height),
        color=divider_color, width_pt=1.1,
    )
    builder.line_segment(
        "divider-horizontal",
        (matrix_x, matrix_y + cell_height),
        (matrix_x + matrix_width, matrix_y + cell_height),
        color=divider_color, width_pt=1.1,
    )
    return builder.commands


def _normalize(quadrants: Mapping[str, Any] | Sequence[Any]) -> dict[str, dict[str, Any]]:
    if isinstance(quadrants, Mapping):
        output: dict[str, dict[str, Any]] = {}
        for key, value in quadrants.items():
            if isinstance(value, Mapping):
                output[key] = {"title": value.get("title"), "items": list(value.get("items", []))}
            else:
                output[key] = {"title": _TITLES.get(key), "items": list(value or [])}
        return output
    keys = ("highHigh", "highLow", "lowHigh", "lowLow")
    return {
        key: ({"title": value.get("title"), "items": list(value.get("items", []))} if isinstance(value, Mapping) else {"title": _TITLES[key], "items": list(value or [])})
        for key, value in zip(keys, quadrants)
    }
