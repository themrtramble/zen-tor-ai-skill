"""Native OfficeCLI table with explicit cell styles and three horizontal rules."""

from __future__ import annotations

from math import ceil, isfinite
from typing import Any, Mapping, Sequence

from ._base import ComponentBuilder, blend, contrast_color, emu, parse_box, to_emu
from .helpers import Style
from ._text import text_metrics


def _default_alignment(values: Sequence[Any]) -> str:
    present = [str(value).strip() for value in values
               if value is not None and str(value).strip() not in {"", "-", "–", "—"}]
    try:
        numeric = all(isfinite(float(value.removesuffix("%").replace(",", "").replace("−", "-")))
                      for value in present)
    except ValueError:
        numeric = False
    return "right" if present and numeric else "left"


def _automatic_widths(values: list[list[str]], width: int, font: str,
                      font_size: float, inset: int, emphasis_rows: Sequence[int]) -> list[int]:
    """Allocate between measured minimum-content and maximum-content widths."""
    minimum, natural = [], []
    for column in range(len(values[0])):
        minimum_points = font_size
        natural_points = font_size
        for row, cells in enumerate(values):
            text = cells[column]
            bold = row == 0 or row in emphasis_rows
            measure = lambda value: text_metrics(value, font, font_size, 100000, bold=bold)[1]
            natural_points = max(natural_points, measure(text))
            minimum_points = max(minimum_points, *(measure(word) for word in text.split()), font_size)
        minimum.append(to_emu(f"{minimum_points + 2:g}pt") + 2 * inset)
        natural.append(to_emu(f"{natural_points + 2:g}pt") + 2 * inset)
    if sum(natural) <= width:
        weights = [value + (width - sum(natural)) / len(natural) for value in natural]
    elif sum(minimum) < width:
        fraction = (width - sum(minimum)) / (sum(natural) - sum(minimum))
        weights = [low + fraction * (high - low) for low, high in zip(minimum, natural)]
    else:
        weights = [width * value / sum(minimum) for value in minimum]
    widths = [int(value) for value in weights]
    widths[-1] += width - sum(widths)
    return widths


def add_table(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    headers: Sequence[str],
    rows: Sequence[Sequence[Any]],
    style: Style | Mapping[str, Any],
    *,
    column_widths: Sequence[int | float | str] | None = None,
    alignments: Sequence[str] | None = None,
    emphasis_rows: Sequence[int] = (),
    font_size: float = 14,
    padding: int | float | str = "0.12cm",
    name: str | None = None,
) -> list[dict[str, Any]]:
    """Return a styled table plan; emphasis_rows numbers body rows from one.

    Omitted column widths are measured from cell contents and fit size[0].
    Explicit widths must sum to size[0]. Cell text is set directly so commas,
    semicolons, quotes and newlines are preserved without CSV encoding.
    The function neither writes files nor runs OfficeCLI.
    """
    ox, oy, width, height = parse_box(origin, size)
    columns = len(headers)
    if not columns or any(len(row) != columns for row in rows):
        raise ValueError("headers and every body row must have the same nonzero column count")
    if not isfinite(font_size) or font_size <= 0 or to_emu(padding) < 0:
        raise ValueError("font_size must be positive and padding must not be negative")
    builder = ComponentBuilder(slide, "table", style, name=name)
    values_by_row = [["" if value is None else str(value) for value in row] for row in [headers, *rows]]
    inset = to_emu(padding)
    widths = ([to_emu(value) for value in column_widths] if column_widths is not None else
              _automatic_widths(values_by_row, width, builder.style.fonts.body, font_size, inset, emphasis_rows))
    if len(widths) != columns or any(value <= 0 for value in widths):
        raise ValueError("column_widths must contain one positive width per column")
    if abs(sum(widths) - width) > 1:
        raise ValueError("column_widths must sum to the table width")
    alignments = list(alignments) if alignments is not None else [
        _default_alignment([row[column] for row in rows]) for column in range(columns)
    ]
    if len(alignments) != columns or any(value not in {"left", "center", "right"} for value in alignments):
        raise ValueError("alignments must contain left, center or right for each column")
    if any(index < 1 or index > len(rows) for index in emphasis_rows):
        raise ValueError("emphasis_rows must refer to existing body rows, numbered from one")
    palette = builder.style.palette
    table = f"{slide}/table[@name={builder.component}]"
    row_count = len(rows) + 1
    lines = [max(text_metrics(
        value, builder.style.fonts.body, font_size, (cell_width - 2 * inset) / 12700,
        bold=(index == 0 or index in emphasis_rows),
    )[0] for value, cell_width in zip(values, widths)) for index, values in enumerate(values_by_row)]
    # Fixed point spacing plus padding/rules. Uniform rows let wrapped cells
    # expand the rendered table below its declared frame and into its caption.
    minimum_heights = [to_emu(f"{count * font_size * 1.5 + 2:g}pt") + 2 * inset for count in lines]
    required_height = sum(minimum_heights)
    if height < required_height:
        minimum_cm = ceil(required_height / 360000 * 100) / 100
        raise ValueError(
            f"table height cannot fit {row_count} rows at {font_size:g}pt with padding {emu(padding)}; "
            f"use at least {minimum_cm:.2f}cm height or widen the wrapped columns; "
            f"measured lines per row: {lines}. Move the caption below the new table region."
        )
    extra, remainder = divmod(height - required_height, row_count)
    heights = [minimum + extra + int(index < remainder) for index, minimum in enumerate(minimum_heights)]
    commands = [{"command": "add", "path": slide, "type": "table", "props": {
        "name": builder.component, "rows": row_count, "cols": columns,
        "x": emu(ox), "y": emu(oy), "width": emu(width), "height": emu(height),
        "colWidths": ",".join(emu(value) for value in widths),
        "rowHeight": emu(height / row_count),
        "style": "none", "firstRow": False, "bandedRows": False, "border.all": "none",
    }}]
    rule = f"1pt solid {palette.primary}"
    body = {
        "font": builder.style.fonts.body, "size": f"{font_size:g}pt",
        "color": palette.on_bg, "fill": palette.bg, "bold": False,
        "valign": "center", "padding": emu(padding), "linespacing": f"{font_size * 1.5:g}pt",
    }
    header = {
        "fill": palette.primary,
        "color": contrast_color(palette.primary, palette.bg, palette.on_bg),
        "bold": True, "border.bottom": rule,
    }
    emphasis = {"fill": blend(palette.bg, palette.accent, 0.12), "bold": True}
    for row_number, values in enumerate(values_by_row, start=1):
        for column, value in enumerate(values, start=1):
            props = {"text": value, **body, "align": alignments[column - 1]}
            if row_number == 1:
                props.update(header)
                props["align"] = "left" if alignments[column - 1] == "left" else "center"
            elif row_number - 1 in emphasis_rows:
                props.update(emphasis)
            commands.append({"command": "set", "path": f"{table}/tr[{row_number}]/tc[{column}]", "props": props})
        commands.append({"command": "set", "path": f"{table}/tr[{row_number}]", "props": {"height": emu(heights[row_number - 1])}})
    commands.append({"command": "set", "path": table, "props": {"border.top": rule, "border.bottom": rule}})
    return commands
