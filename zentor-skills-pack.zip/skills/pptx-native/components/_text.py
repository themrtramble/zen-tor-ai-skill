"""Measure text with the Sandbox's installed fonts at 72 dpi."""

from __future__ import annotations

from functools import lru_cache


@lru_cache(maxsize=1024)
def text_metrics(text: str, font: str, size: float, width: float, bold: bool = False) -> tuple[int, float]:
    """Return wrapped line count and occupied width in points, using Pango."""
    if width <= 0:
        raise ValueError("text width must exceed its padding")
    import gi
    gi.require_version("Gio", "2.0")
    gi.require_version("Pango", "1.0")
    gi.require_version("PangoCairo", "1.0")
    # Register Gio overrides before font-map initialization. Otherwise the
    # system PyGObject can fail to import GdkPixbuf later in the same process.
    from gi.repository import Gio, Pango, PangoCairo

    context = PangoCairo.FontMap.get_default().create_context()
    PangoCairo.context_set_resolution(context, 72)
    layout = Pango.Layout.new(context)
    # Match the installed fallback used by OfficeCLI's HTML preview.
    # Otherwise symbols can measure narrower here than in the browser.
    families = f"{font}, Noto Sans CJK SC"
    layout.set_font_description(Pango.FontDescription(f"{families} {'Bold' if bold else 'Regular'} {size:g}"))
    layout.set_width(max(1, int(width * Pango.SCALE)))
    layout.set_wrap(Pango.WrapMode.WORD_CHAR)
    layout.set_text(text, -1)
    return layout.get_line_count(), layout.get_size()[0] / Pango.SCALE


def _officecli_metrics(text: str, size: float, width: float) -> tuple[int, float]:
    """Return estimated lines and unwrapped width for OfficeCLI 1.0.143."""
    # CheckTextOverflow uses 0.55 em per UTF-16 character, or 1 em in these
    # ranges (Core/ParseHelpers.cs). Keep this as a lower bound, not a font metric.
    wide = ((0x3000, 0x312F), (0x3400, 0x4DBF), (0x4E00, 0x9FFF),
            (0xAC00, 0xD7AF), (0xF900, 0xFAFF), (0xFF01, 0xFF60))
    lines, maximum = 0, 0.0
    for segment in text.split("\n"):
        lines += 1
        occupied, unwrapped = 0.0, 0.0
        for char in segment:
            code = ord(char)
            advance = size if code == 0x2014 or any(low <= code <= high for low, high in wide) else size * 0.55
            for _ in range(2 if code > 0xFFFF else 1):
                if occupied > 0 and occupied + advance > width:
                    lines += 1
                    occupied = 0.0
                occupied += advance
                unwrapped += advance
        maximum = max(maximum, unwrapped)
    return lines, maximum


def label_width(text: str, font: str, size: float, width: float, bold: bool = False) -> float:
    """Keep real glyph width and OfficeCLI's conservative check in bounds."""
    _, occupied = text_metrics(text, font, size, width, bold)
    _, estimate = _officecli_metrics(text, size, width)
    return max(occupied, estimate) + 2


def text_height(text: str, font: str, size: float, width: float,
                line_spacing: float, bold: bool = False) -> tuple[int, float]:
    """Return wrapped line count and minimum height, excluding padding."""
    actual_lines, _ = text_metrics(text, font, size, width, bold)
    estimated_lines, _ = _officecli_metrics(text, size, width)
    lines = max(actual_lines, estimated_lines)
    return lines, lines * line_spacing
