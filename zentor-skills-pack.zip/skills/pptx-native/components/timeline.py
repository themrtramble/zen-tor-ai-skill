"""Curved roadmap timeline with an SVG road and editable OfficeCLI content."""

from __future__ import annotations

import base64
from typing import Any, Mapping

from ._base import EMU_PER_INCH, ComponentBuilder, contrast_color, darken, lighten, line_spec, parse_box
from .helpers import normalize_color


def add_timeline(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    phases: list[Mapping[str, Any]],
    style,
    *,
    boundary_dates: list[str] | None = None,
    title: str | None = None,
    name: str | None = None,
) -> list[dict[str, Any]]:
    """Return a curved roadmap with an SVG road and native milestone content."""
    if not phases:
        return []
    if len(phases) > 6:
        raise ValueError("timeline supports at most 6 phases")
    if boundary_dates is not None and len(boundary_dates) != len(phases) + 1:
        raise ValueError("boundary_dates must contain len(phases) + 1 labels")

    ox, oy, width, height = parse_box(origin, size)
    builder = ComponentBuilder(slide, "timeline", style, name=name)
    palette = builder.style.palette
    title_height = int(0.50 * EMU_PER_INCH) if title else 0
    if title:
        builder.text(
            "heading",
            title,
            ox,
            oy,
            width,
            title_height,
            size=24,
            color=palette.on_bg,
            font=builder.style.fonts.header,
            bold=True,
            valign="center",
        )

    body_y = oy + title_height
    body_height = height - title_height
    road_margin_x = int(0.46 * EMU_PER_INCH)
    road_margin_y = int(0.14 * EMU_PER_INCH)
    road_x = ox + road_margin_x
    road_y = body_y + road_margin_y
    road_width = width - road_margin_x * 2
    road_height = body_height - road_margin_y * 2
    points = _road_points(len(phases) + 1, road_width, road_height)

    builder.picture(
        "road",
        _road_svg_data_uri(points, road_width, road_height, darken(palette.muted, 0.30), lighten(palette.muted, 0.34)),
        road_x,
        road_y,
        road_width,
        road_height,
        alt="Curved roadmap",
        zorder="back",
    )

    marker_size = int(0.38 * EMU_PER_INCH)
    start_x, start_y = points[0]
    start_cx = road_x + start_x
    start_cy = road_y + start_y
    builder.shape(
        "start-marker",
        start_cx - marker_size // 2,
        start_cy - marker_size // 2,
        marker_size,
        marker_size,
        geometry="ellipse",
        fill=palette.accent,
        line=line_spec(palette.bg, 2),
        text="起",
        size=10,
        color=palette.bg,
        bold=True,
        align="center",
        valign="center",
        margin=0,
    )
    if boundary_dates:
        _add_date_label(builder, boundary_dates[0], start_cx, start_cy, road_y, road_height)

    card_width = min(int(2.55 * EMU_PER_INCH), max(int(1.75 * EMU_PER_INCH), road_width // len(phases) - int(0.24 * EMU_PER_INCH)))
    card_height = min(int(1.50 * EMU_PER_INCH), max(int(1.18 * EMU_PER_INCH), road_height * 31 // 100))
    card_gap = int(0.24 * EMU_PER_INCH)
    card_padding = int(0.12 * EMU_PER_INCH)

    for index, phase in enumerate(phases):
        colors = _phase_colors(
            phase,
            palette,
            palette.primary if index < len(phases) - 1 else palette.accent,
        )
        point_x, point_y = points[index + 1]
        center_x = road_x + point_x
        center_y = road_y + point_y
        place_below = point_y < road_height * 0.5
        card_x = max(ox, min(center_x - card_width // 2, ox + width - card_width))
        if place_below:
            card_y = center_y + marker_size // 2 + card_gap
            stem_start = center_y + marker_size // 2
            stem_end = card_y
        else:
            card_y = center_y - marker_size // 2 - card_gap - card_height
            stem_start = card_y + card_height
            stem_end = center_y - marker_size // 2
        card_y = max(body_y, min(card_y, body_y + body_height - card_height))
        builder.line_segment(
            "milestone-stem",
            (center_x, min(stem_start, stem_end)),
            (center_x, max(stem_start, stem_end)),
            color=colors["accent"],
            width_pt=1.2,
        )
        builder.shape(
            "card",
            card_x,
            card_y,
            card_width,
            card_height,
            geometry="roundRect",
            fill=colors["fill"],
            line=line_spec(colors["border"], 0.9),
        )
        builder.shape(
            "milestone-marker",
            center_x - marker_size // 2,
            center_y - marker_size // 2,
            marker_size,
            marker_size,
            geometry="ellipse",
            fill=colors["accent"],
            line=line_spec(palette.bg, 2),
            text=str(index + 1),
            size=10,
            color=colors["marker_text"],
            bold=True,
            align="center",
            valign="center",
            margin=0,
        )
        _add_phase_card(
            builder,
            phase,
            boundary_dates[index + 1] if boundary_dates else None,
            card_x + card_padding,
            card_y + int(0.10 * EMU_PER_INCH),
            card_width - card_padding * 2,
            card_height - int(0.18 * EMU_PER_INCH),
            colors,
        )
    return builder.commands


def _phase_colors(phase: Mapping[str, Any], palette, default_accent: str) -> dict[str, str]:
    """Resolve one phase's semantic colors with palette-based fallbacks."""
    custom = phase.get("colors", {})
    if not isinstance(custom, Mapping):
        raise TypeError("phase colors must be a mapping")
    fill = normalize_color(custom.get("fill", palette.bg))
    accent = normalize_color(custom.get("accent", default_accent))
    return {
        "fill": fill,
        "border": normalize_color(custom.get("border", lighten(palette.secondary, 0.18))),
        "text": normalize_color(custom.get("text", contrast_color(fill, palette.bg, palette.on_bg))),
        "accent": accent,
        "marker_text": contrast_color(accent, palette.bg, palette.on_bg),
    }


def _road_points(count: int, width: int, height: int) -> list[tuple[int, int]]:
    """Distribute up to seven points over a consistent alternating S-curve."""
    y_positions = (0.56, 0.27, 0.68, 0.34, 0.66, 0.29, 0.55)
    inset = min(int(0.28 * EMU_PER_INCH), width // 16)
    span = width - inset * 2
    return [
        (inset + round(span * index / (count - 1)), round(height * y_positions[index]))
        for index in range(count)
    ]


def _road_svg_data_uri(points: list[tuple[int, int]], width: int, height: int, road: str, border: str) -> str:
    """Create a scalable road image without embedding presentation text."""
    svg_width = 1200.0
    svg_height = 600.0
    scaled = [(x / width * svg_width, y / height * svg_height) for x, y in points]
    path = _catmull_rom_path(scaled)
    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{svg_width:g}" height="{svg_height:g}" '
        f'viewBox="0 0 {svg_width:g} {svg_height:g}">'
        f'<path d="{path}" fill="none" stroke="#{border}" stroke-width="62" stroke-linecap="round" stroke-linejoin="round"/>'
        f'<path d="{path}" fill="none" stroke="#{road}" stroke-width="52" stroke-linecap="round" stroke-linejoin="round"/>'
        f'<path d="{path}" fill="none" stroke="#FFFFFF" stroke-width="4" stroke-dasharray="18 15" stroke-linecap="round"/>'
        '</svg>'
    )
    encoded = base64.b64encode(svg.encode("utf-8")).decode("ascii")
    return f"data:image/svg+xml;base64,{encoded}"


def _catmull_rom_path(points: list[tuple[float, float]]) -> str:
    if len(points) < 2:
        raise ValueError("road requires at least two points")
    commands = [f"M {points[0][0]:.2f} {points[0][1]:.2f}"]
    for index in range(len(points) - 1):
        p0 = points[index - 1] if index > 0 else points[index]
        p1 = points[index]
        p2 = points[index + 1]
        p3 = points[index + 2] if index + 2 < len(points) else p2
        c1 = (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6)
        c2 = (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6)
        commands.append(
            f"C {c1[0]:.2f} {c1[1]:.2f}, {c2[0]:.2f} {c2[1]:.2f}, {p2[0]:.2f} {p2[1]:.2f}"
        )
    return " ".join(commands)


def _add_date_label(builder: ComponentBuilder, text: str, center_x: int, center_y: int, road_y: int, road_height: int) -> None:
    label_width = int(0.95 * EMU_PER_INCH)
    label_height = int(0.24 * EMU_PER_INCH)
    y = center_y - int(0.48 * EMU_PER_INCH) if center_y >= road_y + road_height * 0.5 else center_y + int(0.28 * EMU_PER_INCH)
    builder.text(
        "date",
        str(text),
        center_x - label_width // 2,
        y,
        label_width,
        label_height,
        size=8.5,
        color=builder.style.palette.muted,
        bold=True,
        align="center",
        valign="center",
    )


def _add_phase_card(
    builder: ComponentBuilder,
    phase: Mapping[str, Any],
    date: str | None,
    x: int,
    y: int,
    width: int,
    height: int,
    colors: Mapping[str, str],
) -> None:
    kicker = " · ".join(str(value) for value in (date, phase.get("label") or phase.get("duration")) if value)
    cursor_y = y
    if kicker:
        builder.text("kicker", kicker.upper(), x, cursor_y, width, int(0.20 * EMU_PER_INCH), size=8, color=colors["accent"], bold=True)
        cursor_y += int(0.20 * EMU_PER_INCH)
    builder.text(
        "title",
        str(phase.get("title", "")),
        x,
        cursor_y,
        width,
        int(0.28 * EMU_PER_INCH),
        size=11.5,
        color=colors["text"],
        font=builder.style.fonts.header,
        bold=True,
        valign="center",
    )
    cursor_y += int(0.29 * EMU_PER_INCH)
    items = [str(item) for item in phase.get("deliverables", [])[:3]]
    if items:
        item_height = max(int(0.28 * EMU_PER_INCH), height - (cursor_y - y) - int(0.30 * EMU_PER_INCH))
        builder.text("deliverables", "  •  ".join(items), x, cursor_y, width, item_height, size=8.5, color=colors["text"], valign="top")
    if phase.get("exit_gate"):
        builder.text(
            "outcome",
            f"→ {phase['exit_gate']}",
            x,
            y + height - int(0.23 * EMU_PER_INCH),
            width,
            int(0.23 * EMU_PER_INCH),
            size=8,
            color=colors["accent"],
            bold=True,
            valign="bottom",
        )
