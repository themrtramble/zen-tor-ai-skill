"""OfficeCLI Gantt chart with planned and actual task bars."""

from __future__ import annotations

from typing import Any, Mapping

from ._base import EMU_PER_INCH, ComponentBuilder, darken, lighten, line_spec, parse_box


def add_gantt(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    style,
    *,
    columns: list[str] | None = None,
    groups: list[Mapping[str, Any]] | None = None,
    tasks: list[Mapping[str, Any]] | None = None,
    variant: str = "grouped",
    legend: bool = True,
    legend_labels: tuple[str, str] = ("Actual", "Planned"),
    name: str | None = None,
) -> list[dict[str, Any]]:
    """Return OfficeCLI commands for a grouped or flat Gantt component."""
    ox, oy, width, height = parse_box(origin, size)
    builder = ComponentBuilder(slide, "gantt", style, name=name)
    palette = builder.style.palette
    columns = columns or [f"{index + 1}月" for index in range(12)]
    if len(columns) < 2:
        raise ValueError("gantt requires at least two columns")
    grouped = variant != "ungrouped" and bool(groups)
    flat: list[tuple[Mapping[str, Any] | None, Mapping[str, Any]]] = []
    if grouped:
        for group in groups or []:
            flat.extend((group, task) for task in group.get("tasks", []))
    else:
        flat.extend((None, task) for task in tasks or [])
    if not flat:
        return []

    header_height = int(0.44 * EMU_PER_INCH)
    legend_height = int(0.24 * EMU_PER_INCH) if legend else 0
    body_y = oy + header_height
    body_height = height - header_height - legend_height
    rail_width = min(int(1.75 * EMU_PER_INCH), int(width * 0.22)) if grouped else 0
    chart_x = ox + rail_width
    chart_width = width - rail_width
    column_width = chart_width // len(columns)
    row_height = body_height // len(flat)

    for index, label in enumerate(columns):
        cap_width = int(column_width * 0.72)
        builder.shape(
            "column", chart_x + index * column_width + (column_width - cap_width) // 2, oy,
            cap_width, header_height - int(0.08 * EMU_PER_INCH), fill=lighten(palette.muted, 0.72), line="none",
            text=str(label), size=9.5, color=palette.on_bg, bold=True, align="center", valign="center", margin=int(0.04 * EMU_PER_INCH),
        )
    for index in range(len(columns) + 1):
        x = chart_x + index * column_width
        builder.line_segment("grid", (x, body_y), (x, body_y + body_height), color=lighten(palette.muted, 0.62), width_pt=0.5, zorder="bottom")

    if grouped:
        cursor = 0
        for group in groups or []:
            count = len(group.get("tasks", []))
            if not count:
                continue
            y = body_y + cursor * row_height
            group_height = count * row_height
            builder.shape("group-rail", ox, y, rail_width - int(0.10 * EMU_PER_INCH), group_height, fill=lighten(palette.primary, 0.85), line=line_spec(lighten(palette.primary, 0.60), 0.5))
            builder.text("group-title", str(group.get("label", "")), ox + int(0.12 * EMU_PER_INCH), y + int(0.08 * EMU_PER_INCH), rail_width - int(0.34 * EMU_PER_INCH), int(0.25 * EMU_PER_INCH), size=10.5, color=palette.primary, bold=True, font=builder.style.fonts.header)
            if group.get("desc"):
                builder.text("group-desc", str(group["desc"]), ox + int(0.12 * EMU_PER_INCH), y + int(0.33 * EMU_PER_INCH), rail_width - int(0.34 * EMU_PER_INCH), max(group_height - int(0.40 * EMU_PER_INCH), int(0.15 * EMU_PER_INCH)), size=8.5, color=palette.muted)
            cursor += count

    planned_height = max(int(row_height * 0.22), int(0.06 * EMU_PER_INCH))
    actual_height = planned_height
    for index, (_, task) in enumerate(flat):
        row_y = body_y + index * row_height
        planned_start, planned_end = task.get("plannedStart"), task.get("plannedEnd")
        actual_start, actual_end = task.get("actualStart"), task.get("actualEnd")
        if all(value is None for value in (planned_start, planned_end, actual_start, actual_end)):
            planned_start, planned_end = task.get("start"), task.get("end")
            actual_start, actual_end = planned_start, planned_end
        if planned_start is not None and planned_end is not None and planned_end >= planned_start:
            x = chart_x + column_width * (int(planned_start) - 1)
            bar_width = max(column_width * (int(planned_end) - int(planned_start) + 1), int(0.10 * EMU_PER_INCH))
            builder.shape("planned", x, row_y + int(row_height * 0.38), bar_width, planned_height, fill=lighten(palette.primary, 0.62), line="none")
        if actual_start is not None and actual_end is not None and actual_end >= actual_start:
            x = chart_x + column_width * (int(actual_start) - 1)
            bar_width = max(column_width * (int(actual_end) - int(actual_start) + 1), int(0.10 * EMU_PER_INCH))
            color = darken(palette.primary, 0.25) if task.get("tone") == "dark" else lighten(palette.primary, 0.2) if task.get("tone") == "soft" else palette.primary
            builder.shape("actual", x, row_y + int(row_height * 0.64), bar_width, actual_height, fill=color, line="none")
            if task.get("value"):
                builder.text("bar-value", str(task["value"]), x + int(0.06 * EMU_PER_INCH), row_y + int(row_height * 0.62), bar_width - int(0.12 * EMU_PER_INCH), actual_height + int(0.04 * EMU_PER_INCH), size=8, color=palette.bg, bold=True, valign="center")
        builder.text("task-label", str(task.get("label", "")), chart_x + int(0.03 * EMU_PER_INCH), row_y + int(0.03 * EMU_PER_INCH), min(int(2.5 * EMU_PER_INCH), chart_width), int(0.20 * EMU_PER_INCH), size=9.5, color=palette.on_bg)

    if legend:
        legend_y = oy + height - legend_height
        swatch = int(0.14 * EMU_PER_INCH)
        for index, (label, color) in enumerate(((legend_labels[0], palette.primary), (legend_labels[1], lighten(palette.primary, 0.62)))):
            x = chart_x + index * int(1.25 * EMU_PER_INCH)
            builder.shape("legend-swatch", x, legend_y + int(0.04 * EMU_PER_INCH), swatch, swatch, fill=color, line="none")
            builder.text("legend-label", label, x + swatch + int(0.05 * EMU_PER_INCH), legend_y, int(0.95 * EMU_PER_INCH), legend_height, size=8.5, color=palette.muted, valign="center")
    return builder.commands
