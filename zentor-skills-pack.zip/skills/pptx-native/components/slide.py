"""Native titles and text with explicit OfficeCLI typography."""

from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Any, Mapping

from ._base import emu, parse_box, to_emu
from ._text import label_width, text_height
from .helpers import Style, coerce_style


def add_text(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    text: str,
    style: Style | Mapping[str, Any],
    *,
    font_size: float = 18,
    font: str | None = None,
    color: str | None = None,
    bold: bool = False,
    align: str = "left",
    valign: str = "top",
    padding: str = "0.1cm",
    line_spacing: float | None = None,
    bullets: bool = False,
    fit_width: bool | None = None,
    fit_height: bool | None = None,
    name: str = "text",
) -> list[dict[str, Any]]:
    """Return one text command; line_spacing is a point value, never a multiplier."""
    if not re.fullmatch(r"/slide\[[1-9][0-9]*\]", slide):
        raise ValueError("slide must be a path such as '/slide[1]'")
    if not math.isfinite(font_size) or font_size <= 0:
        raise ValueError("font_size must be a positive point value")
    spacing = font_size * 1.25 if line_spacing is None else line_spacing
    if not math.isfinite(spacing) or spacing <= 0:
        raise ValueError("line_spacing must be a positive point value")
    if spacing < font_size:
        raise ValueError(
            f"line_spacing is an absolute point value and must be at least {font_size:g}pt "
            f"for {font_size:g}pt text; omit it for the default {font_size * 1.25:g}pt spacing. "
            "Enlarge the text region instead of compressing lines."
        )
    selected = coerce_style(style)
    x, y, width, height = parse_box(origin, size)
    inset = to_emu(padding)
    if inset < 0 or width <= 2 * inset:
        raise ValueError("padding must be non-negative and leave a positive text width")
    if fit_width is None:
        fit_width = not bullets
    if fit_height is None:
        fit_height = not bullets
    if fit_height and bullets:
        raise ValueError("fit_height is for plain text, not bullet lists")
    if fit_width:
        if bullets:
            raise ValueError("fit_width is for labels and captions, not bullet lists")
        occupied = label_width(text, font or selected.fonts.body, font_size,
                               (width - 2 * inset) / 12700, bold)
        fitted = min(width, to_emu(f"{occupied:g}pt") + 2 * inset)
        if align == "center":
            x += (width - fitted) // 2
        elif align == "right":
            x += width - fitted
        width = fitted
    if text:
        lines, minimum = text_height(text, font or selected.fonts.body, font_size,
                                     (width - 2 * inset) / 12700, spacing, bold)
        required = to_emu(f"{minimum:g}pt") + 2 * inset
        if height < required:
            minimum_cm = math.ceil(required / 360000 * 100) / 100
            raise ValueError(
                f"text height cannot fit {lines} lines at {font_size:g}pt with "
                f"{spacing:g}pt line spacing; use at least {minimum_cm:.2f}cm height "
                "or widen the wrapping region. Move following elements below the new text region."
            )
        if fit_height:
            if valign == "middle":
                y += (height - required) // 2
            elif valign == "bottom":
                y += height - required
            height = required
    props = {
        "name": name, "text": text,
        "x": emu(x), "y": emu(y), "width": emu(width), "height": emu(height),
        "font": font or selected.fonts.body, "font.ea": font or selected.fonts.body,
        "size": f"{font_size:g}pt", "lineSpacing": f"{spacing:g}pt",
        "color": selected.palette.resolve(color or "on_bg"), "bold": bold,
        "align": align, "valign": valign, "margin": emu(padding),
        "fill": "none", "line": "none",
    }
    if bullets:
        props["list"] = "bullet"
    return [{"command": "add", "path": slide, "type": "shape", "props": props}]


def add_rule(
    slide: str, origin: tuple[Any, Any], size: tuple[Any, Any],
    style: Style | Mapping[str, Any], *, color: str = "primary", name: str = "rule",
) -> list[dict[str, Any]]:
    """Return a native rectangular horizontal or vertical divider."""
    if not re.fullmatch(r"/slide\[[1-9][0-9]*\]", slide):
        raise ValueError("slide must be a path such as '/slide[1]'")
    x, y, width, height = parse_box(origin, size)
    selected = coerce_style(style)
    return [{"command": "add", "path": slide, "type": "shape", "props": {
        "name": name, "geometry": "rect",
        "x": emu(x), "y": emu(y), "width": emu(width), "height": emu(height),
        "fill": selected.palette.resolve(color), "line": "none",
    }}]


def add_titled_slide(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    title: str,
    style: Style | Mapping[str, Any],
    *,
    font_size: float = 28,
    color: str | None = None,
    bold: bool = True,
    line_spacing: float | None = None,
    name: str = "Title",
) -> list[dict[str, Any]]:
    """Append a slide, then style its native title; slide is its planned final path."""
    selected = coerce_style(style)
    title_command = add_text(
        slide, origin, size, title, selected, font_size=font_size,
        font=selected.fonts.header, color=color, bold=bold, padding="0cm",
        line_spacing=line_spacing, fit_width=False, name=name,
    )[0]
    return [
        {"command": "add", "path": "/", "type": "slide",
         "props": {"layout": "blank", "title": title, "background": selected.palette.bg}},
        {"command": "set", "path": f"{slide}/shape[@name=Title]", "props": title_command["props"]},
    ]


def add_picture(
    slide: str, origin: tuple[Any, Any], size: tuple[Any, Any],
    src: str, style: Style | Mapping[str, Any], *, name: str = "picture", alt: str = "",
    target: str | None = None,
) -> list[dict[str, Any]]:
    """Fit a complete image; target refits an existing picture without replacing it."""
    import gi
    gi.require_version("GdkPixbuf", "2.0")
    from gi.repository import GdkPixbuf

    if target is not None and not re.fullmatch(
        re.escape(slide) + r"/picture\[(?:[1-9][0-9]*|@id=[0-9]+)\]", target,
    ):
        raise ValueError("target must identify an existing picture on the specified slide")
    source = Path(src)
    if not source.is_absolute() or not source.is_file():
        raise ValueError("src must be an existing absolute image path")
    image = GdkPixbuf.Pixbuf.new_from_file(str(source))
    x, y, width, height = parse_box(origin, size)
    scale = min(width / image.get_width(), height / image.get_height())
    fitted_width, fitted_height = round(image.get_width() * scale), round(image.get_height() * scale)
    geometry = {
        "x": emu(x + (width - fitted_width) // 2), "y": emu(y + (height - fitted_height) // 2),
        "width": emu(fitted_width), "height": emu(fitted_height),
    }
    if target is not None:
        return [{"command": "set", "path": target, "props": geometry}]
    return [{"command": "add", "path": slide, "type": "picture", "props": {
        "src": str(source), "name": name, "alt": alt, **geometry,
    }}]
