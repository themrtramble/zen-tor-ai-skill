"""OfficeCLI allocation bars for budget, channel, or resource splits."""

from __future__ import annotations

from typing import Any, Mapping

from ._base import EMU_PER_INCH, ComponentBuilder, lighten, parse_box


def add_allocation_bars(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    items: list[Mapping[str, Any]],
    style,
    *,
    title: str | None = None,
    subtitle: str | None = None,
    note: str | None = None,
    name: str | None = None,
) -> list[dict[str, Any]]:
    """Return native OfficeCLI commands for labelled percentage bars."""
    ox, oy, width, height = parse_box(origin, size)
    builder = ComponentBuilder(slide, "allocation-bars", style, name=name)
    palette = builder.style.palette
    fonts = builder.style.fonts
    cursor_y = oy

    if title:
        title_height = int(0.45 * EMU_PER_INCH)
        builder.text("title", title, ox, cursor_y, width, title_height, size=18, bold=True, font=fonts.header)
        cursor_y += title_height
        if subtitle:
            subtitle_height = int(0.28 * EMU_PER_INCH)
            builder.text("subtitle", subtitle, ox, cursor_y, width, subtitle_height, size=11, color=palette.muted)
            cursor_y += subtitle_height
        cursor_y += int(0.08 * EMU_PER_INCH)

    note_height = int(0.35 * EMU_PER_INCH) if note else 0
    bar_area = max(height - (cursor_y - oy) - note_height, EMU_PER_INCH)
    if not items:
        return builder.commands
    row_gap = int(0.10 * EMU_PER_INCH)
    row_height = max((bar_area - row_gap * (len(items) - 1)) // len(items), int(0.42 * EMU_PER_INCH))
    text_height = min(int(0.25 * EMU_PER_INCH), row_height // 2)
    bar_height = max(min(row_height - text_height - int(0.04 * EMU_PER_INCH), int(0.22 * EMU_PER_INCH)), int(0.08 * EMU_PER_INCH))
    label_width = max(int(width * 0.45), int(1.3 * EMU_PER_INCH))
    value_width = max(int(width * 0.25), int(1.0 * EMU_PER_INCH))

    tones = {
        "accent": palette.accent,
        "primary": palette.primary,
        "green": "16A34A",
        "soft": lighten(palette.primary, 0.5),
        "muted": palette.muted,
    }
    for index, item in enumerate(items):
        row_y = cursor_y + index * (row_height + row_gap)
        builder.text("label", str(item.get("label", "")), ox, row_y, label_width, text_height, size=12, bold=True)
        builder.text(
            "value", str(item.get("value", "")), ox + width - value_width, row_y,
            value_width, text_height, size=12, bold=True, color=palette.muted, align="right",
        )
        bar_y = row_y + text_height
        builder.shape(
            "track", ox, bar_y, width, bar_height, geometry="roundRect",
            fill=lighten(palette.muted, 0.75), line="none", adj="adj:val 50000",
        )
        percent = max(0.0, min(100.0, float(item.get("percent", 0))))
        if percent:
            color = item.get("color") or tones.get(str(item.get("tone", "primary")), palette.primary)
            builder.shape(
                "fill", ox, bar_y, max(int(width * percent / 100), 1), bar_height,
                geometry="roundRect", fill=color, line="none", adj="adj:val 50000",
            )

    if note:
        builder.text("note", note, ox, oy + height - note_height, width, note_height, size=10, color=palette.muted, italic=True)
    return builder.commands
