"""OfficeCLI command-plan primitives for composite PowerPoint shapes."""

from __future__ import annotations

import math
import re
import unicodedata
from typing import Any, Iterable, Mapping

from .helpers import Style, coerce_style, normalize_color, smart_quotes

EMU_PER_INCH = 914400
EMU_PER_PT = 12700
EMU_PER_CM = 360000

_LENGTH = re.compile(r"^\s*(-?\d+(?:\.\d+)?)\s*(emu|pt|in|cm)?\s*$", re.IGNORECASE)
_INCREASE_KEYWORDS = ("+", "增长", "提升", "↑", "up", "growth")
_DECREASE_KEYWORDS = ("-", "下降", "下跌", "减少", "↓", "down", "decline")


def to_emu(value: int | float | str) -> int:
    """Convert an OfficeCLI length or a numeric EMU value to EMU."""
    if isinstance(value, (int, float)):
        return int(round(value))
    match = _LENGTH.fullmatch(value)
    if match is None:
        raise ValueError(f"invalid length: {value!r}")
    number = float(match.group(1))
    unit = (match.group(2) or "emu").lower()
    scale = {"emu": 1, "pt": EMU_PER_PT, "in": EMU_PER_INCH, "cm": EMU_PER_CM}[unit]
    return int(round(number * scale))


def emu(value: int | float | str) -> str:
    """Serialize a length as points so OfficeCLI does not infer units."""
    return f"{to_emu(value) / EMU_PER_PT:.3f}pt"


def rgb(color: str) -> tuple[int, int, int]:
    value = normalize_color(color).removeprefix("#")
    if not re.fullmatch(r"[0-9A-Fa-f]{6}", value):
        raise ValueError(f"color must resolve to six-digit RGB: {color!r}")
    return int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16)


def blend(a: str, b: str, fraction: float) -> str:
    fraction = max(0.0, min(1.0, float(fraction)))
    av = rgb(a)
    bv = rgb(b)
    return "".join(f"{int(x + (y - x) * fraction):02X}" for x, y in zip(av, bv))


def lighten(color: str, fraction: float) -> str:
    return blend(color, "FFFFFF", fraction)


def darken(color: str, fraction: float) -> str:
    return blend(color, "000000", fraction)


def contrast_color(background: str, light: str, dark: str) -> str:
    """Return whichever candidate has the higher WCAG contrast ratio."""
    background_luminance = _relative_luminance(background)
    candidates = (light, dark)
    return max(
        candidates,
        key=lambda color: _contrast_ratio(background_luminance, _relative_luminance(color)),
    )


def _relative_luminance(color: str) -> float:
    channels = []
    for value in rgb(color):
        normalized = value / 255
        channels.append(normalized / 12.92 if normalized <= 0.04045 else ((normalized + 0.055) / 1.055) ** 2.4)
    return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2]


def _contrast_ratio(first: float, second: float) -> float:
    lighter, darker = max(first, second), min(first, second)
    return (lighter + 0.05) / (darker + 0.05)


def depth_ramp(base: str, count: int, *, light_first: bool = True) -> list[str]:
    if count <= 0:
        return []
    if count == 1:
        return [normalize_color(base)]
    colors: list[str] = []
    for index in range(count):
        position = index / (count - 1)
        light_fraction = (1 - position) * 0.35 if light_first else position * 0.35
        dark_fraction = position * 0.20 if light_first else (1 - position) * 0.20
        colors.append(lighten(base, light_fraction) if light_fraction > dark_fraction else darken(base, dark_fraction))
    return colors


def col_edges(origin: int, width: int, count: int) -> list[int]:
    if count <= 0:
        return [origin]
    return [origin + round(index * width / count) for index in range(count + 1)]


def auto_delta_color(text: str) -> str | None:
    lower = (text or "").lower()
    increase = any(token in lower or token in text for token in _INCREASE_KEYWORDS)
    decrease = any(token in lower or token in text for token in _DECREASE_KEYWORDS)
    if increase and not decrease:
        return "16A34A"
    if decrease and not increase:
        return "DC2626"
    return None


class ComponentBuilder:
    """Create named, replayable OfficeCLI add commands for one component."""

    def __init__(self, slide: str, component: str, style: Style | Mapping[str, Any], *, name: str | None = None):
        if not isinstance(slide, str) or not slide.startswith("/slide["):
            raise ValueError("slide must be an OfficeCLI stable path such as '/slide[1]'")
        self.slide = slide
        self.component = _slug(name or component)
        self.style = coerce_style(style)
        self.commands: list[dict[str, Any]] = []
        self.paths: list[str] = []
        self._counter = 0

    def _name(self, role: str) -> str:
        self._counter += 1
        return f"{self.component}-{_slug(role)}-{self._counter:02d}"

    def shape(
        self,
        role: str,
        x: int,
        y: int,
        width: int,
        height: int,
        *,
        geometry: str = "rect",
        fill: str = "none",
        line: str = "none",
        opacity: float | None = None,
        text: str | None = None,
        font: str | None = None,
        size: float | None = None,
        color: str | None = None,
        bold: bool | None = None,
        italic: bool | None = None,
        align: str = "left",
        valign: str = "top",
        margin: int | str | None = None,
        rotation: float | None = None,
        auto_fit: str | None = None,
        adj: str | None = None,
        zorder: str | int | None = None,
    ) -> str:
        name = self._name(role)
        props: dict[str, Any] = {
            "name": name,
            "x": emu(x),
            "y": emu(y),
            "width": emu(max(to_emu(width), 1)),
            "height": emu(max(to_emu(height), 1)),
            "geometry": geometry,
            "fill": normalize_color(fill) if fill != "none" else "none",
            "line": line,
            "shadow": "none",
        }
        if opacity is not None:
            props["opacity"] = max(0.0, min(1.0, float(opacity)))
        if text is not None:
            props.update({
                "text": smart_quotes(str(text)),
                "font": font or self.style.fonts.body,
                "font.ea": font or self.style.fonts.body,
                "align": align,
                "valign": valign,
            })
        if size is not None:
            props["size"] = f"{float(size):g}pt"
        if color is not None:
            props["color"] = normalize_color(color)
        if bold is not None:
            props["bold"] = bool(bold)
        if italic is not None:
            props["italic"] = bool(italic)
        if margin is not None:
            props["margin"] = emu(margin)
        if rotation is not None:
            props["rotation"] = f"{float(rotation):g}"
        if auto_fit is not None:
            props["autoFit"] = auto_fit
        if adj is not None:
            props["adj"] = adj
        if zorder is not None:
            props["zorder"] = zorder
        self.commands.append({"command": "add", "parent": self.slide, "type": "shape", "props": props})
        path = f"{self.slide}/shape[@name={name}]"
        self.paths.append(path)
        return path

    def text(
        self,
        role: str,
        text: str,
        x: int,
        y: int,
        width: int,
        height: int,
        *,
        size: float = 12,
        color: str | None = None,
        font: str | None = None,
        bold: bool = False,
        italic: bool = False,
        align: str = "left",
        valign: str = "top",
        margin: int | str = 0,
        auto_fit: str = "shrink",
    ) -> str:
        if "\n" not in text and len(text) <= 50:
            display_units = sum(1.0 if unicodedata.east_asian_width(character) in {"W", "F"} else 0.58 for character in text)
            estimated_width = int((display_units * size * 1.15 + 8) * EMU_PER_PT)
            if estimated_width < width:
                if align == "center":
                    x += (width - estimated_width) // 2
                elif align == "right":
                    x += width - estimated_width
                width = estimated_width
        return self.shape(
            role, x, y, width, height,
            fill="none", line="none", text=text,
            font=font, size=size, color=color or self.style.palette.on_bg,
            bold=bold, italic=italic, align=align, valign=valign,
            margin=margin, auto_fit=auto_fit,
        )

    def line_segment(
        self,
        role: str,
        start: tuple[int, int],
        end: tuple[int, int],
        *,
        color: str,
        width_pt: float = 1.0,
        dash: str = "solid",
        zorder: str | int | None = None,
    ) -> str:
        x1, y1 = start
        x2, y2 = end
        thickness = max(int(round(width_pt * EMU_PER_PT)), 1)
        line = f"{normalize_color(color)}:{width_pt:g}:{dash}"
        if y1 == y2:
            return self.shape(
                role, min(x1, x2), y1 - thickness // 2, max(abs(x2 - x1), 1), thickness,
                fill=normalize_color(color), line=line, zorder=zorder,
            )
        if x1 == x2:
            return self.shape(
                role, x1 - thickness // 2, min(y1, y2), thickness, max(abs(y2 - y1), 1),
                fill=normalize_color(color), line=line, zorder=zorder,
            )
        distance = max(int(round(math.hypot(x2 - x1, y2 - y1))), 1)
        angle = math.degrees(math.atan2(y2 - y1, x2 - x1))
        return self.shape(
            role,
            int(round((x1 + x2 - distance) / 2)),
            int(round((y1 + y2 - thickness) / 2)),
            distance,
            thickness,
            fill=normalize_color(color),
            line=line,
            rotation=angle,
            zorder=zorder,
        )

    def connector(
        self,
        role: str,
        from_path: str,
        to_path: str,
        *,
        color: str,
        width_pt: float = 1.0,
        shape: str = "straight",
        head_end: str = "none",
        tail_end: str = "none",
        from_side: str | None = None,
        to_side: str | None = None,
        zorder: str | int | None = None,
    ) -> str:
        name = self._name(role)
        props: dict[str, Any] = {
            "name": name,
            "from": from_path,
            "to": to_path,
            "shape": shape,
            "color": normalize_color(color),
            "lineWidth": f"{width_pt:g}pt",
            "headEnd": head_end,
            "tailEnd": tail_end,
        }
        if from_side:
            props["fromSide"] = from_side
        if to_side:
            props["toSide"] = to_side
        if zorder is not None:
            props["zorder"] = zorder
        self.commands.append({"command": "add", "parent": self.slide, "type": "connector", "props": props})
        path = f"{self.slide}/connector[@name={name}]"
        self.paths.append(path)
        return path

    def picture(
        self,
        role: str,
        src: str,
        x: int,
        y: int,
        width: int,
        height: int,
        *,
        alt: str | None = None,
        opacity: float | None = None,
        zorder: str | int | None = None,
    ) -> str:
        """Add an OfficeCLI picture command and return its stable name path."""
        name = self._name(role)
        props: dict[str, Any] = {
            "name": name,
            "src": src,
            "x": emu(x),
            "y": emu(y),
            "width": emu(max(to_emu(width), 1)),
            "height": emu(max(to_emu(height), 1)),
        }
        if alt is not None:
            props["alt"] = alt
        if opacity is not None:
            props["opacity"] = max(0.0, min(1.0, float(opacity)))
        if zorder is not None:
            props["zorder"] = zorder
        self.commands.append({"command": "add", "parent": self.slide, "type": "picture", "props": props})
        path = f"{self.slide}/picture[@name={name}]"
        self.paths.append(path)
        return path

    def chart(self, role: str, x: int, y: int, width: int, height: int, **properties: Any) -> str:
        """Add a native OfficeCLI chart command and return its name path."""
        name = self._name(role)
        props: dict[str, Any] = {
            "name": name,
            "x": emu(x),
            "y": emu(y),
            "width": emu(width),
            "height": emu(height),
        }
        props.update(properties)
        self.commands.append({"command": "add", "parent": self.slide, "type": "chart", "props": props})
        path = f"{self.slide}/chart[@name={name}]"
        self.paths.append(path)
        return path

    def group(self, role: str = "group") -> str | None:
        if not self.paths:
            return None
        name = self._name(role)
        props = {"name": name, "shapes": ",".join(self.paths)}
        self.commands.append({"command": "add", "parent": self.slide, "type": "group", "props": props})
        return f"{self.slide}/group[@name={name}]"


def _slug(value: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9_-]+", "-", value.strip()).strip("-")
    return slug or "component"


def parse_box(origin: tuple[Any, Any], size: tuple[Any, Any]) -> tuple[int, int, int, int]:
    ox, oy = (to_emu(value) for value in origin)
    width, height = (to_emu(value) for value in size)
    if width <= 0 or height <= 0:
        raise ValueError("component width and height must be positive")
    return ox, oy, width, height


def line_spec(color: str, width_pt: float = 1.0, dash: str = "solid") -> str:
    return f"{normalize_color(color)}:{width_pt:g}:{dash}"


def combine_text(lines: Iterable[str]) -> str:
    return "\n".join(str(line) for line in lines if str(line).strip())
