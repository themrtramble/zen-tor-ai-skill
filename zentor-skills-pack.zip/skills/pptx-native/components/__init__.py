"""Reusable composite PowerPoint components backed only by OfficeCLI.

Every ``add_*`` function returns a plain ordered command list accepted by
``officecli batch``. Use :func:`apply_commands` to apply one or more lists.
"""

from .allocation_bars import add_allocation_bars
from .chart import add_chart
from .comparison import add_comparison
from .flow_matrix import add_flow_matrix
from .flywheel import add_flywheel
from .funnel import add_funnel
from .gantt import add_gantt
from .helpers import FontPair, Palette, Style, apply_commands, get_slide_count, write_commands
from .layered_diagram import add_layered_diagram
from .metric_card import add_metric_card
from .quote_block import add_quote_block
from .slide import add_picture, add_rule, add_text, add_titled_slide
from .swot import add_swot
from .table import add_table
from .timeline import add_timeline

COMPONENTS = {
    "allocation_bars": add_allocation_bars,
    "chart": add_chart,
    "comparison": add_comparison,
    "flow_matrix": add_flow_matrix,
    "flywheel": add_flywheel,
    "funnel": add_funnel,
    "gantt": add_gantt,
    "layered_diagram": add_layered_diagram,
    "metric_card": add_metric_card,
    "quote_block": add_quote_block,
    "picture": add_picture,
    "rule": add_rule,
    "swot": add_swot,
    "table": add_table,
    "text": add_text,
    "timeline": add_timeline,
}

__all__ = [
    "COMPONENTS",
    "FontPair",
    "Palette",
    "Style",
    "add_allocation_bars",
    "add_chart",
    "add_comparison",
    "add_flow_matrix",
    "add_flywheel",
    "add_funnel",
    "add_gantt",
    "add_layered_diagram",
    "add_metric_card",
    "add_picture",
    "add_quote_block",
    "add_rule",
    "add_swot",
    "add_table",
    "add_text",
    "add_titled_slide",
    "add_timeline",
    "apply_commands",
    "get_slide_count",
    "write_commands",
]
