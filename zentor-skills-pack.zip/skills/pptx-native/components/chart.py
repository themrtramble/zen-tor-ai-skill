"""Native comparison charts with shared typography and separate axis captions."""

from __future__ import annotations

import math
import re
from typing import Any, Mapping, Sequence

from ._base import emu, parse_box, to_emu
from .helpers import Style, coerce_style
from .slide import add_text


def add_chart(
    slide: str, origin: tuple[Any, Any], size: tuple[Any, Any],
    categories: Sequence[str], series: Mapping[str, Sequence[float]],
    category_label: str, value_label: str, style: Style | Mapping[str, Any], *,
    chart_type: str = "column", font_size: float = 12, name: str = "chart",
) -> list[dict[str, Any]]:
    """Build a grouped bar or column chart; all series share the value-axis unit."""
    if not re.fullmatch(r"/slide\[[1-9][0-9]*\]", slide):
        raise ValueError("slide must be a path such as '/slide[1]'")
    if chart_type not in {"bar", "column"}:
        raise ValueError("chart_type must be bar or column; query OfficeCLI for other chart types")
    if not math.isfinite(font_size) or font_size <= 0:
        raise ValueError("font_size must be a positive point value")
    if isinstance(categories, str) or not categories:
        raise ValueError("categories must be a non-empty list of labels")
    if any(not isinstance(label, str) or not label.strip() or "," in label for label in categories):
        raise ValueError("category labels must be non-empty strings without commas")
    if not isinstance(series, Mapping) or not series:
        raise ValueError("series must map names to numeric value lists")
    data = []
    values = []
    for label, numbers in series.items():
        if not isinstance(label, str) or not label.strip() or any(c in label for c in ":;,"):
            raise ValueError("series names must be non-empty strings without colons, semicolons, or commas")
        if isinstance(numbers, str) or len(numbers) != len(categories):
            raise ValueError(f"series {label!r} must contain one value per category")
        if any(isinstance(n, bool) or not isinstance(n, (int, float)) or not math.isfinite(n) for n in numbers):
            raise ValueError(f"series {label!r} must contain finite numbers")
        values.extend(numbers)
        data.append(label + ":" + ",".join(str(n) for n in numbers))
    if not category_label.strip() or not value_label.strip():
        raise ValueError("category_label and value_label must describe both axes, including units")
    selected = coerce_style(style)
    x, y, width, height = parse_box(origin, size)
    x_label, y_label = ((category_label, value_label) if chart_type == "column"
                        else (value_label, category_label))
    caption = add_text(
        slide, (x, y), (width, height),
        f"X: {x_label} | Y: {y_label}", selected, font_size=font_size,
        padding="0cm", align="center", name=f"{name}-axes",
    )
    caption_props = caption[0]["props"]
    caption_height = max(to_emu(f"{font_size * 1.75:g}pt"), to_emu(caption_props["height"]))
    gap = to_emu("0.15cm")
    if height - caption_height - gap < to_emu("4cm"):
        raise ValueError("chart region must leave at least 4cm height above its axis caption")
    palette = selected.palette
    colors = [palette.primary, palette.accent, palette.secondary, palette.muted]
    if len(series) > len(colors):
        raise ValueError("use at most four series per comparison chart")
    typography = f"{font_size:g}:{palette.on_bg}:{selected.fonts.body}"
    props = {
        "name": name, "chartType": chart_type, "title": "none",
        "x": emu(x), "y": emu(y), "width": emu(width),
        "height": emu(height - caption_height - gap),
        "categories": ",".join(categories), "data": ";".join(data),
        "colors": ",".join(colors[:len(series)]),
        "legend": "bottom", "legendFont": typography,
        "axisfont": typography, "labelfont": typography,
        "dataLabels": "outsideEnd", "gapwidth": 90, "overlap": 0,
        "chartFill": palette.bg, "plotFill": palette.bg,
        "chartborder": "none", "plotborder": "none",
        "gridlines": f"{palette.secondary}:0.5",
    }
    if min(values) >= 0:
        props["axismin"] = 0
    caption_props["y"] = emu(y + height - caption_height)
    return [{"command": "add", "path": slide, "type": "chart", "props": props}, *caption]
