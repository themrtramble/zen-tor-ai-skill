"""OfficeCLI quote block for executive messages and strategy callouts."""

from __future__ import annotations

from typing import Any, Mapping

from ._base import EMU_PER_INCH, ComponentBuilder, lighten, parse_box


def add_quote_block(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    content: Mapping[str, Any],
    style,
    *,
    variant: str = "line",
    name: str | None = None,
) -> list[dict[str, Any]]:
    """Return OfficeCLI commands for a line or dark quote component."""
    if "copy" not in content:
        raise ValueError("quote block content requires copy")
    ox, oy, width, height = parse_box(origin, size)
    builder = ComponentBuilder(slide, "quote-block", style, name=name)
    palette = builder.style.palette
    fonts = builder.style.fonts
    dark = variant == "dark"
    narrow = width < height
    background = palette.on_bg if dark else lighten(palette.primary, 0.92)
    text_color = palette.bg if dark else palette.on_bg
    heading_color = palette.bg if dark else palette.primary
    accent = palette.accent if dark else palette.primary
    builder.shape("card", ox, oy, width, height, fill=background, line="none")
    left_pad = int(0.40 * EMU_PER_INCH)
    right_pad = int(0.24 * EMU_PER_INCH)
    if variant == "line":
        builder.shape("rule", ox + int(0.10 * EMU_PER_INCH), oy + int(0.22 * EMU_PER_INCH), int(0.05 * EMU_PER_INCH), height - int(0.44 * EMU_PER_INCH), fill=accent, line="none")
    cursor_y = oy + int(0.22 * EMU_PER_INCH)
    content_width = width - left_pad - right_pad
    if content.get("kicker") and not narrow:
        builder.text("kicker", str(content["kicker"]).upper(), ox + left_pad, cursor_y, content_width, int(0.22 * EMU_PER_INCH), size=10.5, color=accent, bold=True)
        cursor_y += int(0.30 * EMU_PER_INCH)
    if content.get("title"):
        builder.text("title", str(content["title"]), ox + left_pad, cursor_y, content_width, int(0.50 * EMU_PER_INCH), size=19, color=heading_color, bold=True, font=fonts.header)
        cursor_y += int(0.58 * EMU_PER_INCH)
    attribution_height = int(0.55 * EMU_PER_INCH) if content.get("author") or content.get("role") else 0
    copy_height = max(oy + height - int(0.20 * EMU_PER_INCH) - attribution_height - cursor_y, int(0.45 * EMU_PER_INCH))
    builder.text("copy", str(content["copy"]), ox + left_pad, cursor_y, content_width, copy_height, size=15, color=text_color, italic=True, font=fonts.header, valign="center")
    if attribution_height:
        attribution_y = oy + height - attribution_height - int(0.10 * EMU_PER_INCH)
        if content.get("author"):
            builder.text("author", str(content["author"]), ox + left_pad, attribution_y, content_width, int(0.26 * EMU_PER_INCH), size=10.5, color=heading_color, bold=True)
        if content.get("role"):
            builder.text("role", str(content["role"]), ox + left_pad, attribution_y + int(0.25 * EMU_PER_INCH), content_width, int(0.22 * EMU_PER_INCH), size=9.5, color=lighten(text_color, 0.25) if dark else palette.muted)
    return builder.commands
