"""OfficeCLI funnel with caller-controlled step widths."""

from __future__ import annotations

import re
from typing import Any, Mapping

from ._base import EMU_PER_INCH, ComponentBuilder, contrast_color, depth_ramp, lighten, line_spec, parse_box


def add_funnel(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    steps: list[Mapping[str, Any]],
    style,
    *,
    title: str | None = None,
    note: str | None = None,
    orientation: str = "narrow_bottom",
    name: str | None = None,
) -> list[dict[str, Any]]:
    """Return OfficeCLI commands for a top-to-bottom funnel."""
    ox, oy, width, height = parse_box(origin, size)
    builder = ComponentBuilder(slide, "funnel", style, name=name)
    palette = builder.style.palette
    fonts = builder.style.fonts
    if not steps:
        return []
    if orientation not in {"narrow_top", "narrow_bottom"}:
        raise ValueError("orientation must be narrow_top or narrow_bottom")
    title_height = int(0.52 * EMU_PER_INCH) if title else 0
    note_height = int(0.34 * EMU_PER_INCH) if note else 0
    if title:
        builder.text("title", title, ox, oy, width, title_height, size=22, bold=True, font=fonts.header)
    body_y = oy + title_height
    body_height = height - title_height - note_height
    gap = int(0.08 * EMU_PER_INCH)
    available_step_height = (body_height - gap * (len(steps) - 1)) // len(steps)
    step_height = min(available_step_height, int(0.82 * EMU_PER_INCH))
    used_height = step_height * len(steps) + gap * (len(steps) - 1)
    first_y = body_y + max((body_height - used_height) // 2, 0)
    widths = _resolve_widths(steps, orientation)
    ramp = depth_ramp(palette.primary, len(steps))
    if orientation == "narrow_top":
        ramp.reverse()

    for index, (step, width_fraction) in enumerate(zip(steps, widths)):
        segment_width = max(int(width * width_fraction), int(0.30 * EMU_PER_INCH))
        x = ox + (width - segment_width) // 2
        y = first_y + index * (step_height + gap)
        fill = ramp[index]
        text_color = contrast_color(fill, palette.bg, palette.on_bg)
        builder.shape(
            "segment", x, y, segment_width, step_height,
            geometry="roundRect", fill=fill, line=line_spec(lighten(fill, 0.18), 0.5),
            adj="adj:val 8000",
        )
        value_width = min(int(1.15 * EMU_PER_INCH), max(int(segment_width * 0.28), int(0.62 * EMU_PER_INCH)))
        content_x = x + int(0.20 * EMU_PER_INCH)
        content_y = y + int(0.08 * EMU_PER_INCH)
        content_height = max(step_height - int(0.16 * EMU_PER_INCH), int(0.20 * EMU_PER_INCH))
        label_width = max(segment_width - value_width - int(0.46 * EMU_PER_INCH), int(0.45 * EMU_PER_INCH))
        builder.text(
            "label", str(step.get("label", "")), content_x, content_y, label_width, content_height,
            size=12, color=text_color, bold=True, valign="center",
        )
        if step.get("value"):
            builder.text(
                "value", str(step["value"]), x + segment_width - value_width - int(0.20 * EMU_PER_INCH),
                content_y, value_width, content_height, size=16, color=text_color,
                bold=True, font=fonts.header, align="right", valign="center",
            )
    if note:
        builder.text("note", note, ox, oy + height - note_height, width, note_height, size=10, color=palette.muted, italic=True)
    return builder.commands


def _resolve_widths(steps: list[Mapping[str, Any]], orientation: str) -> list[float]:
    supplied = ["width" in step for step in steps]
    if any(supplied) and not all(supplied):
        raise ValueError("funnel steps must either all define width or all omit it")
    if all(supplied):
        widths = [_fraction(step["width"]) for step in steps]
    else:
        values = [_numeric_value(step.get("value")) for step in steps]
        if all(value is not None for value in values) and max(values, default=0) > 0:
            maximum = max(value for value in values if value is not None)
            widths = [max(0.32, value / maximum) for value in values if value is not None]
        elif len(steps) == 1:
            widths = [1.0]
        else:
            widths = [1.0 - 0.48 * index / (len(steps) - 1) for index in range(len(steps))]
            if orientation == "narrow_top":
                widths.reverse()
    pairs = zip(widths, widths[1:])
    valid = all(first <= second + 1e-9 for first, second in pairs) if orientation == "narrow_top" else all(first + 1e-9 >= second for first, second in pairs)
    if not valid:
        direction = "nondecreasing" if orientation == "narrow_top" else "nonincreasing"
        raise ValueError(f"funnel widths must be {direction} for orientation={orientation!r}")
    return widths


def _numeric_value(value: Any) -> float | None:
    if isinstance(value, (int, float)):
        return max(float(value), 0.0)
    if not isinstance(value, str):
        return None
    text = value.strip().replace(",", "")
    if not re.fullmatch(r"\d+(?:\.\d+)?%?", text):
        return None
    return max(float(text.removesuffix("%")), 0.0)


def _fraction(value: Any) -> float:
    if isinstance(value, str):
        text = value.strip()
        try:
            number = float(text.removesuffix("%"))
        except ValueError:
            return 1.0
        value = number / 100 if text.endswith("%") else number
    fraction = float(value)
    if fraction > 1:
        fraction /= 100
    return max(0.05, min(1.0, fraction))
