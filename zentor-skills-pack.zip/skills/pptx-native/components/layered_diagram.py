"""OfficeCLI bottom-aligned concentric-circle layered diagram."""

from __future__ import annotations

from typing import Any, Mapping

from ._base import EMU_PER_INCH, ComponentBuilder, darken, depth_ramp, parse_box


def add_layered_diagram(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    layers: list[Mapping[str, Any]],
    style,
    *,
    title: str | None = None,
    desc: str | None = None,
    name: str | None = None,
) -> list[dict[str, Any]]:
    """Return OfficeCLI commands for two to six concentric layers."""
    if not 2 <= len(layers) <= 6:
        raise ValueError("layered_diagram requires 2-6 layers")
    ox, oy, width, height = parse_box(origin, size)
    builder = ComponentBuilder(slide, "layered-diagram", style, name=name)
    palette = builder.style.palette
    title_height = int(0.58 * EMU_PER_INCH) if title else 0
    if title:
        builder.text("title", title, ox, oy, width, int(0.34 * EMU_PER_INCH), size=18, bold=True, font=builder.style.fonts.header)
        if desc:
            builder.text("desc", desc, ox, oy + int(0.34 * EMU_PER_INCH), width, int(0.22 * EMU_PER_INCH), size=10.5, color=palette.muted)
    diagram_y = oy + title_height
    diagram_height = height - title_height
    outer_diameter = min(width, diagram_height)
    center_x = ox + width // 2
    bottom = diagram_y + diagram_height
    colors = depth_ramp(palette.primary, len(layers))

    for index, layer in enumerate(layers):
        fraction = 1.0 - (index / len(layers)) * 0.78
        diameter = max(int(outer_diameter * fraction), int(0.5 * EMU_PER_INCH))
        color = darken(colors[index], 0.1) if layer.get("tone") == "strong" else colors[index]
        x = center_x - diameter // 2
        y = bottom - diameter
        builder.shape("layer", x, y, diameter, diameter, geometry="ellipse", fill=color, line="none")
        label = layer.get("title") or layer.get("label") or ""
        label_y = y + max(int(0.07 * diameter), int(0.06 * EMU_PER_INCH))
        builder.text("layer-label", str(label), center_x - int(diameter * 0.34), label_y, int(diameter * 0.68), min(int(0.28 * EMU_PER_INCH), max(diameter // 5, int(0.15 * EMU_PER_INCH))), size=max(9, 13 - index * 0.6), color=palette.bg if index >= len(layers) // 2 else palette.on_bg, bold=True, font=builder.style.fonts.header, align="center")
    return builder.commands
