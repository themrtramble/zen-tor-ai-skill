"""OfficeCLI flywheel with a center asset and orbital node cards."""

from __future__ import annotations

import math
from typing import Any, Mapping

from ._base import EMU_PER_INCH, ComponentBuilder, lighten, line_spec, parse_box


def add_flywheel(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    center: Mapping[str, Any],
    nodes: list[Mapping[str, Any]],
    style,
    *,
    start_angle_deg: float = -90.0,
    direction: str = "clockwise",
    name: str | None = None,
) -> list[dict[str, Any]]:
    """Return OfficeCLI commands for a three-to-six-node flywheel."""
    if not 3 <= len(nodes) <= 6:
        raise ValueError("flywheel requires 3-6 nodes")
    if direction not in {"clockwise", "counterclockwise"}:
        raise ValueError("direction must be clockwise or counterclockwise")
    ox, oy, width, height = parse_box(origin, size)
    builder = ComponentBuilder(slide, "flywheel", style, name=name)
    palette = builder.style.palette
    fonts = builder.style.fonts
    cx, cy = ox + width // 2, oy + height // 2
    short_side = min(width, height)
    card_width = min(int(short_side * 0.31), int(width * 0.28))
    card_height = int(card_width * 0.53)
    orbit_radius = max(short_side // 2 - max(card_width, card_height) // 2 - int(0.08 * EMU_PER_INCH), int(0.5 * EMU_PER_INCH))
    inter_node = int(2 * orbit_radius * math.sin(math.pi / len(nodes)))
    card_width = min(card_width, max(int(inter_node * 0.82), int(1.3 * EMU_PER_INCH)))
    card_height = int(card_width * 0.53)

    builder.shape(
        "orbit", cx - orbit_radius, cy - orbit_radius, orbit_radius * 2, orbit_radius * 2,
        geometry="ellipse", fill="none", line=line_spec(lighten(palette.primary, 0.58), 0.75),
    )
    center_diameter = int(short_side * 0.31)
    builder.shape(
        "center", cx - center_diameter // 2, cy - center_diameter // 2,
        center_diameter, center_diameter, geometry="ellipse", fill=palette.primary, line="none",
    )
    center_title = str(center.get("title", ""))
    center_title_size = 16 if len(center_title) <= 16 else 13
    builder.text(
        "center-title", center_title, cx - int(center_diameter * 0.40), cy - int(0.20 * EMU_PER_INCH),
        int(center_diameter * 0.80), int(0.38 * EMU_PER_INCH), size=center_title_size,
        color=palette.bg, bold=True, font=fonts.header, align="center", valign="center",
    )
    if center.get("label"):
        builder.text(
            "center-label", str(center["label"]).upper(), cx - int(center_diameter * 0.38), cy + int(0.18 * EMU_PER_INCH),
            int(center_diameter * 0.76), int(0.20 * EMU_PER_INCH), size=8.5, color=lighten(palette.bg, 0.05), bold=True, align="center",
        )

    sign = 1 if direction == "clockwise" else -1
    start = math.radians(start_angle_deg)
    arrow_width = int(0.28 * EMU_PER_INCH)
    arrow_height = int(0.14 * EMU_PER_INCH)
    for index in range(len(nodes)):
        angle = start + sign * 2 * math.pi * (index + 0.5) / len(nodes)
        arrow_x = cx + int(orbit_radius * math.cos(angle)) - arrow_width // 2
        arrow_y = cy + int(orbit_radius * math.sin(angle)) - arrow_height // 2
        builder.shape(
            "cycle-arrow", arrow_x, arrow_y, arrow_width, arrow_height,
            geometry="rightArrow", fill=lighten(palette.primary, 0.22), line="none",
            rotation=math.degrees(angle) + sign * 90,
        )

    for index, node in enumerate(nodes):
        angle = start + sign * 2 * math.pi * index / len(nodes)
        node_cx = cx + int(orbit_radius * math.cos(angle))
        node_cy = cy + int(orbit_radius * math.sin(angle))
        x, y = node_cx - card_width // 2, node_cy - card_height // 2
        builder.shape("node", x, y, card_width, card_height, fill=palette.bg, line=line_spec(lighten(palette.primary, 0.45), 1))
        label = f"{int(node.get('index', index + 1)):02d}  {str(node.get('label', '')).upper()}"
        builder.text("node-label", label, x + int(0.10 * EMU_PER_INCH), y + int(0.06 * EMU_PER_INCH), card_width - int(0.20 * EMU_PER_INCH), int(0.18 * EMU_PER_INCH), size=8.5, color=palette.accent, bold=True)
        builder.text("node-title", str(node.get("title", "")), x + int(0.10 * EMU_PER_INCH), y + int(0.24 * EMU_PER_INCH), card_width - int(0.20 * EMU_PER_INCH), int(0.27 * EMU_PER_INCH), size=11.5, bold=True, font=fonts.header)
        if node.get("desc"):
            builder.text("node-desc", str(node["desc"]), x + int(0.10 * EMU_PER_INCH), y + int(0.50 * EMU_PER_INCH), card_width - int(0.20 * EMU_PER_INCH), max(card_height - int(0.55 * EMU_PER_INCH), int(0.14 * EMU_PER_INCH)), size=8.5, color=palette.muted)

    return builder.commands
