"""OfficeCLI helpers shared by the native PowerPoint components.

The component modules generate plain ``officecli batch`` command arrays.
They never import or mutate a presentation through ``python-pptx``.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

__all__ = [
    "FontPair",
    "Palette",
    "Style",
    "apply_commands",
    "coerce_style",
    "get_slide_count",
    "normalize_color",
    "smart_quotes",
    "write_commands",
]


_HEX_COLOR = re.compile(r"^#?[0-9a-fA-F]{6}$")


def normalize_color(value: Any) -> str:
    """Return an OfficeCLI-compatible six-digit RGB value."""
    if isinstance(value, str):
        text = value.strip()
        if _HEX_COLOR.fullmatch(text):
            return text.removeprefix("#").upper()
        return text
    if isinstance(value, int):
        return f"{value & 0xFFFFFF:06X}"
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)) and len(value) == 3:
        return "".join(f"{max(0, min(255, int(channel))):02X}" for channel in value)
    try:
        channels = list(value)
    except TypeError as exc:
        raise TypeError(f"unsupported color value: {value!r}") from exc
    if len(channels) != 3:
        raise TypeError(f"unsupported color value: {value!r}")
    return "".join(f"{max(0, min(255, int(channel))):02X}" for channel in channels)


@dataclass(frozen=True)
class Palette:
    """Six color tokens used by every component."""

    primary: str
    secondary: str
    accent: str
    muted: str = "6B7280"
    bg: str = "F7F8FA"
    on_bg: str = "111827"

    def __post_init__(self) -> None:
        for field_name in ("primary", "secondary", "accent", "muted", "bg", "on_bg"):
            object.__setattr__(self, field_name, normalize_color(getattr(self, field_name)))

    def resolve(self, value: str) -> str:
        """Resolve a palette token or normalize a literal OfficeCLI color."""
        if value in self.__dataclass_fields__:
            return getattr(self, value)
        return normalize_color(value)


@dataclass(frozen=True)
class FontPair:
    header: str = "Noto Serif CJK SC"
    body: str = "Noto Sans CJK SC"


@dataclass(frozen=True)
class Style:
    palette: Palette
    fonts: FontPair = field(default_factory=FontPair)


def coerce_style(value: Style | Mapping[str, Any]) -> Style:
    """Accept a ``Style`` instance or its JSON-friendly mapping form."""
    if isinstance(value, Style):
        return value
    if not isinstance(value, Mapping):
        raise TypeError("style must be Style or a mapping")
    palette_value = value.get("palette", value)
    fonts_value = value.get("fonts", {})
    palette = palette_value if isinstance(palette_value, Palette) else Palette(**dict(palette_value))
    fonts = fonts_value if isinstance(fonts_value, FontPair) else FontPair(**dict(fonts_value))
    return Style(palette=palette, fonts=fonts)


def smart_quotes(text: str) -> str:
    """Convert paired straight quotes to deterministic typographic quotes."""
    if not text:
        return text
    output: list[str] = []
    in_double = False
    in_single = False
    previous_is_alpha = False
    for character in text:
        if character == '"':
            output.append("\u201d" if in_double else "\u201c")
            in_double = not in_double
        elif character == "'":
            if previous_is_alpha:
                output.append("\u2019")
            else:
                output.append("\u2019" if in_single else "\u2018")
                in_single = not in_single
        else:
            output.append(character)
        previous_is_alpha = character.isalpha()
    return "".join(output)


def get_slide_count(deck: str | Path, officecli: str = "officecli") -> int:
    """Read the current OfficeCLI session, including slides not yet saved to disk."""
    process = subprocess.run([officecli, "get", str(deck), "/", "--depth", "0", "--json"],
                             check=True, capture_output=True, text=True, timeout=60)
    response = json.loads(process.stdout)
    results = (response.get("data") or {}).get("results", [])
    if response.get("success") is not True or len(results) != 1 or results[0].get("path") != "/":
        raise ValueError("OfficeCLI did not return the presentation root")
    root = results[0]
    children = root.get("children", [])
    count = root.get("childCount")
    if (not isinstance(count, int) or count < 0 or len(children) != count
            or any(child.get("path") != f"/slide[{i}]" for i, child in enumerate(children, 1))):
        raise ValueError("OfficeCLI returned an incomplete slide list")
    return count


def write_commands(commands: Iterable[Mapping[str, Any]], path: str | Path) -> Path:
    """Write an OfficeCLI command array for inspection or later replay."""
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(list(commands), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return output


def apply_commands(
    deck: str | Path,
    commands: Iterable[Mapping[str, Any]],
    *,
    officecli: str | Path = "officecli",
) -> dict[str, Any]:
    """Apply a component command array through one atomic OfficeCLI batch."""
    executable = str(officecli)
    if "/" not in executable:
        discovered = shutil.which(executable)
        if discovered is None:
            raise FileNotFoundError(f"OfficeCLI executable not found: {executable}")
        executable = discovered
    payload = list(commands)
    if not payload:
        return {"success": True, "results": []}
    with tempfile.NamedTemporaryFile("w", suffix=".json", encoding="utf-8", delete=False) as stream:
        json.dump(payload, stream, ensure_ascii=False)
        input_path = Path(stream.name)
    try:
        completed = subprocess.run(
            [executable, "batch", str(Path(deck)), "--input", str(input_path), "--stop-on-error", "--json"],
            check=False,
            capture_output=True,
            text=True,
        )
    finally:
        input_path.unlink(missing_ok=True)
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise RuntimeError(f"OfficeCLI batch failed: {detail}")
    try:
        return json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"OfficeCLI returned invalid JSON: {completed.stdout!r}") from exc
