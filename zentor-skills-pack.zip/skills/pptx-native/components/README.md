# OfficeCLI Composite Components

This directory provides command builders for native titles, text, tables, comparison charts, and composite shapes. All builders return native OfficeCLI commands without `python-pptx`.

Each `add_*` function accepts these shared parameters:

- `slide`: OfficeCLI slide path, such as `/slide[1]`.
- `origin`: top-left coordinates, expressed as EMU numbers or strings with `pt`, `in`, or `cm` units.
- `size`: component width and height, using the same units as `origin`.
- `style`: a dictionary containing `palette` and optional `fonts`.
- `name`: an optional component-name prefix used to produce stable, meaningful shape names.

Functions return an ordered JSON array that can be passed directly to `officecli batch`.

`fonts.header` defaults to `Noto Serif CJK SC`; `fonts.body` defaults to
`Noto Sans CJK SC`. The sandbox base image installs both font families through Ubuntu 22.04's
`fonts-noto-cjk` package. Its `fonts-noto-core` package provides `Noto Sans` and `Noto Serif`
for Latin, Greek, and Cyrillic scripts. Callers may override these defaults in `style.fonts`.

## Design Contract

`Palette` defines six stable color roles:

| Field | Meaning | Required |
| --- | --- | --- |
| `primary` | Main theme color for primary data, important nodes, and primary backgrounds. | Yes |
| `secondary` | Secondary color for borders, light layers, and supporting structures. | Yes |
| `accent` | Emphasis color for states that must differ from the primary color. | Yes |
| `muted` | Subdued text and supporting labels. | No; defaults to `6B7280` |
| `bg` | Light component background and light text on dark fills. | No; defaults to `F7F8FA` |
| `on_bg` | Body text on light backgrounds. | No; defaults to `111827` |

For `primary` or `highlight` fill variants, ensure that `bg` has sufficient contrast against `primary` or `accent`, respectively.

`metric_card` supports three `variant` values:

| Value | Visual meaning |
| --- | --- |
| `outlined` | Default light card: `bg` background, thin `secondary` border, and `primary` main value. |
| `primary` | Solid primary card: `primary` background, no border, and `bg` text. |
| `highlight` | Solid emphasis card: `accent` background, no border, and `bg` text. |

### Funnel Width and Direction

`funnel` defaults to `orientation="narrow_bottom"`, narrowing from top to bottom. Equal-height rounded stage bars place labels on the left and values on the right.

- If all stages omit `width`, the component first attempts to derive widths from numeric values.
- If values cannot be parsed, it generates a default taper from the number of stages.
- If any stage specifies `width`, every stage must specify it. Widths must not increase for `narrow_bottom` or decrease for `narrow_top`.
- `width` accepts `"72%"`, `0.72`, or `72`. The resulting percentage is clamped to 5%–100%.
- Widths derived from values have a 32% visual minimum to reserve label space.
- `orientation` controls both geometry and color progression. A conflict with explicit widths raises an error immediately.

### Traditional SWOT Matrix

`swot` defaults to a shared outer frame and central cross. The top columns identify favorable and unfavorable factors; left rows identify internal and external factors. The quadrants are Strengths, Weaknesses, Opportunities, and Threats.

- `axis_labels`: overrides semantic labels through `column_left`, `column_right`, `row_top`, and `row_bottom`.
- `show_axes`: controls semantic axis labels; defaults to `true`.
- `item_gap`: controls spacing between quadrant items; defaults to `0.06in`.
- `quadrants`: retains the existing input structure. Each quadrant displays at most five items.

Items sit compactly below quadrant titles. Their line spacing does not expand merely to fill the quadrant.

### Curved Timeline Roadmap

`timeline` draws the road as SVG and uses native OfficeCLI shapes for milestones, cards, and text. The road remains one picture; all other content is individually editable in PowerPoint.

- At most six phases are supported. Split longer timelines across slides.
- `boundary_dates` contains the starting date and every phase's ending date, so its length must equal `len(phases) + 1`.
- `title` is an optional roadmap title.
- Each phase card displays at most three `deliverables`. Cards alternate above or below the road according to its position.
- The SVG contains only the road outline and dashed center line, without text or business data.

Each phase can customize its `colors`:

| Field | Meaning | Default |
| --- | --- | --- |
| `fill` | Card background. | `palette.bg` |
| `border` | Card border. | A light color derived from `palette.secondary` |
| `text` | Title and body text. | `palette.bg` or `palette.on_bg`, selected from the fill |
| `accent` | Nodes, connectors, phase labels, and result text. | `palette.primary` for ordinary phases; `palette.accent` for the final phase |

```json
{
  "title": "Autonomous execution",
  "deliverables": ["Call tools", "Produce intermediate results"],
  "colors": {
    "fill": "ECFEFF",
    "border": "67E8F9",
    "text": "164E63",
    "accent": "0891B2"
  }
}
```

`colors` may specify only some fields. Unspecified fields retain the theme fallback rules.

## Python Usage

Call component functions directly when [creating slides](../references/workflow/create-slides.md#input).
The JSON examples also work through the optional CLI. Include the target `slide` path in each component entry.

### Native Comparison Charts and Picture Repairs

`add_chart(slide, origin, size, categories, series, category_label, value_label, style, *, chart_type="column", font_size=12, name="chart")`
creates a native grouped column or bar chart plus a separate editable axis caption.
`series` maps names to numeric arrays. Arrays must match the category count. Use one value-axis unit for all series.
The component sets theme colors, typography, data labels, and the legend. It measures the axis caption and reserves its wrapped height outside the plot.
Include the common unit and baseline in `value_label`. Use at most four series; put different units in separate charts or a table.
Include planned charts in the initial batch and inspect their actual labels.
Category labels cannot contain commas; series names cannot contain commas, colons, or semicolons because OfficeCLI uses these delimiters.

```json
{"component":"chart","origin":["1.4cm","4cm"],"size":["17cm","10cm"],"props":{
  "categories":["Baseline","Proposed"],"series":{"Training time":[120,75]},
  "category_label":"Method","value_label":"Training time (s)","chart_type":"bar","name":"time"
}}
```

`add_picture(..., target="/slide[3]/picture[@id=100022]")` emits a geometry-only `set` command for an existing picture.
Supply its original `src` and a new available region. The component preserves the source aspect ratio and centers the result.
Use the same component-only JSON through `components/cli.py plan` for in-place picture repairs.

### Native Titles and Body Text

Use `add_titled_slide` for new slides and `add_text` for body text and labels. Both return command arrays; combine them with `extend`.
They set consistent fonts, colors, padding, and fixed-point line spacing. Vertical alignment defaults to top.
Pass the chosen design system's `style`, font sizes, and regions. Do not rewrite the underlying text functions.

Complete signatures follow. `origin` and `size` are two-item tuples; `line_spacing` uses points.

```python
add_titled_slide(slide, origin, size, title, style, *,
                 font_size=28, color=None, bold=True, line_spacing=None, name="Title")
add_text(slide, origin, size, text, style, *,
         font_size=18, font=None, color=None, bold=False,
         align="left", valign="top", padding="0.1cm",
         line_spacing=None, bullets=False, fit_width=None, fit_height=None, name="text")
```

```python
from components import add_titled_slide, add_text

# STYLE is the palette / fonts dictionary selected for this task.
commands = add_titled_slide(
    "/slide[1]", ("1.2cm", "0.6cm"), ("30cm", "2.2cm"),
    "Research Question and Main Results", STYLE, font_size=30,
)
commands.extend(add_text(
    "/slide[1]", ("1.2cm", "3cm"), ("20cm", "4cm"),
    "Research question\nExperimental method\nMain results", STYLE,
    font_size=18, line_spacing=24, bullets=True, name="summary",
))
commands.extend(add_text(
    "/slide[1]", ("1.2cm", "17.6cm"), ("15cm", "0.6cm"),
    "Source: experimental report, p. 3", STYLE,
    font_size=10, padding="0cm", color=STYLE["palette"].get("muted", "6B7280"), name="source",
))
```

- `add_titled_slide` appends a slide, then styles its native title through `@name=Title`. The supplied `slide` is the intended appended slide number; call it in order. This function does not add a title to an existing slide.
- Titles default to `fonts.header`, 28 pt, bold, `on_bg`, and zero padding. Dark covers can use `color="FFFFFF"`; `bold=False` disables bold. Body text defaults to `fonts.body`, 18 pt, and `0.1cm` padding.
- `line_spacing` is an absolute point value and must be at least the font size. Omit it for the default spacing of 1.25 times the font size. Titles use the same rule. Enlarge the text region instead of compressing lines.
- `add_text` also supports `font`, `color`, `bold`, `align`, `valign`, `padding`, `bullets`, and `name`. Use `padding="0cm"` and tight regions for short labels.
- `color` accepts hexadecimal colors or shared palette fields such as `"muted"`. The interface resolves fields to the current `style.palette` values.
- Text width fits the content within the supplied region by default, preserving center and right anchors. Bullet lists and native titles retain the supplied width. Set `fit_width=False` to retain another text region's width; `fit_width=True` is incompatible with bullet lists.
- Plain text height fits the measured content within the supplied region, preserving top, middle, and bottom anchors. This removes unused transparent space from overlap checks. Set `fit_height=False` to retain the supplied height. Bullet lists retain their height; `fit_height=True` is incompatible with bullet lists. Insufficient height still fails before writing.
- Text and titles report insufficient height before writing, using font wrapping and fixed line spacing. Increase the region to the reported minimum and move following elements together. For example, one 18 pt line with zero padding needs 0.80 cm height; five lines with 24 pt spacing and 0.1 cm padding need 4.44 cm.
- Functions do not increase height automatically, execute OfficeCLI, or replace lint and per-slide screenshot review.
- Use `get_slide_count(deck)` to read the current OfficeCLI session, including unsaved slides. Append from that count plus one.
- Combine titles, components, and native notes commands following [Create Slides](../references/workflow/create-slides.md). Apply and review with `review_batch.py --input`.

### Native Tables

`add_table` accepts headers, row data, a region, and shared `style`, then returns all table-creation and cell-styling commands.
It handles geometry, fonts, header contrast, column alignment, emphasis rows, padding, and three horizontal rules.
Text is written directly to each cell. Commas, semicolons, quotes, and newlines are not interpreted as table delimiters.

```python
add_table(slide, origin, size, headers, rows, style, *,
          column_widths=None, alignments=None, emphasis_rows=(),
          font_size=14, padding="0.12cm", name=None)
```

- Omit `column_widths` to fit measured cell contents within the component width. Measurement includes bold headers and emphasis rows.
- Explicit `column_widths` must match the column count and sum to the component width. Mismatches fail before writing.
- `alignments` defaults to left for text columns and right for numeric or percentage columns. Empty cells and dash placeholders are ignored. Each column may explicitly specify `left`, `center`, or `right`; use this override for identifiers and mixed formats.
- Headers use a `primary` background and contrasting text. `emphasis_rows` uses bold text and a light accent background.
- `emphasis_rows` begins at `1` for the first body row and excludes the header.
- `font_size` defaults to `14` pt; `padding` defaults to `0.12cm`. The component measures wrapping with the actual font, weight, and column widths, then allocates row heights. Fixed-point line spacing is 1.5 times the font size, plus padding and borders.
- Insufficient height returns the required total height and line counts before writing. Enlarge the region and move its caption down, or widen wrapped columns. The component does not clip text, reduce fonts, or silently expand its region.
- Font measurement uses the sandbox's PyGObject, Pango, and installed fonts. Other environments must provide these system libraries. Measurement does not replace actual OfficeCLI screenshot review.
- Give each table a distinct `name`. The function does not create slides, execute OfficeCLI, or replace lint and screenshot review.

Call the component directly to generate commands. Do not first read its implementation, manually convert EMUs, or derive minimum row heights again. On a height error, adjust the region to the reported minimum total height and rerun generation.
The batch interface collects component-input errors with actual slide numbers, component indices, and names. Compilation errors prevent PPTX writes.

#### Table Capacity

Establish the slide's argument, then choose the required rows, columns, and table region. Font size, column widths, and actual wrapping determine table height. Do not assign height arbitrarily from remaining whitespace.
With default padding, each single-line row at 14 pt needs approximately 1.06 cm, including the header. Reserve at least 7.4 cm for seven single-line rows; wrapped rows need more height. Two eleven-row tables do not fit stacked in one content region.

For several results, first consider one comparison table or side-by-side tables when the column count permits. Preserve required metrics, units, baselines, and controls. Relevant source rows and columns may be selected with attribution; do not omit required or unfavorable results for layout. Allocate enough slides when the user requests a complete long table.
Height errors report required heights and line counts for the batch. Reposition tables, captions, and subsequent elements together. Reducing padding alone may not resolve capacity. Do not reduce font sizes to bypass the problem.

#### Reusable Table Example

Use `add_table` instead of rewriting cell-style loops. It returns commands for the authoring session to execute.
The example targets an existing `/slide[1]`. Values illustrate the interface and are not task data.
Replace parameters with actual data, dimensions, and the chosen design system. Keep the output after the first execution; do not replay `add`.

```python
import sys
sys.path.insert(0, "/opt/kernel/skills/pptx-native")
from components import add_table, write_commands

style = {
    "palette": {
        "primary": "16324F", "secondary": "B9CCD9", "accent": "23866D",
        "bg": "FFFFFF", "on_bg": "262626"
    },
    "fonts": {"header": "Noto Serif", "body": "Noto Sans"}
}
commands = add_table(
    "/slide[1]", ("2cm", "4cm"), ("20cm", "3.3cm"),
    headers=["Method", "Score", "Time (s)"],
    rows=[["Baseline", "80.0", "10"], ["Proposed", "82.0", "8"]],
    style=style,
    alignments=["left", "right", "right"], emphasis_rows=[2],
    font_size=14, padding="0.12cm", name="results",
)
write_commands(commands, "table-commands.json")
```

```bash
officecli batch deck.pptx --input table-commands.json --stop-on-error --json > table-result.json
# Inspect the full result, then save and read the table.
officecli save deck.pptx
officecli get deck.pptx '/slide[1]/table[@name=results]' --depth 3 --json
```

For custom edits to an existing table, read the `set table-cell`, `table-row`, and `table-column` schemas with `officecli help pptx ... --json`, then verify the result with a full-slide screenshot.

### Complete Pictures

`add_picture(slide, origin, size, src, style, *, name="picture", alt="")` fits and centers a local image within a region at its original aspect ratio.
`src` must be an existing absolute file path. The component uses the sandbox's GdkPixbuf to read dimensions, without cropping or stretching.
`size` defines available space, not forced image dimensions. `style` preserves the common component interface; pictures do not use palette colors.
Add captions separately with `text`.

```json
{"component":"picture","origin":["1.4cm","3cm"],"size":["15cm","12cm"],"props":{"src":"/home/user/.workspace/figure.png","name":"figure1","alt":"Complete experimental figure"}}
```

## Native Rules

`add_rule(slide, origin, size, style, *, color="primary", name="rule")` returns a native rectangular rule.
For horizontal rules, height specifies thickness, such as `size=("29cm", "0.5pt")`. For vertical rules, width specifies thickness, such as `size=("1pt", "10cm")`.
`color` accepts hexadecimal colors or shared palette fields. The optional JSON component name is `rule`.

```json
{"component":"rule","origin":["1.4cm","17.8cm"],"size":["31cm","0.5pt"],"props":{"color":"secondary","name":"footer-rule"}}
```

### Composite Shapes

```python
from components import Style, Palette, add_metric_card, apply_commands

style = Style(Palette(primary="2563EB", secondary="93C5FD", accent="F97316"))
commands = add_metric_card(
    "/slide[1]",
    ("1in", "1in"),
    ("4in", "2.4in"),
    {"kicker": "Revenue", "value": "$12.4M", "desc": "+18% YoY"},
    style,
    variant="outlined",
)
apply_commands("deck.pptx", commands)
```

## JSON and Command-line Usage

A specification can target components on multiple slides. This optional CLI calls the same Python component functions.
It does not interpret whole-slide specifications. Independently detectable component errors return together before any PPTX write.

```json
{
  "style": {
    "palette": {
      "primary": "2563EB",
      "secondary": "93C5FD",
      "accent": "F97316"
    }
  },
  "components": [
    {
      "component": "metric_card",
      "slide": "/slide[1]",
      "origin": ["1in", "1in"],
      "size": ["4in", "2.4in"],
      "props": {
        "variant": "outlined",
        "content": {"kicker": "Revenue", "value": "$12.4M", "desc": "+18% YoY"}
      }
    }
  ]
}
```

Generate the command plan:

```bash
python3 -m components.cli plan --spec components.json --out officecli-commands.json
```

Create a PPTX and apply components:

```bash
python3 -m components.cli apply --spec components.json --deck deck.pptx --create
```

To apply components to an existing PPTX, omit `--create`. OfficeCLI `batch` is atomic by default. If a command fails, it does not leave partially applied components.
