"""OfficeCLI layered architecture matrix with row rails and node cells."""

from __future__ import annotations

from typing import Any, Mapping

from ._base import EMU_PER_INCH, ComponentBuilder, depth_ramp, lighten, line_spec, parse_box


def add_flow_matrix(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    rows: list[Mapping[str, Any]],
    style,
    *,
    title: str | None = None,
    platform: Mapping[str, Any] | None = None,
    name: str | None = None,
) -> list[dict[str, Any]]:
    """Return OfficeCLI commands for a layered system or capability map."""
    ox, oy, width, height = parse_box(origin, size)
    builder = ComponentBuilder(slide, "flow-matrix", style, name=name)
    palette = builder.style.palette
    fonts = builder.style.fonts
    if not rows:
        return []
    title_height = int(0.46 * EMU_PER_INCH) if title else 0
    if title:
        builder.text("title", title, ox, oy, width, title_height, size=16, bold=True, font=fonts.header)
    platform_height = int(0.56 * EMU_PER_INCH) if platform else 0
    body_y = oy + title_height
    body_height = height - title_height - platform_height
    row_gap = int(0.10 * EMU_PER_INCH)
    row_height = (body_height - row_gap * (len(rows) - 1)) // len(rows)
    rail_width = min(int(1.8 * EMU_PER_INCH), int(width * 0.24))
    band_x = ox + rail_width + int(0.10 * EMU_PER_INCH)
    band_width = width - rail_width - int(0.10 * EMU_PER_INCH)
    ramp = depth_ramp(palette.primary, len(rows))
    max_nodes = max(1, max(len(row.get("nodes", [])[:5]) for row in rows))
    inner_gap = int(0.10 * EMU_PER_INCH)
    cell_width = (band_width - inner_gap * (max_nodes + 1)) // max_nodes

    for row_index, row in enumerate(rows):
        y = body_y + row_index * (row_height + row_gap)
        builder.shape("row-band", band_x, y, band_width, row_height, fill=lighten(ramp[row_index], 0.7), line="none")
        label = row.get("leftLabel") or row.get("label") or row.get("title") or ""
        builder.shape(
            "row-label", ox, y, rail_width, row_height, fill=ramp[row_index], line="none",
            text=str(label), size=12, color=palette.bg if row_index >= max(1, len(rows) // 2) else palette.on_bg,
            font=fonts.header, bold=True, align="left", valign="center", margin=int(0.14 * EMU_PER_INCH),
        )
        for node_index, node in enumerate(row.get("nodes", [])[:5]):
            x = band_x + inner_gap + node_index * (cell_width + inner_gap)
            cell_y = y + int(0.05 * EMU_PER_INCH)
            cell_height = row_height - int(0.10 * EMU_PER_INCH)
            builder.shape("node", x, cell_y, cell_width, cell_height, fill=palette.bg, line=line_spec(lighten(palette.primary, 0.4), 0.75))
            builder.text("node-title", str(node.get("title", "")), x + int(0.10 * EMU_PER_INCH), cell_y + int(0.06 * EMU_PER_INCH), cell_width - int(0.20 * EMU_PER_INCH), int(0.28 * EMU_PER_INCH), size=12, color=palette.primary, bold=True, font=fonts.header)
            if node.get("desc"):
                builder.text("node-desc", str(node["desc"]), x + int(0.10 * EMU_PER_INCH), cell_y + int(0.33 * EMU_PER_INCH), cell_width - int(0.20 * EMU_PER_INCH), max(cell_height - int(0.39 * EMU_PER_INCH), int(0.16 * EMU_PER_INCH)), size=9.5, color=palette.on_bg)

    if platform:
        py = oy + height - platform_height + int(0.04 * EMU_PER_INCH)
        builder.shape("platform", ox, py, width, platform_height - int(0.04 * EMU_PER_INCH), fill=palette.on_bg, line="none")
        builder.text("platform-label", str(platform.get("label", "")), ox + int(0.20 * EMU_PER_INCH), py + int(0.08 * EMU_PER_INCH), width - int(0.40 * EMU_PER_INCH), int(0.22 * EMU_PER_INCH), size=12, color=palette.bg, bold=True, font=fonts.header)
        if platform.get("desc"):
            builder.text("platform-desc", str(platform["desc"]), ox + int(0.20 * EMU_PER_INCH), py + int(0.30 * EMU_PER_INCH), width - int(0.40 * EMU_PER_INCH), int(0.18 * EMU_PER_INCH), size=9.5, color=lighten(palette.bg, 0.05))
    return builder.commands
