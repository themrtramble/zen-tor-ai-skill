"""OfficeCLI metric card with a kicker, value, and optional delta text."""

from __future__ import annotations

import unicodedata
from typing import Any, Literal, Mapping

from ._base import EMU_PER_INCH, EMU_PER_PT, ComponentBuilder, auto_delta_color, line_spec, parse_box


def add_metric_card(
    slide: str,
    origin: tuple[Any, Any],
    size: tuple[Any, Any],
    content: Mapping[str, Any],
    style,
    *,
    variant: Literal["outlined", "primary", "highlight"] = "outlined",
    name: str | None = None,
) -> list[dict[str, Any]]:
    """Return OfficeCLI commands for one editable metric card."""
    if "value" not in content:
        raise ValueError("metric card content requires value")
    ox, oy, width, height = parse_box(origin, size)
    builder = ComponentBuilder(slide, "metric-card", style, name=name)
    palette = builder.style.palette
    fonts = builder.style.fonts
    if variant not in {"outlined", "primary", "highlight"}:
        raise ValueError("metric card variant must be 'outlined', 'primary', or 'highlight'")
    filled = variant in {"primary", "highlight"}
    background = {
        "outlined": palette.bg,
        "primary": palette.primary,
        "highlight": palette.accent,
    }[variant]
    border = line_spec(palette.secondary, 1) if variant == "outlined" else "none"
    foreground = palette.bg if filled else palette.on_bg
    value_color = palette.bg if filled else palette.primary
    builder.shape("card", ox, oy, width, height, fill=background, line=border)
    pad_x = int(0.24 * EMU_PER_INCH)
    pad_y = int(0.18 * EMU_PER_INCH)
    content_width = width - 2 * pad_x
    cursor_y = oy + pad_y
    if content.get("kicker"):
        kicker_height = int(0.24 * EMU_PER_INCH)
        builder.text("kicker", str(content["kicker"]).upper(), ox + pad_x, cursor_y, content_width, kicker_height, size=10.5, color=palette.bg if filled else palette.muted, bold=True)
        cursor_y += kicker_height + int(0.05 * EMU_PER_INCH)
    value_text = str(content["value"])
    base_size = 48 if width >= 4 * EMU_PER_INCH else 40 if width >= 2.8 * EMU_PER_INCH else 32 if width >= 2 * EMU_PER_INCH else 26
    display_units = sum(1.0 if unicodedata.east_asian_width(character) in {"W", "F"} else 0.55 for character in value_text)
    fitted = int((content_width / EMU_PER_PT) * 0.90 / max(display_units, 1.0))
    value_size = max(18, min(base_size, fitted))
    value_height = min(int(0.72 * EMU_PER_INCH), max(int(value_size * 1.25 * EMU_PER_PT), int(0.38 * EMU_PER_INCH)))
    builder.text("value", value_text, ox + pad_x, cursor_y, content_width, value_height, size=value_size, color=value_color, bold=True, font=fonts.header, valign="center")
    cursor_y += value_height + int(0.05 * EMU_PER_INCH)
    desc = content.get("desc")
    if desc:
        lines = [line for line in str(desc).splitlines() if line.strip()]
        remaining = max(oy + height - pad_y - cursor_y, int(0.18 * EMU_PER_INCH))
        line_height = min(int(0.28 * EMU_PER_INCH), remaining // max(len(lines), 1))
        line_height = max(line_height, int(0.18 * EMU_PER_INCH))
        for index, line in enumerate(lines):
            color = foreground if filled else auto_delta_color(line) or foreground
            builder.text("desc", line, ox + pad_x, cursor_y + index * line_height, content_width, line_height, size=11.5, color=color)
    return builder.commands
