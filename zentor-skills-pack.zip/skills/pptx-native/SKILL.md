---
name: pptx-native
description: >-
  The default PowerPoint skill. Use when the user asks to create, read, inspect, render, edit, restyle, reconstruct, or export a PPT, PPTX, PowerPoint presentation, or slide deck. Image input does not automatically require image output.
---

# Create Native PPTX Files with OfficeCLI

Use this skill by default. The `pptx` skill handles only explicitly requested image-based output. Do not mix in its full-slide packaging workflow.

## Authoritative Practices

1. You have enough time to produce a high-quality deck. **Complete one batch at a time per writer.** A batch is one or two consecutive slides. A worker's full slide range is an assignment and may contain several batches. Do not skip work or disrupt the workflow to go faster or be more efficient; quality always comes before speed. Planning and source-image preparation may cover the whole deck.
2. **Each writer must pass every slide in its current batch before starting the next batch in the same assignment.** PDF conversion and image reconstruction retain their per-page gates. Do not write a full-deck command array or run one `reconstruct.py build` for the whole deck. Do not declare delivery until every planned slide has passed and publication succeeds.
3. **Call `publish_file` only for the final deliverable.** Do not publish previews, drafts, initial work in progress, or intermediate screenshots. If a tool is unavailable or fails, leave the file in the workspace and do not claim it was uploaded.
4. Remember the selected design system and follow its visual and layout rules throughout the deck.
5. **Check text length.** When creating or rewriting content, keep body paragraphs to at most 40 English words or 50 CJK characters. Keep titles to at most 15 English words or 18 CJK characters and two lines. Use at most five bullets, with at most eight English words or 20 CJK characters per bullet, and keep each bullet on one line. If content exceeds these limits, tighten the copy. Do not reduce font size or line spacing, or enlarge text boxes merely to force it to fit. When the user requests verbatim preservation or a 1:1 reconstruction, preserve the source content instead.
6. **Keep one PPTX writer.** Only the primary agent modifies, validates, and publishes the final PPTX. A `worker` subagent may write its assigned temporary PPTX and auxiliary files in an exclusive output path.
7. **Do not edit the PPTX ZIP manually.** Use OfficeCLI for all deck changes.
8. **Capture slide screenshots only with OfficeCLI.** Use `officecli view <file> screenshot --page N --out <path> --screenshot-width 1280 --screenshot-height 720 --render html`. Do not call `chrome`, `google-chrome`, Playwright, camoufox, or any browser tool. The sandbox already has `google-chrome-stable`; OfficeCLI finds it. A missing `chrome` binary means the wrong command was used.

## 1. Route the Task

Identify the task type first. For any later-turn edit, addition, or deletion to a deck created earlier, use "Edit an Existing PPTX" and read [`workflow/slides-editing.md`](references/workflow/slides-editing.md) in full.

| Task | Required route |
| --- | --- |
| **Create a new deck** from scratch or from a style reference; use a PDF only as source material and redesign the layout | Section 2, "Create a New Deck," Steps 1 through 8 |
| **Convert PDF to PPT** with a 1:1 reproduction, restored layout, and one editable slide per page | [workflow/pdf-conversion.md](references/workflow/pdf-conversion.md) |
| **Edit an existing deck**, including an earlier-turn PPTX | [workflow/slides-editing.md](references/workflow/slides-editing.md) |
| **Use a user-provided template**, meaning a PPTX whose layout must carry the new content | [workflow/template-editing.md](references/workflow/template-editing.md) |
| **Read or analyze an existing deck** | Follow [slides-editing.md](references/workflow/slides-editing.md) to inspect its structure and classify it as native, mixed, or flattened. |
| **Convert images or a flattened PPTX to editable output** | [workflow/image-reconstruction.md](references/workflow/image-reconstruction.md) |

## 2. Create a New Deck

**Required sequence: understand the request, select a design system, collect assets, outline the deck, create the file, prepare images, complete each slide, then validate and deliver.**

**Parallel creation:** When `subagent` is available, use up to four workers for independent slide ranges. Follow [create-deck.md](references/workflow/create-deck.md) for assignments and merging. Workers prepare their assigned assets and temporary PPTX files. The primary agent reviews and publishes the merged deck.

### Step 1: Understand the Request

Identify the **purpose, audience, slide count, style preference, and input type**, such as a topic only, a complete document, or a slide-by-slide outline or script.

- **Slide count:** Follow the user's requested count. If the user supplies a slide-by-slide outline or script, match its slide count. If the user supplies only a topic or structured long document, choose a reasonable count based on content volume and explain the choice in the response.
- **Do not interrupt when a safe inference is possible.** Ask only for a hard blocker, such as an unreadable attachment or contradictory requirements, for example a required design system with an incompatible style or both 10 slides and more than 30 slides.

### Step 2: Select a Design System

- If the user provides a **template PPTX**, skip this step and follow [template-editing.md](references/workflow/template-editing.md).
- For **PDF-to-PPT conversion**, skip this step and follow [pdf-conversion.md](references/workflow/pdf-conversion.md).
- For a **1:1 reconstruction of images or a flattened PPTX**, skip this step and follow [image-reconstruction.md](references/workflow/image-reconstruction.md). Treat source pixels as authoritative.
- Otherwise, read [`style/slide-taxonomy.md`](references/style/slide-taxonomy.md), select one of its seven primary scenarios, then read the corresponding scenario document.
- If no scenario matches, read [`style/fallback.md`](references/style/fallback.md).
- User-provided branding, colors, fonts, and style references take precedence.
- After selection, follow that design system for color, typography, whitespace, layout, decoration, and image density.
- Implement the design with OfficeCLI `table`, `shape`, and `chart` elements. Do not place Markdown tables on slides.

### Step 3: Collect Assets

Use the selected design system to determine which assets are required, and collect them in this step.

- **Prefer user attachments.** DOCX, PDF, XLSX, and image attachments are factual sources. Plain-text extraction loses images, tables, and formulas. Inspect DOCX tables and embedded images, and inspect PDF embedded images, tables, and full-page renders. Preserve all information when inserting attached images or tables into the deck. **Do not crop them, but scale them to fit the layout.** Attachments take precedence over conflicting sources. For PDF-to-PPT requests, do not expand the material in this step; follow [pdf-conversion.md](references/workflow/pdf-conversion.md). **Do not parse a primary PPTX source or template as an ordinary attachment.** Copy it and inspect it with OfficeCLI; reconstruct it if flattened. Use the absolute path from `<file>` for attached images, commonly `/home/user/uploads/...`; they are already local.
- **Search online** for real data, facts, and examples. Do not invent information. Mark missing information as a placeholder, assumption, or item to confirm, and cite its source. If the user supplies a complete document or slide-by-slide outline without specifying whether expansion is allowed, search for supporting material by default unless the user explicitly forbids expansion.
- **Generate images** with the platform-provided `GenerateImage` or `EditImage` tool, following the tool schema. Use it for illustrations, cover visuals, diagrams, or when no real image is available. Do not call `publish_file` for source images. For a 16:9 background, use `aspect_ratio="16:9"`. Follow the tool schema; do not pass `size` or `output_format`. Exclude text, numbers, logos, watermarks, charts, and user-interface elements from the prompt. If generated text appears, use `EditImage` or regenerate. The tool returns a relative `workspace_path`, such as `generated/...`; convert it to an absolute path in Step 6. A full-bleed background is `33.867cm x 19.05cm`. If its aspect ratio differs, use `crop` rather than stretching it. On a new slide, add the background before foreground elements. On an existing slide, use `move --index 0`. Do not use `ppt gen` or `ppt pack` from the adjacent `pptx` skill. Do not bake title or body copy into the background. Do not generate an image merely to fill whitespace.

Record the original dimensions of every image. Use them to scale `picture` elements in Step 7 without distortion.

#### Parallel Asset Collection

When the `subagent` tool is available, submit independent asset tasks in one parallel call. Use `scout` for read-only local inspection. Use `worker` when the task needs the full child-session tool set, such as remote research or asset generation. For known image prompts, call `GenerateImage` directly and concurrently instead.

Define each parallel task with:

- the target slides and asset purpose;
- source and design constraints;
- an exclusive output directory, when a `worker` task writes files;
- the required result fields: selected asset paths, source URLs or input paths, generation prompts, original dimensions, and unresolved issues.

No task may edit or publish the PPTX. After the aggregated tool result returns, the primary agent checks the assets and integrates them into the deck.

### Step 4: Prepare a Lightweight Outline

Save the selected palette and fonts in `style.json` for both serial and parallel creation. Save the shared outline in `brief.md` only for parallel creation. Define the reader's task on each slide. Use varied layouts and maintain a deliberate rhythm across slides. Ensure that the contents slide matches the later content slides.

```text
Presentation title:
Target audience:
Design system: [selected scenario or fallback style]
Color palette: [primary / secondary / accent]
Slide plan (N slides total):
Slide N - role or reader task; key information; primary visual
```

### Step 5: Prepare the File

Before writing the final PPTX, verify the runtime, then create the file and first slide. Keep work in progress in the workspace and do not upload it.

**Standard components:** Use [component builders](components/README.md) for supported elements; do not reimplement them in custom helpers. Read [create-slides.md](references/workflow/create-slides.md) before creating slides. Use the direct creation and schema instructions below only for elements the components do not cover.

```bash
command -v officecli
officecli --version
officecli help pptx add <element> --json
```

1. **Compile intent into commands.** Do not memorize a command catalog. Map intent to an element, query its schema, use only properties with `add: true`, save stable paths from `--json`, and read back with `get --json` before editing. Use `raw`, `raw-set`, or `add-part` only for capabilities absent from structured help. See [element-recipes.md](references/workflow/element-recipes.md).

   Map slides to `slide`; text, titles, and labels to `shape`; charts to `chart`; tables to `table`; images to `picture`; lines and arrows to `connector`; groups to `group`; speaker notes to `notes`; effects to `animation`; transitions to `transition`; and background artwork to `GenerateImage` plus a full-bleed `picture`.

2. **Create the file and first slide.** For a standard new deck, use OfficeCLI directly without the reconstruction script:

```bash
officecli create deck.pptx
officecli add deck.pptx / --type slide \
  --prop name=slide-01 --prop layout=blank --json
```

   Save the stable path returned by `add --json`, then read it back with `get --json`. Quote paths containing brackets, for example `'/slide[1]/shape[@id=7]'`. Use `--input` for large JSON payloads.

### Step 6: Prepare Image Files

`src` is only an add/set input. OfficeCLI embeds the bytes in `ppt/media/`, so the delivered PPTX is self-contained. Before writing, the file must exist in the sandbox and `src` must be an existing absolute path. `get` returns only `relId`, so record the source path yourself. Apply schema-defined `crop` geometry in Step 7, not during file preparation.

- **Attachments:** Use the absolute path from `<file>`.
- **Generated images:** Expand `workspace_path` to `/home/user/.workspace/<workspace_path>`.
- **Reuse from an existing PPTX:** Do not unpack the archive and guess media names. Use `get --save` or copy the asset to a local file before passing it as `src`.

### Step 7: Complete Each Slide

When running a command to generate one slide, set `timeout: 600` (10 minutes) alongside `command` in the Bash tool call.

Planning and asset collection may cover the whole deck. During slide creation, each script or `officecli batch` may modify only the current batch. Repair existing slides in place with `set`, `move`, or `remove`; do not recreate the deck or replay successful creation scripts. Recheck every affected slide.

**Gate:** write the batch, `save`, lint, screenshot, `read` every screenshot, and update both records. Mark each slide `pass` only when lint is `pass`, every issue row is `pass`, and the latest visual review found no new issues. Do not defer slide-local fixes to Step 8. If a check is unavailable, mark the slide `unchecked` and stop that writer's later batches until the check is restored and passes. Unavailable checks do not count as passes. After updating the records, immediately start the next unfinished batch, or go to Step 8 if the assignment is complete. If any slide in the batch is still `fix`, keep repairing it. Do not clean up or send a final reply here.

Keep `slide-checks.md` (one summary row per slide; no issue details) and `review/slide-NN.md` (one row per issue; keep resolved rows). Use two-digit slide numbers (`01`). Encode the discovery round in each issue `id`, such as `R1-01` (round 1, issue 1). Keep that ID during rechecks; use `R2-01` for a new issue found in round 2. After each check, update both files. Write `verification` as a short note, not a path. `lint` is the combined `officecli validate` and `layout_lint.py` result (`pass` / `fail` / `unknown`): use `fail` if either check fails, otherwise `unknown` if either is unavailable. Slide `status` is `pass` / `fix` / `unchecked`: use `fix` for failed checks or open issues, otherwise `unchecked` when any check is unavailable. Issue `status` is `open` until a later lint plus fresh-screenshot recheck confirms the fix, then `pass`. Use `unknown` for `open_visual_issues` until inspection succeeds.

```text
# slide-checks.md
| slide | lint | open_visual_issues | status |
| 01 | pass | 0 | pass |

# review/slide-01.md
| id | check | issue | status | verification |
| R1-01 | visual | title clipped | pass | lint pass; visual recheck passed |
```

Add later slides to the same `deck.pptx`.

1. **Query the schema before writing.** Run `officecli help pptx add <element> --json` before creating an element. Replace `add` with `set` before modifying one. Do not invent element IDs; use values from `add --json` or `get --json`. Give short transparent text explicit unit-bearing `width` and `height` values rather than full-slide width. See [element-recipes.md](references/workflow/element-recipes.md).
2. **Images:** Scale images to fit without exceeding the slide canvas. Do not crop images or tables extracted from attachments; scale them only. Matching the source aspect ratio prevents cropping. Do not reuse the same content image on multiple slides, except for logos and consistent decoration.
3. **Asset fallback:** Prefer real assets for the primary visual and do not leave empty image frames. If an image is missing, use `GenerateImage`. If that is unavailable, draw a structure with `shape` and `connector` elements. Do not invent numbers when real data is missing. Prefer a structure diagram, key points, or qualitative comparison. If a placeholder chart is necessary, label it "Simulated data for placeholder use only."
4. **Speaker notes:** Add three to five speakable sentences to every slide with `notes`.
5. **Static validation is required:**

```bash
officecli validate deck.pptx --json
python3 /opt/kernel/skills/pptx-native/scripts/layout_lint.py deck.pptx
```

6. **Visual validation is required.** Generate a `1280x720` screenshot of each slide with OfficeCLI only, then call `read` on the same path:

```bash
officecli view deck.pptx screenshot --page 1 --out review/slide-01.png \
  --screenshot-width 1280 --screenshot-height 720 --render html
```

For direct captures, save the current screenshot at `review/slide-NN.png` and replace it when the slide changes. For `review_batch.py` runs, `read` the unique screenshot paths it returns and record the latest path in `review/slide-NN.md`. Re-validate a changed slide with a fresh screenshot before treating it as `pass`. Every required check in `validation-visual.md` must pass. Unavailable checks block the next slide and delivery. Fix `open` issues, rerun lint, capture a fresh screenshot, and recheck before marking those rows `pass`; then scan for new issues. Fix blank slides, broken images, overlaps, and obvious clipping before delivery. Do not validate with thumbnails.

### Step 8: Validate and Deliver

This full-deck pass does not replace the Step 7 gate. Slides merged from a worker's temporary PPTX must first pass the Step 7 gate in the final presentation, with the primary agent reading their fresh screenshots; those results count as Step 7 records.

1. **Reuse unchanged slides.** Keep Step 7 screenshots and `pass` records for slides that have not changed. Shared layout, theme, or asset changes affect every slide that uses them. Run `layout_lint.py` on the complete deck once unless the file is unchanged since the last Step 7 lint. Recapture OfficeCLI screenshots only for affected slides.

If slides invalidated by such shared changes need review in this pass, call `subagent` once in parallel mode to inspect their fresh screenshots. Do not `read` those screenshots in the primary session; use the read-only `reviewer` profile. This delegation does not apply to slides going through the Step 7 gate above.

Define each parallel task with:

- assigned slide numbers;
- exclusive absolute screenshot paths for those slides;
- the inspection standard: [validation-visual.md](references/workflow/validation-visual.md) and the "Visual Quality Floor" in [slide-taxonomy.md](references/style/slide-taxonomy.md);
- a requirement to `read` every assigned screenshot;
- the required result fields, one row per assigned slide: `slide`, `status`, `findings`, `suggested_fix`.

Focus on information density per slide and consistency across slides. Require this result table:

```text
| slide | status | findings | suggested_fix |
```

Every `status` must be `pass` or `fix`. Each task reports findings only and does not modify files. After the aggregated tool result returns, the primary agent resolves duplicate or conflicting findings, checks deck-wide consistency, applies fixes, reruns `layout_lint.py` on the complete deck, and recaptures screenshots only for affected slides.

2. **Review the full-deck overview.** Create one or more overview images from the latest validated screenshots and call `read` on each overview. Check for consecutive slides with the same layout, repeated content images, excessive empty section slides, abrupt dark-to-light transitions, long runs of uniformly high or low information density, and an underfilled closing slide. Fix each finding, recheck affected slides, and update the overview. If no changes are needed, proceed to delivery without repeating per-slide checks.

## 3. Reference Map

### `style/`

| Document | Read when |
| --- | --- |
| [slide-taxonomy.md](references/style/slide-taxonomy.md) | Selecting a design system. Do not choose a scenario document without reading this entry point. |

### `workflow/`

| Document | Read when |
| --- | --- |
| [create-deck.md](references/workflow/create-deck.md) | Coordinating parallel creation: shared brief and style, worker assignments, and merging. |
| [create-slides.md](references/workflow/create-slides.md) | Creating assigned slides with component builders, reviewing batches, repairing, and exporting worker output. |
| [slides-editing.md](references/workflow/slides-editing.md) | Editing a source deck: copy, `view`, `get`, `audit-pptx`, edit, then lint. |
| [template-editing.md](references/workflow/template-editing.md) | Copying a template as the only target and reusing its frame and layout for new content. |
| [pdf-conversion.md](references/workflow/pdf-conversion.md) | Converting PDF to editable PPTX: rasterize, then follow the reconstruction `build` gate. |
| [image-reconstruction.md](references/workflow/image-reconstruction.md) | Reconstructing images or a flattened PPTX as editable elements. |
| [element-recipes.md](references/workflow/element-recipes.md) | Mapping intent to OfficeCLI commands and applying text geometry rules. |
| [layout-lint.md](references/workflow/layout-lint.md) | Validating structure and layout with `layout_lint.py` in Steps 7 and 8. |
| [validation-visual.md](references/workflow/validation-visual.md) | Visually validating slide screenshots. |

### `components/`

**Reuse composite shapes when they match the content.** The `components/` package provides OfficeCLI command builders for titles, text, tables, pictures, charts, rules, allocation bars, comparisons, flow matrices, flywheels, funnels, Gantt charts, layered diagrams, metric cards, quote blocks, SWOT matrices, and timelines. The timeline uses one SVG picture for its curved road; its milestones, cards, and text remain native OfficeCLI objects. Each phase can override the card's semantic colors through its `colors` mapping. Read `components/README.md`, generate the component command array, and apply it through one atomic `officecli batch` call. Do not use a component as a generic card grid when its documented information model does not match the slide.

#### Decision tree

```
Need to show…
├─ a single big KPI number?          → add_metric_card (place 2-4 in a row)
├─ a pull quote / CEO message?       → add_quote_block
├─ 2-4 options side by side?         → add_comparison
├─ SWOT or 2×2 impact matrix?        → add_swot
├─ conversion / stage funnel?        → add_funnel
├─ project schedule with bars?       → add_gantt
├─ phased roadmap with milestones?   → add_timeline
├─ budget / percentage breakdown?    → add_allocation_bars
├─ ecosystem orbiting a core?        → add_flywheel
├─ concentric layers (core → outer)? → add_layered_diagram
└─ multi-layer architecture?         → add_flow_matrix
```

If none of these fit, generate the layout yourself. Do not force-fit a component.

## 4. Core Concepts

```text
deck.pptx
|-- /                         presentation (slideWidth / slideHeight)
`-- /slide[N]
    |-- shape[@id=...]        titles, body text, labels, and geometry
    |-- picture[@id=...]      images; write with absolute src paths, embed bytes, and commonly read back relId
    |-- chart / table
    |-- connector / group
    `-- notes                 speaker notes
```

- **Source file:** After delivery, the PPTX is authoritative. Do not overwrite an edited deck from a stale `officecli-commands.json`.
- **Stable path:** Use the latest result from `add --json` or `get --json`. Do not guess `@id` values.
- **Validation:** `officecli validate` checks Open XML. `layout_lint.py` checks layout. Both must pass before delivery.
