# Reconstruct Images as an Editable PPTX

## Default Contract

Use this workflow for screenshots, exported slide images, image directories, or a flattened full-slide PPTX that must become editable elements. For PDF conversion, first rasterize every page into the same PNG layout. See [pdf-conversion.md](pdf-conversion.md).

Follow the Authoritative Practices in `SKILL.md`. Because `reconstruct.py build` cannot append to an existing PPTX, apply that rule here as a cumulative rebuild:

```text
current source page -> visual analysis -> current-page commands -> cumulative build -> lint -> read screenshot -> fix -> pass -> next page
```

The Agent writes a native OfficeCLI command array for this round only: already-passed pages 1 through N-1, unchanged, plus the current page N. The runner fills missing drawing IDs, checks the installed OfficeCLI schema, executes one atomic batch for this cumulative file, audits editability, renders the slides in this round, and applies a visual-fidelity gate. There is no Scene, manifest, or copied schema. Isolate this round's source-image directory and command files as described below.

## 1. Route the Task and Inspect the Source

Audit a PPTX before deciding whether to reconstruct it:

```bash
SKILL_DIR=/opt/kernel/skills/pptx-native
python3 "$SKILL_DIR/scripts/reconstruct.py" audit-pptx source.pptx
```

- `route: reconstruct`: The entire deck contains flattened images. Reconstruct it. Fully transparent PNG placeholders do not change this route.
- `route: edit-existing`: The deck contains native or mixed editable content. Preserve the PPTX and use standard OfficeCLI editing.

Do not flatten a native or mixed deck into full-slide images merely to use this workflow.

For a flattened source, render each slide to a review PNG when that slide becomes the current page, or render all slides first as source images only:

```bash
officecli view source.pptx screenshot --page 1 --out source/slide-01.png \
  --screenshot-width 2048 --screenshot-height 1152 --render html
```

When the input is already an image, inspect it at full original resolution. The source pixels define the design. Do not redesign, summarize, or apply another template unless the user requests a new version.

## 2. Separate Editable and Fidelity Regions

Use visual analysis to identify meaningful editable units. Do not trace every contour.

| Source object | Default output |
| --- | --- |
| Verified readable titles, body text, labels, dates, numbers, percent signs, or units | Native text `shape` |
| Stable cards, dividers, lines, arrows, or connections | Native `shape` or `connector` |
| Photos, screenshots, maps, illustrations, detailed logos, or complex icons | Tightly cropped `picture` island |
| Charts or tables whose underlying data is unverified | Tightly cropped `picture` island |
| Unreadable text, unclear boundaries, or unsupported effects | Fidelity background or separate review |

Create a hybrid reconstruction as the default minimum-fidelity approach:

1. Add the full source-slide render as a full-bleed fidelity background. This preserves small icons, decorations, illustrations, and uncertain effects.
2. Promote reliable text and simple geometry to native elements.
3. Before promoting a region, cover the old pixels with a native shape that fits tightly and matches the local background.
4. If the cover is not clean, leave that region image-backed. Do not place a duplicate native object over the original pixels.

The fidelity background cannot be the slide's only meaningful object. Do not replace uncertain visuals with generic icons, invented charts, rough approximations, or blank areas.

Set the Office slide canvas before measuring objects. Use one source-to-slide scale for all coordinates and dimensions.

## 3. Write a Native OfficeCLI Command Plan

Check the installed binary's help for every element type used on the slide. If a property, enum, or verb is uncertain, query its exact schema. Do not guess.

```bash
officecli --version
officecli help pptx add slide --json
officecli help pptx add shape --json
officecli help pptx add picture --json
officecli help pptx add connector --json
```

Keep commands by page. The fragment or command file for page N contains only that page. The cumulative `officecli-commands.json` may contain only already-passed pages 1 through N-1 plus the current page N. Do not create a page N+1 file before page N passes. Write a plain ordered JSON array with no envelope:

```json
[
  {
    "command": "set",
    "path": "/",
    "props": {
      "slideWidth": "960pt",
      "slideHeight": "540pt"
    }
  },
  {
    "command": "add",
    "parent": "/",
    "type": "slide",
    "props": {
      "name": "slide-01"
    }
  }
]
```

Add objects from back to front: slide, fidelity background, cover shapes, picture islands, native geometry, and native text last. Give every object a unique semantic `props.name`. Use absolute local paths for assets. Drawing `props.id` values can be omitted; the runner assigns them deterministically. Add connector endpoints before the `connector`, and refer to endpoints with stable `@name` paths. Set `"wrap": false` on reconstructed single-line text boxes so the Office renderer does not reflow measured titles, labels, or text embedded in graphics. The wrapper uses fail-fast runtime add probes and read-back checks to cover known omissions in OfficeCLI help. If the probe succeeds, do not replace structured `wrap` with repeated `raw-set` calls.

Reject `raw-set` by default. Use it only when the current structured help cannot preserve a required capability and the caller explicitly enables `--allow-raw-set`.

### Reconstruction Prompt

```text
Use the installed OfficeCLI to reconstruct only the current source page. Do not write or generate any later page until this page passes static validation and visual review. Never generate the entire deck before checking it.

The source pixels are visually authoritative. Preserve every visible detail. Do not redesign, summarize, invent content, infer unverified chart data, or silently omit small icons, decorations, labels, numbers, or uncertain regions.

If an OfficeCLI property or value is uncertain, query `officecli help pptx <verb> <element> --json`. Write commands only for the current page. The cumulative officecli-commands.json may replay previously approved pages unchanged, followed by the current page. It must contain no later pages. Do not create a Scene, schema copy, or manifest. Keep the per-slide validation and visual-review records required by this workflow.

Use an explicit slide canvas and one coordinate scale. Build each slide from back to front. First add the full source-slide render as a fidelity background. Then promote verified text and simple geometry to native elements. Before promoting a region, cover its old pixels with a tightly fitted native shape whose fill matches the local background. If the cover is not clean, leave the region image-backed. Do not duplicate it or omit it.

Use native text for verified readable copy, native shape or connector elements for reproducible simple geometry, and tightly cropped picture islands for complex or uncertain visuals. Give every created object a unique semantic name. Use absolute paths for assets. Add connector endpoints before the connector. Drawing IDs can be omitted because the runner assigns them. Set wrap to false for intentionally single-line text. Give short transparent single-line text boxes content-sized width and height. Do not make them full-slide width solely for center or right alignment. Adjust x to preserve their visual position. Do not output raw-set unless explicitly requested.

Before finishing, account for every visible source region and verify every word, date, number, percent sign, and unit against the source image.
```

## 4. Build and Gate One Page at a Time

`reconstruct.py build` always rebuilds from an empty PPTX. It cannot append to an existing file. Adapt to that limit with a cumulative rebuild: round N adds only the current page and replays already-passed pages 1 through N-1 unchanged. Do not write the complete deck first and then execute it in batches.

For each page N:

1. Read the current source page and write commands for that page only. Reuse the agreed canvas, coordinate scale, and naming rules.
2. Merge already-passed page commands with the current page into `officecli-commands.json`. The file may contain only pages 1 through N.
3. Copy source images for pages 1 through N into `work/current-source/` as `slide-1.png` through `slide-N.png`. Do not include later pages. Keep the full source set elsewhere. The comparator requires the source-image set to match this round exactly.
4. Run the cumulative build. The example below is for `2048x1152` sources; other sizes must change both screenshot arguments.

```bash
python3 "$SKILL_DIR/scripts/reconstruct.py" build \
  --source-renders work/current-source \
  --commands officecli-commands.json \
  --out editable.pptx \
  --screenshot-width 2048 \
  --screenshot-height 1152
```

5. After a successful build, run static checks on this round's file:

```bash
officecli validate editable.pptx --json
python3 "$SKILL_DIR/scripts/layout_lint.py" editable.pptx
```

6. Read the reports. `layout_lint.py` exit code `0` is not a pass. Confirm `ok` is true, `error_count` is 0, and there is no execution `error`. See [layout-lint.md](layout-lint.md).
7. Call `read` on the current source image and this round's current-page screenshot. Check text, numbers, charts, cropping, z-order, wrapping, and editability. When applicable, temporarily edit one native text object in a review copy and confirm that no source-image glyphs remain beneath it. Do not change the accepted output file during that probe.
8. Record the static and visual results for the current page. On failure, repair only the current page and rebuild. If an earlier passed page regresses, repair and re-gate that page first.
9. Start page N+1 only after every required check for page N passes. If a check is unavailable, restore it. If it cannot be restored, report the blocker. Do not skip the check or mark the page as passed.

Diagnostics default to `.editable.pptx.reconstruction/` beside the output. This round's screenshots are `preview/slide-N.png`. Each build refreshes those files. Read this round's result. Do not reuse an earlier round's review to approve the current page.

The runner still performs schema checks, one atomic batch for this cumulative file, an editability audit, renders, and source-image comparison. Mean normalized MAE must stay at or below 8%, and no slide in this round may exceed 15%. Those automatic thresholds do not replace a model `read` of the current page. A successful build means only that this cumulative file passed the runner. It does not mean the current page is accepted or that the deck is delivered.

OfficeCLI HTML screenshots provide evidence only for the same rendering stack. Before claiming fidelity across viewers, fonts, animations, media, or playback, open the final deck in the target PowerPoint or WPS application.

## 5. Save Commands by Page

Fragments may store already-passed pages and the current page. They are a save format, not a way to generate later pages or to run one final build. The primary agent advances one page at a time. Do not assign later slides to `worker` subagents.

```text
commands/
|-- 00-presentation.json
|-- slide-01.json  # passed
`-- slide-02.json  # current page; do not create slide-03.json before this page passes
```

Every file remains a plain native OfficeCLI array. Put the root presentation `set` command in `00-presentation.json`. Begin every `slide-NN.json` with a slide named `slide-NN`, and keep its references within `/slide[N]`. This round may replace `--commands officecli-commands.json` with `--fragments commands`, but the directory may contain only passed pages and the current page. Fragment sorting and reference checks do not replace the per-page gate.

## 6. Full-Deck Review and Delivery

After every page has passed its per-page gate, run static checks and visual review on the complete deck. That review is not the first time a page is checked. On findings, repair the affected page, then rerun the affected page gate and the full-deck checks. Publish only after those checks pass.

During the initial reconstruction, edit the matching page commands and rebuild the cumulative file. After delivery or external editing, treat the PPTX as authoritative and use standard OfficeCLI edits with stable paths. Do not overwrite user edits from a stale command array.
