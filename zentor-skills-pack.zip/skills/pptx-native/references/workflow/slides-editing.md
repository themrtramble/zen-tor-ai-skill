# Edit an Existing PPTX

Use this workflow when the user has an existing deck and wants changes made to it. Also use it for any edit, addition, or deletion requested in a later turn for a deck produced earlier. Reread this entire document before editing. Do not run `set` based on memory from a previous turn.

The source must be a local PPTX uploaded in this turn or produced in an earlier turn.

Maintain exactly one delivery file for subsequent work. Copy the source before editing it. Do not overwrite the user's original. Call `publish_file` with `is_artifact: true` only after validation passes, not immediately after copying.

```bash
cp source.pptx deck.pptx
officecli view deck.pptx outline --json
officecli get deck.pptx / --depth 1 --json
python3 /opt/kernel/skills/pptx-native/scripts/reconstruct.py audit-pptx deck.pptx
```

If the result is `route: reconstruct`, do not force edits into this file. Reconstruct it with [image-reconstruction.md](image-reconstruction.md). Continue this workflow only for `edit-existing`.

## Scope

If the user names a slide or object, edit only that area. A global request, such as improving the full deck or adding more charts, requires reviewing the entire deck. Do not change content outside the user's request.

| Input | Handling |
| --- | --- |
| PPTX plus edit instructions | Use that PPTX as the primary source. |
| `deck.pptx` from a previous turn | Run `get` again. Do not rebuild it from a stale command plan. |
| Source deck plus a new template, with a request to unify the style | Follow template editing. The template carries the result, and the source deck supplies the content. |
| Two decks to merge | Choose the primary source, then map slides into it. |
| PPT plus DOCX, PDF, XLSX, or images | Use the PPT as the primary source. Treat the other files as facts or assets. |

## Editing Method

Run `get` to obtain a stable path. Then run `officecli help pptx set <element> --json`; replace `set` with `add` for a new element. Use only properties allowed by the schema. Do not guess `@id` values. See [element-recipes.md](element-recipes.md) for element recipes and text geometry. Run `officecli save deck.pptx` after each batch. For a generated background, use `GenerateImage` and place a full-bleed `picture` behind the content. See Step 3 in `SKILL.md`.

## Validation

```bash
officecli validate deck.pptx --json
python3 /opt/kernel/skills/pptx-native/scripts/layout_lint.py deck.pptx
```

See [layout-lint.md](layout-lint.md) for layout checks and [validation-visual.md](validation-visual.md) for screenshot review.
