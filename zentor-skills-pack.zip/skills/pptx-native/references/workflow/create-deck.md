# Create a Deck

Use this workflow to coordinate a complete new presentation. Assigned workers use [Create Slides](create-slides.md).
For a typical 16–20-slide task, aim for about 30 minutes: five for preparation, 18 for creation, and seven for final review.
Include source reading in preparation when required. This allocation is guidance, not a cutoff. Record overruns and preserve all quality requirements.

## Prepare the Shared Brief and Style

1. Identify the requested purpose, audience, slide count, sections, sources, style, and whole-slide bullet limit. Reuse a supplied outline. Clarify only unreadable materials or conflicting mandatory requirements.
2. When reference documents exist, download and read every required document before dispatch, and record shared ambiguities with their locations in `brief.md`. Otherwise, prepare the outline directly from the request.
3. Select a design system through [slide-taxonomy.md](../style/slide-taxonomy.md) and its scenario guide. Save `style.json` as shown below. Use the [default slide regions](create-slides.md#shared-style-and-slide-regions), with any design overrides recorded in the brief.
4. Save `brief.md` with shared requirements, consecutive slide ranges, and ordered topics for each assignment. Include source paths, locations, and shared ambiguities when reference documents exist.

Dispatch after these steps. Workers choose wording and visuals within their assigned topics; they prepare captions, notes, tables, and figure crops.
Keep shared requirements in `brief.md`. Do not duplicate the workers' authoring work before dispatch.
Use the selected design system's fonts and the component's table styles unless the user requests overrides.

Map the design system to this shared style. `fonts` accepts `header` and `body`; other overrides belong in component properties.

```json
{
  "palette": {"primary":"16324F","secondary":"B9CCD9","accent":"23866D","muted":"666666","bg":"FFFFFF","on_bg":"262626"},
  "fonts": {"header":"Noto Serif","body":"Noto Sans"}
}
```

Validate the shared style once before dispatch:

```bash
PYTHONPATH=/opt/kernel/skills/pptx-native python3 -c 'import json, sys; from components.helpers import coerce_style; coerce_style(json.load(open(sys.argv[1]))); print("Style is valid")' style.json
```

## Assign Slide Ranges

Divide the deck into at most four independent assignments. An assignment is one worker's full slide range. Inside it, [Create Slides](create-slides.md) still writes and reviews one batch of one or two consecutive slides at a time.
Balance authoring work while preserving slide order.
Dense tables, equations, and figure extraction require more work than covers or short conclusions.
Assign each worker an exclusive directory and temporary PPTX. Only the coordinator writes the final presentation.
Use `worker`; read-only `scout` and `reviewer` agents cannot create slides.

Include every assignment in one `subagent` call in `tasks` mode. Each independent session needs its own assignment and shared file paths.
Adapt this task entry without repeating the brief's slide descriptions:

```json
{"agent":"worker","task":"Create final slides 5–9. Read /opt/kernel/skills/pptx-native/SKILL.md and follow the worker route through create-slides.md. Shared requirements and outline: /home/user/.workspace/brief.md; style: /home/user/.workspace/style.json; exclusive directory: /home/user/.workspace/workers/b. Return the temporary PPTX, exported commands, mapping, slide-checks.md, and review directory. Do not publish."}
```

When reference documents exist, add their original and extracted-text paths to each task and require source-faithful content with per-slide source records.
Otherwise, omit document paths and source preparation.
Without `subagent`, complete the same assignments serially through [Create Slides](create-slides.md). Still write and review one batch at a time inside the current assignment.

## Merge the Passing Slides

Require the [worker export and handoff](create-slides.md#worker-export-and-handoff) for every assignment.
Merge exported commands in final slide order. Verify that each `mapping` starts at the next slide in the final presentation.
Create a new final presentation once:

```bash
officecli create final.pptx
```

For an existing target, continue from its current slide count. Do not recreate it or replay imported commands.
Set `COMMANDS` to the worker's returned path. Use its mapped slide numbers and the user's bullet limit:

```bash
python3 /opt/kernel/skills/pptx-native/scripts/review_batch.py final.pptx \
  --input "$COMMANDS" --pages 5 6 7 8 9 --max-bullets 5 --out review
```

Review the fresh final-slide screenshots under [Step 7 of SKILL.md](../../SKILL.md#step-7-complete-each-slide).
For defects, use [in-place repairs](create-slides.md#in-place-repairs).
Finish with [Step 8: Validate and Deliver](../../SKILL.md#step-8-validate-and-deliver).
