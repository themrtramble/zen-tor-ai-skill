# Create Slides

Use this workflow to create or append assigned slides with native OfficeCLI component functions.
It covers input, execution, in-place repairs, and worker handoff. Follow SKILL.md for task routing and quality requirements.

## Prepare the Assigned Slides

Read `style.json`. For parallel creation, also read the shared `brief.md` and stay within the assigned topics, slide range, and exclusive directory.
Workers do not replan the whole deck or delegate further.
When the assignment includes reference documents, read the assigned source sections before writing. Preserve required content, units, baselines, and unfavorable results; source numbers override conflicting outline numbers. Record the sources used in `review/slide-NN.md`.
Otherwise, skip source extraction and cropping.

An assignment is the worker's full slide range. A batch is one or two consecutive slides inside that assignment.
Start with one batch. Reuse its passing font and layout settings for the remaining batches in the same assignment.
Call the documented component functions directly. Do not develop a custom generator or inspect implementations before an actual unexplained error.
Investigate font coverage only when a rendered screenshot shows a missing glyph.
Use the sandbox's `python3`; font and image measurement dependencies are already installed.

## Shared Style and Slide Regions

Load the complete `style.json` object and pass it to each component function.
Use its selected fonts and component defaults. For supported overrides, see the [component reference](../../components/README.md).

A 16:9 slide is 33.87 × 19.05 cm. These are starting regions for content slides. The coordinator may adjust them for the design system and record them in the outline:

| Element | origin (cm) | size (cm) |
| --- | --- | --- |
| Title | 1.4, 0.7 | 31, 1.8 |
| Header rule | 1.4, 2.8 | Width 31; height 0.5 pt |
| Body text, table, or complete figure | 1.4, 3.2 | 31, 13.8 |
| Source | 1.4, 18.1 | 28, 0.6 |
| Slide number | 31, 18.1 | 1.3, 0.6 |

Set these regions through each function's `origin` and `size`. If a title needs more height, move the header rule and body top down together. Lay out the cover separately for its title length.

## Input

Create the presentation once with `officecli create deck.pptx`. Do not recreate an existing file.
Use a short Python script for each consecutive batch. Combine component results into one native OfficeCLI command array.
Read the current slide count with `get_slide_count`; append each slide in order, starting at that count plus one.
An independent temporary presentation begins at slide 1; its footers show the assigned final slide numbers.
Add a title with `add_titled_slide` and speaker notes with a native `notes` command on every slide.
Notes follow the SKILL.md content requirements. Title defaults are 28 pt, `on_bg`, and bold. A dark cover can use `color="FFFFFF"`.
Pass a different `style` to an individual function when the design requires an override.

The shared `style.palette.bg` also sets the background of new slides.
The title, text, and rule functions accept hexadecimal colors or palette fields such as `primary`, `muted`, and `on_bg`.

Save this example as `batch.py`. Replace its sample content and regions with the assigned slide's design:

```python
import json
import sys
from pathlib import Path

sys.path.insert(0, "/opt/kernel/skills/pptx-native")
from components import add_table, add_text, add_titled_slide, get_slide_count, write_commands

style = json.loads(Path("style.json").read_text())
page = get_slide_count("deck.pptx") + 1
slide = f"/slide[{page}]"
commands = add_titled_slide(slide, ("1.4cm", "0.7cm"), ("31cm", "1.8cm"), "Research result", style)
commands.extend(add_table(
    slide, ("1.4cm", "3cm"), ("28cm", "5cm"),
    ["Method", "Score", "Time (s)"], [["Baseline", "80.0", "10"], ["Proposed", "82.0", "8"]],
    style, emphasis_rows=[2], font_size=16, name="results",
))
commands.extend(add_text(
    slide, ("1.4cm", "8.3cm"), ("28cm", "0.8cm"),
    "Higher score and shorter runtime are better.", style, font_size=12, padding="0cm", name="caption",
))
commands.extend(add_text(
    slide, ("1.4cm", "10cm"), ("28cm", "4cm"),
    "Main finding\nPractical limitation", style, font_size=20, bullets=True, name="takeaways",
))
commands.extend(add_text(
    slide, ("1.4cm", "18.1cm"), ("28cm", "0.6cm"),
    "Source: report, p. 3, Table 1.", style, font_size=10, padding="0cm", name="source",
))
commands.extend(add_text(
    slide, ("31cm", "18.1cm"), ("1.3cm", "0.6cm"), "4", style,
    font_size=10, padding="0cm", align="right", name="number",
))
commands.append({"command": "add", "path": slide, "type": "notes", "props": {
    "text": "State the finding. Explain the baseline and units. Describe the limitation.",
}})
write_commands(commands, "commands.json")
print(f"Review pages: {page}")
```

## Component Reference

Pass component data and options as function arguments. Read the relevant reference when selecting options; do not query wrapped OfficeCLI schemas first.

| Component | Required properties | Parameters and behavior |
| --- | --- | --- |
| `text` | `text` | [Fonts, fixed-point line spacing, fitting, and bullets](../../components/README.md#native-titles-and-body-text) |
| `table` | `headers`, `rows` | [Automatic widths, measured row heights, alignment, and emphasis](../../components/README.md#native-tables) |
| `picture` | Absolute `src` | [Complete-image scaling without cropping](../../components/README.md#complete-pictures) |
| `chart` | `categories`, `series`, `category_label`, `value_label` | [Native comparison charts, units, and labels](../../components/README.md#native-comparison-charts-and-picture-repairs) |
| `rule` | None | [Color and thickness](../../components/README.md#native-rules) |

Other composite diagrams use the same Python interface. The [component JSON CLI](../../components/README.md#json-and-command-line-usage) remains optional.
For unwrapped elements or chart types, query the corresponding OfficeCLI schema, such as `officecli help pptx add chart --json`.

Choose required table rows and columns before allocating the region. Use the component's reported minimum height to reposition tables and captions together.
See [table capacity](../../components/README.md#table-capacity) for planning guidance. For custom edits to an existing table, use direct OfficeCLI `set table-cell` commands and read the relevant schema first.

## Execute and Review

Build the complete command array before applying it. Component functions measure and validate their inputs without modifying the PPTX.
If a component reports insufficient space, correct its region and move following captions together. Rebuild the array after correcting the input.
Apply the generated commands once, using the printed page numbers:

```bash
python3 batch.py && python3 /opt/kernel/skills/pptx-native/scripts/review_batch.py deck.pptx \
  --input commands.json --pages 1 --max-bullets 5 --out review
```

Set `--pages` to every slide in the batch and the bullet limit to the user's requirement.
The `&&` prevents applying an older command file when component validation fails.
Read the complete result, including `ok`, `pages`, `record`, and `screenshots`.
For `ok:false`, inspect `batch.success` first. If writing succeeded but review failed, use [in-place repairs](#in-place-repairs).
Do not replay a successful creation batch or delete and rebuild the file. Do not truncate output or hide exit status with `tail`.
After `ok:true`, inspect each `review/slide-NN.png` under [Visual Screenshot Validation](validation-visual.md). Update both `slide-checks.md` and `review/slide-NN.md` under [Step 7 of SKILL.md](../../SKILL.md#step-7-complete-each-slide).
For the next batch, prepare a new script and command file for the same target PPTX. Do not replace slide numbers manually inside text.
After every worker slide passes, hand off using the export command at the end of this document.

## In-place Repairs

`fix.json` is an OfficeCLI command array containing `set`, `move`, or `remove`. Use the element paths returned by lint. Native repair commands bypass component functions. Replace palette names such as `muted` with their six-digit hexadecimal values from `style.json`.
To inspect other elements, run `officecli get deck.pptx '/slide[3]' --depth 3 --json`. The node path is positional; `get` has no `--path` option. Matched nodes are in `data.results`; slide elements are in each result's `children`.
Each child has a `path`. Its `format` object contains `id`, `name`, `x`, `y`, `width`, and `height`.
Read `child["format"]["x"]`, for example. Use `child["path"]` unchanged in the repair command; do not construct a path from guessed identifiers.
Raw XML paths containing `cSld`, `spTree`, or `spPr` do not expose semantic position properties.
For unmatched elements or unsupported properties, correct the path instead of repeating the command.
For example, use this structure to fix a header rule overlapping a title or an overly wide short text box. Replace paths and dimensions with this run's review results and actual layout:

```json
[
  {"command":"set","path":"/slide[1]/shape[@id=100000]","props":{"y":"2.8cm"}},
  {"command":"set","path":"/slide[3]/shape[@id=100023]","props":{"x":"5cm","width":"24cm"}}
]
```

```bash
python3 /opt/kernel/skills/pptx-native/scripts/review_batch.py deck.pptx \
  --input fix.json --pages 1 3 --max-bullets 5 --out review
```

A width repair must fit the actual text. Preserve the font size and inspect the fresh screenshot. Include only changed properties in the repair file; do not copy creation commands. Existing `commands.json` contains creation commands; `batch.json` is an execution log that does not need parsing for repairs.

To refit an existing complete picture, retain its original source image and use the same component with `target`.
The region is available space, not the picture's forced width and height. Directly setting both dimensions can distort the figure.
Save this component-only input as `picture-fix.json`, replacing the source and observed picture path:

```json
{"style":{"palette":{"primary":"16324F","secondary":"B9CCD9","accent":"23866D"}},"components":[
  {"component":"picture","slide":"/slide[3]","origin":["1.4cm","3.3cm"],"size":["31cm","7.8cm"],
   "props":{"src":"/home/user/.workspace/figure.png","target":"/slide[3]/picture[@id=100022]"}}
]}
```

```bash
python3 /opt/kernel/skills/pptx-native/components/cli.py plan --spec picture-fix.json --out fix.json
python3 /opt/kernel/skills/pptx-native/scripts/review_batch.py deck.pptx --input fix.json --pages 3 --out review
```

This emits a geometry-only `set` command. The existing image, identifier, and slide content remain intact.

To recheck unchanged slides, omit `--input`. Do not pass an empty repair array:

```bash
python3 /opt/kernel/skills/pptx-native/scripts/review_batch.py deck.pptx \
  --pages 1 3 --max-bullets 5 --out review
```

This saves, checks, and captures fresh screenshots without adding slides or changing their content.

To generate commands without writing, run only `python3 batch.py`.
Before writing, `review_batch.py` rejects append batches that target existing slides or omit new slides from `--pages`.

## Worker Export and Handoff

After every assigned slide passes review, export the actual passing temporary presentation.
`export_slides.py` supports text, shapes, embedded pictures, native tables, native charts, and notes from the same OfficeCLI version.
Preserve exported chart data and styles as native commands. The exporter rejects arbitrary template relationships, animations, and raw XML with external relationships.
Report unsupported elements so the coordinator can create them in the final presentation while preserving requirements.

```bash
python3 /opt/kernel/skills/pptx-native/scripts/export_slides.py workers/b/deck.pptx \
  --pages 1 2 3 4 5 --start 5 --out workers/b/export
```

Use actual paths, temporary slide numbers, and the assigned final starting slide number. Check returned `ok`, `commands`, and `mapping`. Return the temporary PPTX path, commands path, mapping, `slide-checks.md` path, and review directory. Keep source locations and per-slide evidence in `review/slide-NN.md`. Report unresolved issues explicitly; otherwise keep the handoff within 100 words. Do not repeat slide content or passing checklists in the response. Workers do not publish temporary presentations.
