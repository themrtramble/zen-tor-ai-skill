# Structure and Layout Validation

Run `layout_lint.py` on every modified slide after writing or reconstruction. Do not skip this check to save time. `error_count` must be 0 before continuing to the next slide or delivering the deck. See [validation-visual.md](validation-visual.md) for visual-quality review.

The script returns exit code `0` for reports, including layout findings and execution errors. Always read the JSON details: `ok`, `error_count`, and `issues` describe layout results; `error` explains why a check could not run. Exit code `0` does not mean the deck passed validation.

Run these commands for both newly created and existing files:

```bash
python3 /opt/kernel/skills/pptx-native/scripts/layout_lint.py deck.pptx
python3 /opt/kernel/skills/pptx-native/scripts/layout_lint.py --inspect deck.pptx
```

The script also runs:

| Command | Purpose |
| --- | --- |
| `officecli validate deck.pptx --json` | Validate the Open XML structure. |
| `officecli view deck.pptx issues --json` | Report overlaps and other issues detected by the CLI. |
| `officecli get deck.pptx / --depth 2 --json` | Read element bounds, z-order, and text. |
| `officecli view deck.pptx outline --json` | Produce the `--inspect` summary. |

Each issue includes a `message` and `hint`. Apply `set`, `move`, or `remove` to its stable path, then rerun the script. If an overlap is intentional, leave it for screenshot review.

## What Lint Cannot Check

Review contrast, visual cropping, and style consistency manually. Read the file back with `get` and confirm:

- The slide count and modified stable-path content match the plan.
- The deck has no blank slides, broken images, or leftover template text.
- Short transparent text does not have a full-slide selection box.
