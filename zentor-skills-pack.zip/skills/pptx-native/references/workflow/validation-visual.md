# Visual Screenshot Validation

Use this check after `layout_lint.py`. If screenshots are unavailable, rely on lint results and do not claim that visual review occurred. Use the "Visual Quality Floor" in [slide-taxonomy.md](../style/slide-taxonomy.md) as the aesthetic standard. This document only explains how to capture screenshots and how to respond to visible issues.

Fix only objective defects by moving or resizing elements, reducing font size, or correcting contrast. Do not change colors or fonts, rewrite copy, or add and remove otherwise valid elements based on taste. Judge intentional overlaps in the screenshot instead of separating them.

`officecli view screenshot` writes an image to the workspace but does not place it in model context. Capture slides with this OfficeCLI command only. Do not invoke `chrome`, `google-chrome`, Playwright, camoufox, or any other browser tool. The sandbox provides `google-chrome-stable` on `PATH`; OfficeCLI locates it. Immediately call `read` on each generated slide screenshot. A successful screenshot command without a `read` call does not count as visual review.

```bash
officecli view deck.pptx screenshot --page 1 --out review/slide-01.png \
  --screenshot-width 1280 --screenshot-height 720 --render html
```

```text
review/slide-01.png
[pages] total=1
```

Call `read` on the `--out` path. Inspect one slide per `read` call. Do not substitute a contact sheet or thumbnail for single-slide review. Do not inspect only a partial screenshot of selected elements. Assume a problem exists first, then check for text overflow and clipping by shapes or the canvas.

The pixel values below apply only to `1280x720` screenshots. The final standard is a `0.5"` slide margin and `0.3"` spacing between blocks. If the model input is resized further, scale the pixel values proportionally.

## Inspection Checklist

Use this checklist for every slide. It can also serve directly as a prompt:

```text
Visually inspect these slide screenshots one at a time. Assume that problems exist and try to find all of them.

Check especially for:
- Element overlap: text obscured by shapes, images, or charts; lines crossing text; shapes or labels stacked unintentionally.
- Text overflow or clipping near slide edges, text-box boundaries, or shape boundaries.
- Text that wraps to multiple lines, or individual content that exceeds the maximum text length.
- Misplaced decoration: dividers, accent lines, or label backgrounds designed for one line but colliding with wrapped titles or body text, or leaving abnormal gaps.
- Source notes, footers, or page numbers colliding with content above.
- Elements placed too close together. On a 1280x720 screenshot, flag gaps smaller than about 29 px, which corresponds to 0.3 inches.
- Uneven spacing, with excessive whitespace in one area and crowding in another.
- Insufficient slide margins. On a 1280x720 screenshot, flag margins smaller than about 48 px, which corresponds to 0.5 inches.
- Unstable alignment among columns, shapes, icons, or peer elements.
- Broken image or chart rendering: blank, distorted, low-resolution, unreadable key content, or missing expected graphics.
- Text inside generated background or cover artwork. Generated artwork must not contain text; regenerate or replace it when found.
- Insufficient text contrast, such as light-gray text on beige or another light background.
- Insufficient icon contrast, such as a dark icon on a dark background without a light circle or backing plate.
- Text boxes that are too narrow and cause unnecessary frequent wrapping.
- Leftover placeholders, default template copy, or unreplaced content.
- In repeated row or table structures, inconsistent x origins or widths for columns with the same role, such as label, description, or value columns.

Additional table and chart checks:
- Confirm that text, numbers, labels, and legends are clear and not clipped, overlapping, or excessively wrapped.
- Confirm that equivalent table rows and columns align and use consistent widths, heights, and number formats.
- Confirm that chart titles, units, legends, and data series correspond correctly.
- When the slide requires precise comparison, confirm that key values can be read directly.
- Confirm that accent colors identify the intended focus without creating multiple competing focal points.

List issues or suspicious areas separately for every slide, including minor issues.

Report all findings, including minor ones.
```

| Visible issue | Action |
| --- | --- |
| Text overflows or is clipped by a shape or the canvas | Enlarge the text box, reduce the font size, or move content to the next slide. |
| Text overlaps text, or body text covers an important part of an image | `move` or shrink the covering element, then rerun `layout_lint.py`. |
| Light-gray text on a light background, or a dark icon on a dark background | `set` the text `color`, background, or fill. |
| Edge clearance below 0.5 inches, about 48 px, or block spacing below 0.3 inches, about 29 px | Move content inward or increase spacing between adjacent blocks. |
| One side is empty while the other is crowded | Redistribute column widths or split the crowded side. |
| Peer columns or cards have misaligned top or bottom edges | Standardize `x`, `y`, and `height`. See taxonomy rule 8 for equal-width distribution. |
| A footer or source note collides with content above | Move body content up or the footer down, leaving a clear gap. |
| A title has an underline, color strip, or decorative block beneath it | Remove the decoration and use whitespace or background color for hierarchy. Preserve decorations supplied by the user's template. |
| A text box is too narrow and wraps one word or character per line | Widen the text box. Do not force the content to fit by reducing font size. |
| Short labels in the same group wrap | Keep dates, statuses, IDs, and similar labels on one line. Set a common width based on the longest item. |
| An image is stretched or badly cropped, or text covers a face, product, or logo | Read back picture dimensions and `crop` with `get`. Preserve the source aspect ratio and move text away. |
| Placeholder text, broken images, or blank slides | Replace with real copy or assets. Add content to blank slides or remove them. |
| A chart is blank or does not match its data | Run `officecli help pptx set chart --json`, then change `data` or `chartType`. Do not edit XML manually. |
| Generated background artwork contains text | Use `EditImage` or rerun `GenerateImage`. Do not treat generated text as body copy. |
| Same-role elements drift across repeated rows because adjacent labels have different lengths | Give that role the same x origin and width on every row. A short label is not a reason to move that row's content. |

Fix every visual-quality-floor violation, blank slide, broken image, overlap, and obvious clipping before delivery.

Record a `pass` or `fix` decision for every slide with the rubric below. For slides containing charts, also assess precise chart readability.

| Criterion | Pass standard | Fix signal |
|---|---|---|
| Readability | Titles, body text, labels, and key numbers are readable. Contrast is sufficient, and text levels have clear visual spacing. | Text is clipped, too small, low-contrast, or unreadable. Adjacent text is so close that it appears joined. |
| Layout | Main content is not unintentionally obscured. Slide margins and bottom whitespace are appropriate. | Overlap, overflow, image clipping, edge crowding, bottom crowding, apparent text collisions without geometric intersection, or drifting origins for same-role columns across rows. |
| Visual hierarchy | The main conclusion, primary visual, and supporting information are immediately distinguishable. | Every element has equal weight, the primary visual is too small, or the slide becomes a stack of text. |
| Content integrity | No blank slide, broken image, placeholder, or incorrect slide order exists. Diagrams match the slide's role. | A blank or broken slide, missing image, leftover template copy, or content inconsistent with the plan. |
| Precise chart readability, when a chart is present | If the conclusion depends on exact comparison, ranking, or a threshold, readers can obtain each key value directly through chart data labels or an equivalent corresponding data table or annotation. | Key values can only be estimated from an axis, decisive data labels are absent, or legends cannot be matched to series. Point labels are optional for charts used only to show a trend without an exact conclusion. |

For every chart, first ask whether the slide requires the reader to make a precise judgment:

- **Yes:** The reader must compare group scores, rank items, test a threshold, assess a budget or target difference, or select an option from the chart. Mark `fix` if direct values or an equivalent data table are absent.
- **No:** The chart only communicates an upward or downward trend, a qualitative distribution, or a structural relationship, and the title or body already states the conclusion. Point-by-point labels are optional, but axes, legends, series, and key annotations must remain readable.

Use this format for validation records:

```text
| slide_id | screenshot | status | findings | action |
|---|---|---|---|---|
| 01 | review/slide-01.png | pass | hierarchy and contrast clear | - |
| 02 | review/slide-02.png | fix | bottom labels are clipped | enlarge text box, then rescreenshot |
```

If screenshots were actually reviewed, write "screenshot verified" only for slides that received an individual `read` call on a file recaptured in this review pass, plus a recorded `pass` or `fix` result. A saved screenshot, a Step 7 construction screenshot, a successful batch render, review of only key slides, or contact-sheet review does not count. If screenshots are unavailable, rely on static checks and do not claim visual review.
