# Create a New Deck from a Template

Use this workflow when the user provides a PPTX as a template and asks for a new presentation based on it. The template determines the visual design. The user's content and requirements determine what the deck says. Reread this entire document before making changes.

Do not create a blank deck and redraw the template from memory. Copy the template as the only target file, then edit its text, data, and required structure. Do not upload the copied work in progress. Call `publish_file` with `is_artifact: true` only after every target slide passes lint.

```bash
SKILL_DIR=/opt/kernel/skills/pptx-native
cp template.pptx deck.pptx
officecli view deck.pptx outline --json
officecli get deck.pptx / --depth 1 --json
officecli view deck.pptx screenshot --page 1 --out template/slide-01.png \
  --screenshot-width 1280 --screenshot-height 720 --render html
```

Capture every slide, then call `read` for each screenshot. Saving a screenshot without calling `read` does not count as reviewing it. Use stable `get` paths to locate reusable titles, framing elements, charts, and images.

## Inheritance Priority

1. Preserve complete slides with the same role, such as covers, contents, section dividers, and closing slides.
2. Preserve the framing elements, including backgrounds, logos, headers, footers, and decorations. Edit only the main content area.
3. Restructure only when the content does not fit. Continue to use the template's colors, fonts, and geometry.

Replace the template's sample text and section structure with the user's content. Keep the contents slide, section dividers, and navigation consistent. Do not delete elements outside the edit plan merely to make the deck look "clean."

## Write Changes

Check the schema first. Run `officecli help pptx add <element> --json` before adding an element. Run `officecli help pptx set <element> --json` before modifying one. Do not combine these commands with `|`. Make changes in small batches and read them back with `get` after each batch.

```bash
officecli set deck.pptx '/slide[1]/shape[@id=7]' --prop text='Conclusions for This Quarter' --json
officecli save deck.pptx
python3 "$SKILL_DIR/scripts/layout_lint.py" deck.pptx
```

Delete unplanned template slides only after every target slide passes. Keep at least one slide. See [element-recipes.md](element-recipes.md) for commands.

If the template consists of flattened full-slide images, follow [image-reconstruction.md](image-reconstruction.md) before applying the new content. Do not edit text on a bitmap.
