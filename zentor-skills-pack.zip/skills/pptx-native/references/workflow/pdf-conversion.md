# Convert a PDF to a Native PPTX

Use this workflow when the user asks to **convert a PDF to PPT, reproduce it 1:1, restore its layout, or make its pages editable slides**. The source-page pixels are authoritative. Do not choose a different design system or rewrite the outline by topic.

A request to "create a presentation from this PDF" with summarization, a new style, or a flexible slide count is not a conversion. Follow Section 2, "Create a New Deck," in `SKILL.md`, and use the PDF only as an asset in Step 3. A PDF attachment alone does not select this workflow.

Do not extract only the text with `pdftotext` and recreate the layout from memory. Do not use python-pptx, unpack the ZIP, or run `ppt pack` on full-page PDF images to produce a non-editable deck. OfficeCLI has no PDF import command.

## 1. Inspect the Source

Record the page count and orientation. Do not force portrait A4 pages into 16:9.

```bash
pdfinfo source.pdf
mkdir -p source
```

If `pdfinfo` is unavailable, use Python to inspect the page count and `page.rect` with PyMuPDF `fitz` or another installed PDF library. The presentation `slideWidth` and `slideHeight` in `officecli-commands.json` must match the PDF page aspect ratio.

## 2. Rasterize Pages as Reconstruction Sources

Render every page to `source/slide-N.png`, where `N` starts at 1 and matches the filenames expected by `reconstruct.py build --source-renders`. Use a resolution high enough to read body text. The **pixel width and height must equal** the later `--screenshot-width` and `--screenshot-height` values passed to `reconstruct.py`. Otherwise, the visual gate fails immediately because the dimensions differ.

For 16:9 pages, default to `2048x1152`. For portrait pages, adjust the height proportionally. For example, at a width of 2048, use `round(2048 * page height / page width)`. Do not add black bars.

```bash
pdftoppm -png -r 144 source.pdf source/page
# Rename or resize source/page-1.png to source/slide-1.png, and so on.
```

If `pdftoppm` is unavailable, use `page.get_pixmap` to create PNG files, then resize them to the dimensions above. Do not extract only the text. Treat page renders as authoritative for images, tables, and formulas in the attachment. You can save embedded images separately for use as `picture` elements, but do not crop them.

Open the PNGs and verify page order and completeness before reconstructing the first page.

## 3. Reconstruct from the Page Images

Read [image-reconstruction.md](image-reconstruction.md) in full. Match the PDF page count. Do not add or remove slides unless the user explicitly asks to skip or merge pages.

The conversion must use **`build`** because that entry point includes the source-image visual gate.

Keep the first `deck.pptx` in the workspace. Do not upload work in progress.

## 4. Validate

After reconstruction, run the checks in [image-reconstruction.md](image-reconstruction.md). See [layout-lint.md](layout-lint.md): exit code `0` is not a pass. Call `publish_file` with `is_artifact: true` only after lint and visual review pass. See [validation-visual.md](validation-visual.md) for screenshot instructions.
