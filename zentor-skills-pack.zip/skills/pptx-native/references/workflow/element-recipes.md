# OfficeCLI PPTX Element Command Interface

Use this document to compile user intent into OfficeCLI commands. It is not a complete static API mirror. The interfaces below were checked against the machine-readable help for OfficeCLI 1.0.143. At runtime, the schema returned by the installed binary remains authoritative.

## Compilation Rules

1. Identify the target file, parent path, element type, and action.
2. Before adding an element, run `officecli help pptx add <element> --json`. Replace `add` with `set` before modifying one.
3. Use only properties marked `true` for the selected action. A readable property is not necessarily writable or available during creation.
4. Add elements with `--json`, and save the returned stable `@id=` or `@name=` path.
5. Read the element back with `get <stable-path> --json` before generating later commands.

Common intent routing:

| User intent | OfficeCLI element | Typical parent path |
| --- | --- | --- |
| Add a slide | `slide` | `/` |
| Add a title, body text, label, or geometric shape | `shape` | `/slide[N]` |
| Add a data chart | `chart` | `/slide[N]` |
| Add a table | `table` | `/slide[N]` |
| Add an image | `picture` | `/slide[N]` |
| Add a line or arrow | `connector` | `/slide[N]` |
| Add a group | `group` | `/slide[N]` |
| Add speaker notes | `notes` | `/slide[N]` |
| Add animation | `animation` | `/slide[N]` or the schema-defined parent |
| Add a transition | `transition` | `/slide[N]` |

## Minimal Interface

Create the file and first slide:

```bash
officecli create deck.pptx
officecli add deck.pptx / --type slide --prop title='Quarterly Review' --prop background=FFFFFF --json
```

Add text. PPTX does not require a separate textbox command. Use a `shape` with a `text` property for a standard text box:

```bash
officecli help pptx add shape --json
officecli add deck.pptx '/slide[1]' --type shape \
  --prop text='Revenue increased 25% year over year' \
  --prop x=2cm --prop y=3cm --prop width=7cm --prop height=1.5cm \
  --prop align=center --prop valign=middle \
  --prop font='Noto Sans CJK SC' --prop font.ea='Noto Sans CJK SC' \
  --prop size=24pt --prop color=333333 --prop fill=none --json
```

### Text-Box Geometry Rules

- The bounds of a transparent text-only shape must match the intended text block. This applies to short titles, labels, annotations, wordmarks, and KPI values.
- Do not make such shapes full-slide width or fill the remaining column width by default. Set appropriate `width` and `height` values and retain required padding.
- Do not rely on `autoFit=shape` to rewrite stored width and height during generation. OfficeCLI can preserve the property, but `get` can still return the original bounds. Web editors and other readers can use those bounds directly for selection boxes.
- For a new shape with `text`, center the text horizontally and vertically by default with `--prop align=center --prop valign=middle`. Center or right alignment alone does not justify preserving full-column width. First tighten `width` to the text block, then adjust `x` to preserve the visual center or right edge.

#### Keep a Wider Text Box Only When:

- Body text needs a fixed wrapping width.
- A template placeholder must retain its original layout bounds.
- The shape has a visible fill or outline, making its geometry part of the design.

#### Check the Following After Generation:

1. Run `get --json` on the stable path and confirm that `width` and `height` match the intended text block.
2. Render the slide and confirm that text is not clipped and that wrapping and alignment match the design.
3. For short transparent text, confirm that its selection box does not unintentionally cover the full row. If font metrics differ, adjust explicit width and height and render again. Do not use a fixed "character count times constant" formula.

### Add a Native Chart

`chartType` and `data` are important creation inputs. Recheck the schema before changing the chart type or replacing the complete data set. Do not assume they support `set`.

```bash
officecli help pptx add chart --json
officecli add deck.pptx '/slide[1]' --type chart \
  --prop chartType=column --prop title='Quarterly Revenue' \
  --prop categories='Q1,Q2,Q3,Q4' \
  --prop data='Revenue:10,14,18,25;Cost:5,7,9,11' \
  --prop x=2cm --prop y=5cm --prop width=18cm --prop height=10cm --json
```

### Add a Native Table

```bash
officecli help pptx add table --json
officecli add deck.pptx '/slide[1]' --type table \
  --prop data='Quarter,Revenue,Cost;Q1,10,5;Q2,14,7' \
  --prop x=2cm --prop y=5cm --prop width=18cm --prop height=7cm \
  --prop style=medium2 --prop headerFill=4472C4 --json
```

### Add a Picture

`src` can be a local file, URL, or data URI. It is an add/set input and is not returned unchanged by `get`.

```bash
officecli help pptx add picture --json
officecli add deck.pptx '/slide[1]' --type picture \
  --prop src='/home/user/.workspace/assets/logo.png' \
  --prop x=20cm --prop y=1cm --prop width=4cm --prop height=2cm \
  --prop name='CompanyLogo' --prop alt='Company logo' --json
```

### Connect Two Existing Elements

Obtain stable paths from the `add` or `get` results. Do not guess positional indexes.

```bash
officecli help pptx add connector --json
officecli add deck.pptx '/slide[1]' --type connector \
  --prop from='/slide[1]/shape[@id=7]' \
  --prop to='/slide[1]/shape[@id=8]' \
  --prop shape=straight --prop tailEnd=arrow --json
```

## Unlisted Elements

If the user requests SmartArt, Morph, extended transitions, OLE, 3D, media, masters, layouts, or another capability, first run `officecli help pptx add <element> --json` or `officecli help pptx set <element> --json`. If the structured schema supports the capability, use structured commands. Otherwise, use the `raw`, `raw-set`, or `add-part` passthrough and preserve unchanged parts and relationships.
