# Academic Research

**Visual reference:** Draw on the shared principles of leading university templates, mature Beamer themes, authoritative journal figures, and strong conference talks without imitating a specific template. Use a rational, restrained, clear, and credible style with rigorous hierarchy, sufficient whitespace, a stable grid, low-saturation color, and high-quality chart integration.

**User-uploaded PPT rule:** If a referenced template contains no directly reusable slide, build with this design system and follow `workflow/template-editing.md`.

## Goals

### Narrative: Establish Value in the First Minute and Keep Progress Visible

Follow this sequence: research context, evidence gap, research question, hypothesis, core evidence, conclusion, and contribution. The committee or advisor must understand the value within the first minute.

Use clear sections, transition slides at key points, and persistent navigation so the audience always knows the presentation's progress.

### Visuals: Minimal but Never Cheap

Academic decks are often plain, but plain must not become crude. Use refined, contextually appropriate yet distinctive color and careful typography.

1. **Stay minimal.** Allow decorative elements and images only on covers, section transitions, closing slides, and backgrounds. Never use decorative images to fill content areas. Use icons only when they add clear meaning.
2. **Create quality through detail.** Keep a consistent page framework, source and reference footnotes, figure and table captions, page numbers, and a deliberate type hierarchy.
3. **Use distinctive premium color.**
   - If the user names a school, institution, organization, conference, or journal, obtain the official logo, use its verified primary color, and place the logo appropriately. If the logo cannot be obtained, do not guess its color.
   - Avoid clichéd hospital blue, medical green, environmental green, and ocean blue.
   - Unless requested, avoid crude black, white, or pale-blue backgrounds. Prefer refined backgrounds such as titanium gray `#E7E8E5`, archive paper `#F1E9DA`, or ivory paper `#F7F3E8`.
4. **Maintain density at readable sizes.** Use larger academic body text, above 10 pt with about 1.3 line spacing, except for reading artifacts such as posters. Keep breathing room between regions while filling each region internally. Do not reserve 100 px for content that occupies only 70 px.
5. **Use rigorous layout.** Do not use cards. Express hierarchy through lines, whitespace, type family, and size. Insert a blank line between long paragraphs instead of stacking uninterrupted blocks.

### Let the Research Field Determine the Focus

- **Fundamental and theoretical research:** Emphasize formulas, definitions, propositions, and proof steps. Give rigorous derivations substantial area.
- **Computer science and engineering:** Build slides around system diagrams, code, execution traces, ablations, and performance curves.
- **Experimental research:** Make research figures, images, and tables the focus. Keep formulas, charts, tables, and images supporting one conclusion close together.
- **Empirical analysis:** Treat it as experimental research with stronger narrative, especially in social science.
- **Humanities, architecture, and art:** Use archives, maps, manuscripts, image details, timelines, and textual evidence with brand-level refinement. Also read `brand-storytelling.md`.
- Use shapes, lines, and arrows to annotate figures and images. Lines must stop at node edges and never cross text.
- Use images only when they support the slide's message. Prefer accurate images from attachments.

## Prohibited

1. **Cards by default:** Do not use rounded rectangles or rectangular cards for hierarchy or alignment unless the user explicitly requests them. Use lines, whitespace, and typographic contrast.
2. **Equal-split composition:** Avoid default thirds, quarters, 2x2 matrices, and formulaic "three columns plus title plus conclusion" unless no other layout works.
3. **Generic AI color:** No blue-and-white defaults, blue-purple gradients, cyan-purple neon, rainbow glow, glassmorphism, or luminous borders unless requested.
4. **Tiny body text:** Do not use small body type unless requested or the output is a reading artifact such as a poster.
5. **Underfilled planned regions:** The visible content, not only the text box, must fill its planned area. Underfilled regions create a visibly unfinished layout.
6. **Default chart styling:** Rebuild default axes, grids, legend boxes, rainbow colors, thick black borders, 3D columns, gradients, and shadows. Use one hue family across all charts. In multi-category charts such as pies, prioritize clear legend distinction.
7. **Improper screenshots:** Use charts from attachments intact. Do not crop them. Adapt layout to the image.
8. **Improper image reuse:** Do not reuse paper figures except when needed for information or institutional logos. Preserve every figure's information without cropping.

## Visual References

### Natural Science and Engineering Experiments

**Route here for:** experimental science and engineering, including life sciences, physics, chemistry, materials, and systems; results-driven and chart-heavy work; conference posters or research-result showcases.

- **Character:** The order and tension of a laboratory poster: strict grid, oversized conclusion, large flat color blocks, and full-bleed research imagery. Strong proportions, quiet but not conservative.
- **Color:** Extract one or two primary colors from the research field or institution first. Otherwise use one palette below. Use large flat color areas, never many colors. Use titanium gray, archive paper, or ivory paper for backgrounds.
- **Reference palettes:**
  - Hematoxylin purple `#684765` with eosin pink `#C9828B`.
  - Warm brown-gray `#7A6A58`; taupe `#6B6B67`; warm gray `#B5B1A8`; cream `#EDEBE6`; title `#1A1A1A`; body `#5B5A55`.
  - Deep blue `#0D1B2A`; blue-gray `#64748B`; amber gold `#C9A66B`; mist white `#F7F7F8`; body `#465667`.
  - Cool gray-blue: primary `#3A506B`; support `#5F7A94`; accent `#B8C6D1`; background `#FFFFFF`; charcoal body.
  - Slate green: primary `#4A5E4A`; support `#7A8F7A`; accent `#C4CFC0`; background `#F2F4EF`; charcoal body.
  - Wine and beige-gray: primary `#6B2C3E`; support `#A85A6B`; accent `#D4B8A8`; background `#F0E8E0`; charcoal body.
  - Dark gray and gold: primary `#E8E4D9`; support `#3A3A3A`; accent `#C9A961`; background `#1E1E1E`; body `#E8E4D9` at 60% opacity.
- **Typography:** Sans serif. Use 64-88 pt for cover titles, 36-48 pt for slide titles, 16-19 pt for body, and 9-11 pt for sources.
- **Layout:** Use a 12-column grid with strong asymmetry, often 3:9, 4:8, or a full-slide primary figure.
- **Figure rules:** Give the main figure 60%-75% of the slide and retain axes, error bars, legends, and sources. Photography, microscopy, and remote-sensing imagery can bleed to edges. Put titles in opaque blocks rather than directly over images. Emphasize one result per slide.
- **Slide grammar:** Cover with full-bleed research image and primary-color block connected by a soft overlay; contents with primary-color numbers, 22 pt titles, 12 pt light-gray descriptions, 0.5 pt separators, and two columns when over five sections; content slides that use figures only when meaningful and vary layout unless continuing one topic; results with a large conclusion opposite the complete figure and reversed on the next slide; limitations split by one thick rule into "Established" and "Uncertain"; closing that answers each research question using the cover proportions.
- **Motifs:** Asymmetric flat blocks, section numbers, page numbers, annotations, reference footnotes, and fine edge ticks.
- **Avoid:** Cards, centered titles, soft shadows, blue-and-white business styling, multicolor charts, and giant institutional-logo watermarks.

### STEM Defense and Formal Academic Report

**Route here for:** master's or doctoral defense, course or research report, conference paper talk, or formal academic presentation with institutional identity.

- **Character:** The order of a formal departmental defense. Use school color and logo only for minimal identity; formulas, figures, and arguments remain central.
- **Color:** Extract official colors from the verified institutional logo and use them on 3%-8% of content slides, with full use allowed on section slides. Without an institution, choose one:
  1. Deep charcoal `#2A2D30`, forest green `#4C7A5A`, pale green `#DCE6D6`, ivory `#F4F6F1`, body `#4D5A53`.
  2. Deep blue `#002FA7`, light gray `#B7B7B7`, warm gray-white `#E8E4DC`, warm white `#F5F3EE`, black title `#111111`, dark-gray body `#383838`.
  3. Wine red `#7B2532`, rose brown `#A34450`, warm sand `#D4A59A`, white `#FFFFFF`, charcoal body `#2D2D2D`.
- **Typography:** Use Noto Serif CJK SC for Chinese and English text. Use 48-64 pt cover titles, 32-40 pt slide titles, 17-21 pt body, and 9-11 pt captions and sources. Fix baselines for title, body, caption, and footnote roles.
- **Layout:** Add one hairline header or footer rule on content slides, with fixed short title, section name, page number, or section navigation.
- **Formula and table rules:** Preserve formula numbers, conditions, and symbol definitions. Staged derivations are acceptable, but each slide must contain a complete local argument. Prefer three-line tables and emphasize only rows and columns directly relevant to the conclusion.
- **Slide grammar:** Cover with small school or department mark, title, author, advisor, department, date, and one thin institutional-color line; balanced contents; section slide with institutional color or refined background, section number, title, and one research question; summary answering each question with evidence or section references; references in official citation style at a size between body and footnote; closing with institutional color and logo plus "Questions" or the final conclusion.
- **Motifs:** Short institutional-color rules, fixed title baseline, section name, page number, figure captions, and reference footnotes.
- **Avoid:** Guessed school colors, oversized logo fillers or translucent watermarks, blue gradient headers, repeated large color bands, rounded information cards, figures without captions, and traditions that crowd the argument.

### Humanities, Social Science, and Archival Research

**Route here for:** history, sociology, anthropology, linguistics, literature, art or architectural history, archaeology, and research based on archives, manuscripts, maps, interviews, recordings, or surveys.

- **Character:** A contemporary archival-research special issue. Use warm paper tones, serif text, margin notes, and fine dividers. Images serve as evidence, not decoration.
- **Reference palettes:**
  - Deep charcoal `#2A2D30`, forest green `#4C7A5A`, pale green `#DCE6D6`, ivory `#F4F6F1`, body `#4D5A53`.
  - Brick red `#C62828`, silver gray `#9B9B97`, near-black `#111111`, cream `#F5F4F0`, body `#373735`.
  - Deep blue `#002FA7`, light gray `#B7B7B7`, warm gray-white `#E8E4DC`, warm white `#F5F3EE`, black title `#111111`, body `#383838`.
- **Typography:** Use Noto Serif CJK SC for titles, body text, and quotations. Use Noto Sans Mono CJK SC for numbering and sources. Use 48-68 pt cover titles, 34-44 pt slide titles, 17-20 pt body, 21-28 pt long quotations, 9-11 pt captions and footnotes, and 1.3-1.45 line spacing.
- **Layout:** Use asymmetric 4:8 or 5:7 proportions. Put dates, keywords, document IDs, or annotations in a narrow margin. Organize with whitespace and fine rules, not cards or vintage ornamental borders.
- **Rules:** Do not crop cited images. Use fine frames, leader lines, and enlarged details to identify evidence. Caption every image with creator, title, date, and source. Label interview excerpts with participant ID, time, and place. Keep statistical charts modern and clear without aged texture, using accent color only for the series relevant to the argument. Quote only the passage needed and pair it with interpretation and source; do not fill a slide with source text.
- **Slide grammar:** Cover like a scholarly monograph title page with title, a 35%-50% archive, map, or artwork detail, author, institution, date, and volume-like metadata; research-question slide with three to five lines and margin metadata; literature review organized by chronology or disagreement with lines linking scholars, claims, and responses; archival evidence with enlarged original on the left and transcription, translation, interpretation, and source on the right, connected by matching numbers; empirical analysis with main figure or table across two-thirds and conclusions, variables, and limitations beside it; one main map or timeline with accents only on relevant places and events; argument slide with a declarative title followed by textual evidence, visual evidence, and interpretation; conclusion with numbered short paragraphs answering questions and citing archive, figure, or section IDs.
- **Motifs:** Book-page numbering, fine footnote rules, running headers, archive reference IDs, section tabs, and consistent captions.
- **Avoid:** Casually tilted scrapbooking, low-contrast body text, archive material used as background texture, unsourced historical photographs, and cards.
