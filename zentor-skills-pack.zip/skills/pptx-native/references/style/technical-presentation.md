# Technology and Engineering

**Route here for:** system architecture work such as RFCs, ADRs, capacity planning, or technical-debt reviews; AI and data-platform proposals involving LLMs, RAG, agents, feature engineering, ML platforms, or vector search; production incident reviews and SRE postmortems; and external technical talks such as QCon, KubeCon, developer relations, open-source launches, or technical white papers.

## Narrative Principles

- **Put the conclusion in the title.** Write "Envoy reduced P99 from 320 ms to 85 ms," not "Performance Optimization."
- **Follow the decision chain:** goals and constraints, current state and bottlenecks, mechanism or architecture, key evidence, trade-offs, rollout and rollback, risks, and next steps. Do not conceal information for a final reveal.
- **Use text for why and graphics for how.** Explain motivation, trade-offs, and evidence in text. Show calls and data flow in technical-grade diagrams. Do not make each medium duplicate the other.
- **Make data rigorous and traceable.** Include environment, version, sample size, and load conditions. Report at least P50, P95, and P99, or a confidence interval. A mean alone is insufficient.
- **Separate known facts from inference.** Give current state, target state, assumptions, and validated conclusions distinct locations. If data is unavailable, mark it "To confirm" or "Assumption." Never fill gaps with estimates. Use size or color differences when useful.
- Define terminology and abbreviations at first use, then use one name consistently.

## Prohibited

| Category | Prohibited content |
| --- | --- |
| Layout | Card-stacked hierarchy; equal thirds or quarters; formulaic 2x2 matrices |
| Color | Blue and white defaults, blue-purple gradients, cyan-purple neon, rainbow glow, glassmorphism, glowing borders |
| Style | Glow, particles, halos, glassmorphism, luminous borders, 3D arrows, perspective cubes, gears, cyber globes |
| Typography | More than two body font families; code, paths, or fields without a monospace font |
| Technical filler | Unsupported terms such as "high availability," "high concurrency," "cloud native," "intelligent," "enable," "connect," "end to end," or "one stop." Replace them with specific SLA, QPS, protocol, or component names. |
| Fabricated data | Invented benchmarks, logs, failure cases, performance curves, sample sizes, or version numbers |
| Charts | Software-default axes, grids, legend boxes, rainbow colors, thick black borders, 3D columns, gradient fills, or shadows |
| Diagrams | Lines crossing text; more than two crossings without rerouting; decorative arrows or meaningless nodes |
| Performance reports | Mean only, without P95, P99, or confidence intervals |
| Closing | Standalone "Thank you" or "Q&A" slide; unsupported slogan-sized type; giant logo watermark |

## User Template Reference

**A user-provided PPTX is the highest-priority visual guide.** When asked to reference its style or use it as a template, do not reuse it slide by slide. Apply this process before this document's design principles:

1. **Inspect the rendered result.** Review sample screenshots. Extracting XML text alone does not reveal the template.
2. **Record concise transferable traits:** layout structure such as grids, palette rules, step navigation, and evidence zones; tone such as restrained, approachable, rigorous, live-event, or institutional; and graphic grammar such as parallel modules, timelines, nesting, and frames.
3. **Preserve:** primary fonts, slide-sized background images, brand marks, real people and photographs, original copy, proprietary colors, and decorative patterns. Recompose around them as needed.
4. Apply traits to matching slide types. Do not turn local observations into universal rules.
5. If no slide is directly reusable, build with the design system below.

## Visual Rules

- **Engineering restraint:** Allow decoration only on cover, section, and closing slides. On content slides, give visual weight to architecture diagrams, code, data, and screenshots.
- **Typography:** Use Noto Sans CJK SC for Chinese titles and body copy. Use Noto Sans Mono CJK SC for code, paths, and fields. Use at most two body font families in one deck.
- **Grid:** Fix title baselines, legend locations, color semantics, and source-version coordinates first. This invisible framework creates credibility.
- **Diagram grammar:** Keep arrow endpoints, corners, dash rhythm, corner radii, and line-style encoding consistent. Each diagram should express one primary relationship.
- **Contents:** Left-align a primary-color number, 22 pt section title, and one 12 pt light-gray description. Separate sections with 0.5 pt rules. Use balanced left and right columns for more than five sections.
- **Layout:** Organize with type, hairline light-gray rules, whitespace, and size contrast, using large numbers for key values. Avoid card stacks unless necessary.

## Shared Color References

**Brand color first:** If the user names a company, institution, team, or open-source project, or supplies a logo, first verify its primary brand color. Use it as the deck's theme and build the palette around it. Consider placing the brand logo on the cover. Use explicit visual-identity values directly. This rule takes precedence over the table below.

If no brand color can be confirmed, choose one palette below. Do not use rainbow colors or more than three colors across the deck. If none fits, use ivory `#F5F1E8`, mist gray `#E9E7E2`, and ink black `#131417`.

| Palette | Primary | Supporting | Background | Title | Body |
| --- | --- | --- | --- | --- | --- |
| Jewel blue | `#003087` | `#0070BA` / `#D4E5F7` | `#FFFFFF` | `#001C54` | `#475569` |
| Pine green | `#4C7A5A` | - | `#F4F6F5` | - | `#2E3238` |
| Deep indigo | `#0D1326` | `#2563EB` / `#BFD7FF` | `#F2F4F8` | `#0D1326` | `#536174` |
| Olive gray | `#64664A` | `#3D4246` / `#8A8F94` | `#F2F2F0` | `#0E0E10` | `#3D4246` |
| Deep teal | `#0D2825` | `#7D927E` / `#CDBFA9` | `#F9F7F3` | `#0D2825` | `#4F635A` |
| Dark with neon green | `#D4E92C` | `#7A8B2C` / `#6B7280` | `#1A1A1E` | `#FFFFFF` | `#B8BCC2` |
| Dark talk deck | Brand-color accent | - | `#101418` | `#F0F2EF` | - |

Use accent color on 3%-8% of a content slide. Section slides can use it full-bleed.

## Scenario References

### System Architecture

- **Tone:** White-paper rigor with a neutral matte background, precise orthogonal diagrams, and a continuous document axis. Optimize for stability across the whole deck, not visual spectacle.
- **Sizes:** 48-64 pt cover title, 28-36 pt slide title, 15-18 pt body, 11-13 pt code, and 9-11 pt captions and sources.
- **Layout:** Use a 12-column grid. Fix a short title, section name, and page number at the top. Reuse one architecture coordinate system across slides so changes are immediately visible.
- **Diagram rules:** Show system regions as nested or parallel orthogonal blocks. Use directional arrow chains for calls and data flow. Encode data flow, control flow, and exception paths redundantly with line style and color. Reuse one legend across all architecture diagrams. Show an overview before enlarging details instead of redrawing the full system on every slide. Attach environment, version, and sample size to performance data.
- **Slide grammar:** Cover with proposal title, one-sentence conclusion, version, author or team, and date; TL;DR with three to five conclusions linked to evidence slide numbers; current-state slide with one diagram and bottleneck list; target-architecture slide with differences highlighted by color or line width; migration slide with stages, dependencies, gates, and rollback points in real sequence.
- **Motifs:** Hairline metallic rules, section-number badges, a stable legend bar, a thick critical path, and numbered anchors.
- **Avoid:** 3D architecture, perspective cubes, spheres, gear stacks, generic architecture disguised with AWS, Azure, or GCP brand colors, and empty titles such as "System Architecture Overview" or "Overall Design."

### AI and Data Platform Proposal

- **Tone:** Calm and data-driven, emphasizing trustworthy pipelines and evidence of model quality. Use cool but not sterile colors and avoid clichéd futuristic AI styling.
- **Sizes:** 48-64 pt cover title, 28-36 pt slide title, 15-18 pt body, 60-96 pt metric values, and 11-13 pt code. Vermilion `#C9302C` can identify the component, model, or evaluation set under review.
- **Layout:** A relatively dense dashboard is acceptable within a fixed grid. Fix the evaluation set and version at the top. Give the data-pipeline diagram the primary visual position.
- **Diagram rules:** Separate offline batch, nearline streaming, and online-serving boundaries. Model comparisons must include evaluation-set name, sample size, baseline, and confidence interval. Separate LLM results by task, such as reasoning, instruction following, coding, and safety; do not hide differences in one aggregate score. Show latency-quality-cost trade-offs as scatter plots or Pareto frontiers with every option labeled.
- **Slide grammar:** Cover with one-sentence use case, key result, version, and date; user-task slide with task definition, input and output example, and success criteria; pipeline slide with the full chain, latency budget, and degradation path; one mechanism slide per core technique such as retrieval, ranking, or alignment; evidence slide with multi-task comparison, ablation results, and difference from baseline.
- **Motifs:** Layered pipeline bands, metric values with miniature distributions, Pareto curves, evaluation-set badges, and ablation matrices.
- **Avoid:** Purple-pink gradients, cyber neon, glowing borders, brains, neural-network illustrations, personified robots, comparisons without baselines or confidence intervals, and filler such as "intelligent," "adaptive," or "end-to-end optimization."

### Production Incident Review

- **Tone:** Calm like a case file: fact-driven, timeline-centered, and blameless. Use a dark or paper-like restrained palette. Use vermilion `#C9302C` for event nodes and threshold breaches on no more than 5% of a content slide.
- **Sizes:** 44-56 pt cover title, 28-34 pt slide title, 15-17 pt body, and 11-13 pt monospaced timestamps and logs.
- **Layout:** Carry one main timeline through key slides. Fix incident ID, impact period, and severity at the top. Vertically align impact curves such as QPS, success rate, and latency with event annotations.
- **Diagram rules:** Align timeline ticks to actual time. Mark trigger, alert, intervention, and recovery on one axis. Use a fault tree or causal chain from symptom to direct cause to systemic factors. Quantify impact with users, requests, revenue loss, or SLA violation duration; never say only "a small number of users." Group remediation as complete, in progress, and not started, with verification and owner for each item.
- **Slide grammar:** Cover with incident ID, impact timestamps, severity, and one-sentence impact; quantified impact overview; aligned event timeline and metric curves; direct-cause slide with failure chain, trigger, and earliest detectable moment; systemic-factors slide across organization, process, tools, monitoring, and culture; action slide with owner, date, and verification criterion for every item.
- **Motifs:** Timeline ticks, event dots, severity labels, impact curves, causal arrows, and status dots.
- **Avoid:** Actions such as "strengthen in the future" or "continue monitoring" without verification; stopping at direct causes; blaming individuals instead of process, tooling, or culture; decorative red-green status lights instead of numbers; and self-congratulation.

### External Technical Talk and Developer Advocacy

- **Tone:** Allow stronger visual tension and emotional rhythm, including a dark stage. Stay professionally restrained without showmanship, marketing filler, or artificial suspense.
- **Sizes:** 72-120 pt cover title, 96-160 pt hook number, 32-44 pt slide title, 18-22 pt body for back-row readability, and 14-18 pt code.
- **Layout:** Full-bleed visuals and asymmetric large imagery are allowed. Use one concept per slide. Minimal section slides with one sentence and one number can create pauses.
- **Diagram rules:** Favor conceptual diagrams over exhaustive architecture. Show the shape of the idea, not every interface signature. Keep only code lines that support the point and pre-highlight the important lines. Every data hook must be real and verifiable. Use a representative key frame for demos.
- **Slide grammar:** Cover with one-sentence topic, speaker or organization, and event; hook slide with one striking number, comparison, or before-and-after; problem slide with a concrete user pain or engineering constraint; mechanism slide expanding three to five steps; boundary slide stating limitations honestly; adoption slide with links, repository, or trial entry point.
- **Motifs:** Oversized number hooks, monochrome section pauses, before-and-after comparisons, highlighted code lines, and full-bleed primary visuals.
- **Avoid:** More than seven unsplit lines of text, a final slide that only says "Thank you" without an adoption path, marketing clichés such as "next generation," "revolutionary," "redefine," or "disrupt," unverifiable performance claims such as "100x faster" without environment details, and contrived reveal slides.
