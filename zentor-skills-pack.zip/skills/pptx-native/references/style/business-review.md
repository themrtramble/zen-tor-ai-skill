# Management Review

**Route here for:** operations, finance, and board reports; quarterly or annual reviews; budget and investment decisions; merger proposals; business performance across retail, manufacturing, consumer, or supply-chain categories, regions, and channels; technology and growth monthly reports covering funnels, retention, experiments, MRR, ARR, churn, and iteration; and HR, administration, or government reports.

**Reference quality:** Executive materials from McKinsey, BCG, Bain, Deloitte, PwC, EY, Goldman Sachs, and Morgan Stanley; annual shareholder letters from companies such as Berkshire Hathaway and Amazon; and strong internal operating reviews.

## Global Narrative Principles

- **Performance must be understandable from titles alone.** State a condition or conclusion, such as "Q3 gross margin fell 3.2 points because raw-material costs rose," instead of a section label such as "Business Performance Report." A manager reading only titles should understand results, causes, and requests.
- **Set the tone on the cover and show the full picture on slide 2.** Use whitespace, brand color, logo, report title, period, presenter, and date on the cover without performance data. Make slide 2 a dashboard-like overview using numbers, charts, and hairlines so performance, gaps, and status are immediately clear. User instructions take precedence.
- **Do not exaggerate or omit numbers.** Preserve supplied facts and numbers. Show source baselines beside results. Never invent absent targets, comparisons, or facts. Use numbers, charts, and tables flexibly.
- **Write for the role.** Avoid outsider phrasing and generic management filler such as "enable," "lever," "playbook," "closed loop," "synergy," or "multiple measures."
- **Visualize relationships.** Extract progress, data, ownership, risk, and dependency relationships into diagrams and frameworks instead of text piles.

## Global Visual Discipline

- **Fix information locations.** Keep conclusions and titles in one title zone; evidence such as charts, numbered items, and photos in a stable right or lower zone; and definitions, sources, and footnotes in fixed corners. Prevent page-to-page jumping.
- **Separate font roles.** Distinguish display and body roles with weights in one sans-serif family or separate title and body families. Build hierarchy through size and weight ratios. Use small uppercase text with increased tracking for numbers, labels, and footnotes. Scale sizes with content while preserving hierarchy ratios. Design typography and color together.
- **Keep geometry consistent.** If rectangular components use corner radii, use one radius specification across cards, panels, photos, and column tops. Do not mix square and rounded corners or different radii. Stay flat, with no shadows, 3D, or gradient text. If grain or glow is used, keep it subtle, fixed, and beneath content.
- **Repeat one or two motifs.** Reuse variants of number badges, dotted connectors, or decorative shapes. If a slide lacks an anchor, reuse an existing motif rather than adding a new one.
- **Treat contents as quality-critical.** Use primary-color numbers, 22 pt section titles, and one 12 pt light-gray description line, left-aligned and separated by 0.5 pt light-gray rules. For more than five sections, use balanced columns and reduce size carefully.
- **Fill planned regions.** The visible content, not merely its text box, must fill the intended area. An obviously underfilled region is unfinished.

## Global Prohibitions

| Category | Prohibited content |
| --- | --- |
| Layout | Rounded rectangles or card-stacked hierarchy; equal thirds or quarters; 2x2 matrices; "three columns plus title plus conclusion" |
| Corners | Mixing square and rounded corners or different radius sizes |
| Color | Office blue, blue-and-white business styling, blue-purple gradients, cyan-purple neon, rainbow glow, glassmorphism, luminous borders |
| Decoration | Shadows, 3D, gradient text, colored outlines, saturated background bands, decorative icon piles |
| Charts | Software-default axes, grids, legend boxes, rainbow colors, thick black table borders, 3D columns, gradient fills, shadows, text over charts, or indiscriminate data labels |
| Titles | Empty labels such as "Business Performance Report," "Work Report," "Related Content," "Overview," or "Background" |
| Fabrication | Invented baselines, targets, year-over-year or period-over-period values, or selective hiding of unfavorable data |
| Filler | Generic phrases such as "enable," "lever," "playbook," "closed loop," "synergy," or "multiple measures" |

## User Template Reference

A user-provided PPTX is the highest-priority visual guide. Inspect rendered screenshots, extract transferable layout, tone, and graphic grammar, and preserve primary fonts, slide-sized backgrounds, brand marks, real photographs, original copy, proprietary colors, and patterns. Apply local traits only to corresponding slide types. If no slide is directly reusable, build with this design system. See `workflow/template-editing.md`.

## Global Color Principles

**Brand color first:** When the user names a company, institution, or organization, or supplies a logo, verify its primary brand color and build the palette around it. Consider using the logo on the cover. Use explicit visual-identity values directly. This rule overrides scenario palettes.

**Tone:** Avoid formulaic Office blue, technology gradients, promotional red and gold, and gray-blue templates. Prefer restrained warm white `#F7F3E8`, light limestone `#ECEAE4`, or mist gray `#E9E7E2`. Section and emphasis slides can use deep ink blue `#16283C` or ink black `#1A1A2E`. Use accent color only for key metrics, completion state, or section bands, covering 3%-8% of content slides and never serving as decoration.

**Chart colors:** Use one hue family across every chart without a second family. In multi-category charts, keep legend colors distinguishable. Retain only key data labels or move them to a text column. Show important metrics as large numbers. Keep chart and interpretation zones separate without overprinting.

## Scenario References

### Operations, Finance, and Board Reporting

- **Tone:** Institutionally formal, restrained, precise, and undecorated. Use deep, stable colors and medium content density. Give section and conclusion slides large dark fields.
- **Decision focus:** Achievement rate, gap attribution, funding, and resource requests. Numbers and conclusions must be immediately visible.
- **Reference palettes without a brand color:**
  - Deep blue `#0D1B2A`; blue-gray `#64748B`; amber gold `#C9A66B`; mist white `#F7F7F8`; body `#465667`.
  - Coral red `#C24C57`; charcoal `#333333`; silver `#9B9B9B`; white `#FFFFFF`; title `#1A1A1A`; body `#5C5C5C`.
  - Cobalt `#2F54EB`; mist blue `#ADC6FF`; silver `#D9D9D9`; snow `#F8F9FA`; title `#141414`; body `#595959`.
- **Typography:** Use a Chinese sans-serif family. Pair numbers and English with monospaced or semi-serif numerals for precision. Use 56-72 pt cover titles, 32-40 pt slide titles, 16-19 pt body, and 9-11 pt footnotes.
- **Layout:** Use a 12-column grid with a fixed title baseline and source position at lower right. Covers and sections may use asymmetric large color blocks.
- **Charts and tables:** Prioritize 60-96 pt KPI values for achievement and gaps with minimal labels and comparisons. Remove axes and grids from column and line charts, retaining only key labels. Use three-line tables and mark anomalies with narrow bands or dots, never full-row saturated fills.
- **Slide grammar:** Cover with brand treatment and no performance data; dashboard overview on slide 2 with KPI values, sparklines, and hairlines; summary with three to five declarative conclusions plus metrics and gaps; metric slide with one huge value, comparison, one causal sentence, and a small chart; attribution with waterfall or contribution decomposition plus adjacent conclusion; request slide listing resources, budget, or decisions with impact and alternatives.
- **Motifs:** Metallic hairlines, section badges, fixed page numbers, three-line tables, and minimal KPI values.
- **Avoid:** Blue-and-white business defaults, rounded information-card stacks, 3D or gradient columns, shadows, giant company-logo watermarks, and empty titles such as "Work Report" or "Summary and Outlook."

### Business Operations Review: Retail, Manufacturing, Consumer, and Supply Chain

- **Tone:** Industrial and practical, with warm foundations, dense tables and bar-line combinations, and immediately visible anomalies. Optimize information density and decision efficiency, not decoration.
- **Decision focus:** Category, region, and channel comparisons and trends.
- **Reference palettes:** caramel brown `#A05A2C`, amber `#C9986A`, camel `#E2CDB8`, ivory `#F6F1EC`, deep chestnut `#2A1F14`; or vermilion orange `#E24C3D`, deep ink green `#0F2A23`, sand brown `#CBAA8D`, cream `#F5EDE1`, charcoal `#333333`; or deep blue-gray `#1F3240`, steel gray `#C3CCD4`, amber yellow `#FCAD0C`.
- Use accent only for anomalies, threshold breaches, and items requiring attention.
- **Typography:** Use Noto Serif CJK SC for Chinese and Noto Sans Mono CJK SC for numbers and tables. Use 48-64 pt cover titles, 28-36 pt slide titles, 15-18 pt body, 12-14 pt tables, and 9-11 pt footnotes.
- **Layout:** Use a dense chart-and-table grid with fixed category, region, and channel navigation at top and metric definitions at bottom.
- **Charts and tables:** Prefer horizontal bars and lines for multidimensional comparisons; use columns only for time series. Group table headers clearly, use horizontal separators, and mark anomalous rows. Show negative values in parentheses or a dedicated color, not a minus sign plus red text.
- **Slide grammar:** Brand-led cover; slide-2 dashboard; panorama matrix such as category by region or channel by category with anomalous cells highlighted; one-dimension analysis with one main chart and three to five nearby conclusions; attribution with waterfall or contribution decomposition; action slide split into completed this period, committed next period, and support needed, each with owner and date.
- **Motifs:** Three-line tables, anomaly dots, aligned tabular figures, period badges, and category hues.
- **Avoid:** Rainbow bars, multicolor pies, saturated full-row state fills, 3D columns or cones, gray-blue templates, Office blue, decorative icon piles, misaligned tables, and non-tabular numerals.

### Technology and Growth Monthly Review

- **Tone:** Modern, restrained, and data-driven, with cool or dark foundations, large metrics, sparklines, and strong rhythm. Do not use colorful large-company card walls.
- **Decision focus:** Funnels, retention, and iteration cadence, supported by funnel diagrams, trends, and event timelines.
- **Reference palettes:** neon yellow-green `#D4E92C`, olive `#7A8B2C`, smoke gray `#6B7280`, ink black `#1A1A1E`, white title `#FFFFFF`, silver body `#B8BCC2`; or rust orange `#C24E2A`, steel gray `#7D8085`, pale steel `#C9CBCE`, cool white `#F2F2F0`, charcoal title `#17191C`, iron-gray body `#555A60`; or celadon green `#3FA68C`, ink black `#101418`, cool white `#F4F7F6`.
- On dark themes, use cool white or light gray body text. Never put small type on saturated color.
- **Typography:** Use Noto Sans CJK SC for Chinese and English. Use Noto Sans Mono CJK SC for numbers. Use 48-64 pt cover titles, 28-36 pt slide titles, 15-18 pt body, 60-96 pt metric values, and 9-11 pt footnotes.
- **Layout:** A dense dashboard is acceptable within a fixed grid. Fix period and metric definition at top and filter or dimension notes on the right.
- **Charts:** Place sparklines beside metrics. Use funnel diagrams, retention curves, and cohort tables as primary visuals, each answering one question. A/B results must show sample size, confidence interval, and significance, not only relative uplift.
- **Slide grammar:** Brand-led cover without metrics; slide-2 overview with four to eight KPI values, sparklines, and hairlines without rounded cards; funnel or retention slide with one main chart, key-node values, and conclusion; experiment slide with hypothesis, variants, result table, conclusion, and next action; iteration progress with timeline and launched, in-progress, and pending states.
- **Motifs:** Sparklines, metric-plus-comparison labels, timeline ticks, significance stars, and period labels.
- **Avoid:** Blue-purple gradients, neon, rainbow glow, glass cards, luminous borders, fluorescent outlines, 3D visualization, spheres, radar charts without semantic need, relative uplift without absolute values or sample size, and multicolor rounded card walls.

### HR, Administration, and Government Reporting

- **Tone:** Formal, orderly, and ceremonial, with warm or paper-like backgrounds, serif type, and tables and process diagrams carrying most information. Prioritize clarity, ownership, and deadlines over spectacle.
- **Decision focus:** Compliance, coverage, and milestones, using tables, maps, and process diagrams.
- **Reference palettes:** emerald `#2E8B47`, pine `#143D30`, lime `#7CB342`, cloud gray-white `#F2F3F5`, dark-green title `#1A2E23`, slate body `#4A5568`; or paper white `#F7F3E8`, pine `#284F2C`, apricot `#E8B54A`; or burgundy, cream, and charcoal for government reporting.
- Use accents for completion, overdue items, and critical work. Do not use entire red warning paragraphs.
- **Typography:** A modern Chinese serif for titles and monospace for IDs and archive references. Use 48-64 pt cover titles, 30-38 pt slide titles, 16-19 pt body, 13-15 pt tables, and 9-11 pt footnotes.
- **Layout:** Use stable symmetric or near-symmetric composition. Fix institutional mark and header at top, page and document number at bottom. Section slides can use full-slide accent color.
- **Charts and tables:** Prefer clear tables and process diagrams; use bar and pie charts only when necessary. Show organization, process, and responsibility as directed structural diagrams. Show coverage and compliance percentages with progress bars or rings, not 3D pies.
- **Slide grammar:** Formal cover with report title, period, reporting unit or person, and institution mark without conclusions; slide-2 overview with key metric table, progress bars, and hairlines; status slide with three to five declarative conclusions and metric table; one work item per slide with goal, progress, owner, date, and next step; analysis with main table, chart, short interpretation, and fixed source and definition footer; next-step slide ordered by priority or date with owner and deadline.
- **Motifs:** Institutional-color hairlines, section numbers, owner labels, date nodes, three-line tables, and completion icons.
- **Avoid:** Festive red-green-gold palettes, cartoon icons, decorative borders, clip art, 3D or exploded pies, rainbow columns, generic filler, giant logo watermarks replacing content, thick black table borders, inconsistent row heights, and misaligned numbers.
