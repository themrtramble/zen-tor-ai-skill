# Fallback Style

**This is the fallback design system and the only system in this skill centered on dense visual-content cards.** Use it only when the presentation does **not** match any scenario in [slide-taxonomy.md](slide-taxonomy.md).

- When a specific scenario matches, follow its document. Those seven scenarios prohibit cards by default. This fallback is mutually exclusive with them.
- User-provided templates, brand rules, colors, fonts, and style references take precedence.
- Under this fallback, this document alone governs card use. The general no-card rule in [slide-taxonomy.md](slide-taxonomy.md) does not apply.
- Cover and section-divider slides are exceptions to the card layout.

## Core Requirement

- Use a visual-content card layout. Keep slides substantial, image-rich, and data-driven within the top-level text budget.

## Images and Primary Visuals

- Every deck type must combine text with abundant imagery.
- A cover's primary visual must be a real image from image generation or a user attachment. Do not assemble a cover visual from shapes or icons.

## Layout

- **Card grid:** Fill the page with a multi-row card grid. Keep the composition symmetrical and balanced without unused space. Vary grid count and text-to-image ratio with the content so slides do not repeat. Do not overload one card with text.
- **Card style:** Use square corners and flat, solid fills without gradients. Keep styling consistent across the deck. Use no border or decoration by default. A thin border or color strip is allowed only for emphasis, not decoration.
- **Card anatomy:** Use a visual anchor, such as a keyword, number, symbol, or icon; a title without a background fill; and content such as text, an image, chart, table, or nested card.
- **Text cards:** Split separate topics into separate subcards. Keywords and short phrases can become square-corner label cards.
- **Image cards:** Most slides must contain one to three image cards. Search for or generate images during asset collection. Use `GenerateImage` when the asset count is insufficient.
- **Chart cards:** Do not put data in text cards. Visualize it with tables, charts, timelines, flow diagrams, or similar structures. If a chart already has a title, do not add another card title.
- **Spacing:** Keep slide content and card content away from edges. Prevent overflow. Cards must not touch or overlap.
- **Alignment:** Left-align body text by default. Center table text, but left-align long sentences, paragraphs, and lists. Center charts, images, and text boxes within their cards.
- **Dense fill:** Fill the content area with a dense card grid and avoid large empty areas. Only cover slides and intentionally full-bleed image slides may extend to slide edges. Keep margins around normal content slides.
- Do not place decorative color blocks or lines beneath titles.

## Visual Style

- **Aesthetic:** Use a clean, bright, flat style without gradients. Maintain order at high density through cards and a strict grid. Keep peer cards similar in text volume. In dense text, emphasize key information and group content into sections or separate text boxes. Maintain hierarchy and rhythm instead of creating uninterrupted text blocks.
- **Typography:** Use Noto Serif CJK SC. Do not use the default Noto Sans CJK SC.
- **Sizes:** Use 28-36 pt for titles, 12-14 pt for body text, 10-12 pt for annotations, and 16-32 pt for key metrics. Core metric values can use 36-52 pt, with 10-14 pt labels and short interpretations.
- **Icons:** Use icons, keywords, numbers, or symbols as visual anchors.
- **Color:** Use one consistent, restrained palette: one white or cool-neutral background, one primary color, one accent color, and one supporting color. Use muted or deep-muted tones. Avoid high saturation and ensure that background and foreground colors harmonize.

## Visual Quality Floor

Slides can be dense, but they must still meet the "Visual Quality Floor" in [slide-taxonomy.md](slide-taxonomy.md). Fix text overflow, unintended overlap, low contrast, edge crowding, uneven gaps, misalignment, footer collisions, title-underlining decoration, narrow boxes that cause awkward wrapping, stretched or badly cropped images, placeholders, broken images, and blank slides. Cards must not touch or overlap. Normal content slides require outer margins; only covers or full-bleed backgrounds may extend to slide edges.
