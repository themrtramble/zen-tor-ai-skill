# Brand and Creative Storytelling

**Quality references:** Leading magazines such as Monocle, Wallpaper, and Vogue; international design studios such as Pentagram; strong brand reports, guidelines, and creative proposals; and the execution standard of editorial books, luxury brand manuals, and architecture-studio proposals.

**How to use this document:**

- **Part A, Sections 1-2:** Identify the topic and satisfy hard constraints before accepting the design direction.
- **Part B, Sections 3-7:** Follow the five-step workflow from topic to finished deck.
- **Part C, Sections 8-11:** Apply color, typography, image, and composition disciplines during production.
- **Part D, Section 12:** Select from five visual families and one reference style.
- **Section 13:** Complete four delivery-review passes.

## A. Preconditions

### 1. Identify the Topic

Complete two tasks first.

#### 1.1 Identify the Topic's Visual DNA

For a specific brand, product, company, person, city, building, event, or intellectual property:

- Extract visual identifiers such as icons and brand concepts from user references.
- Search official sites, annual reports, creative manuals, and brand marks. Study their visual treatment, not only their text.
- **Validation:** If all text disappeared, the remaining visuals should still connect clearly to the topic.

#### 1.2 Assess Aesthetic Quality

Not every topic has the visual quality of leading editorial references:

- Inherit visual DNA that meets the benchmark.
- Explicitly reject weak traits rather than reproducing them.
- If the brand lacks design quality, retain only its primary color as a theme or accent, or its mark as decoration.

### 2. Hard Prohibitions

Unless the user explicitly requests otherwise, these rules apply throughout.

**Composition and color:**

1. **No cards by default.** Do not use rounded rectangles or rectangular cards for hierarchy or alignment. Use lines, whitespace, and typographic contrast.
2. **No equal-split composition.** Avoid thirds, quarters, 2x2 matrices, and the formulaic "three columns plus title plus conclusion" unless no other layout works.
3. **No generic or AI-like palette.** Avoid blue and white, blue-purple gradients, cyan-purple neon, rainbow glow, glassmorphism, and luminous outlines.
4. **No style conflicts.** Do not introduce rounded icons or rectangles into a sharp-edged visual family, or any other foreign style.

**Editorial production floor:**

1. **Color boundary:** Use one primary color, a neutral axis, and at most one accent. Never use Material or Flat UI defaults such as `#4CAF50`, `#FF9800`, `#2196F3`, or `#E91E63`, their close neighbors, or pure RGB colors above 70% saturation without a material-based rationale.
2. **No colorful titles:** Use charcoal, warm white on dark backgrounds, or a deeper version of the primary color. Colored bold titles are a major failure.
3. **No component-library look:** Prohibit icon-and-phrase card arrays, seas of small rounded cards, progress bars, pill tags, emoji, clip art, and default PowerPoint shadow, bevel, gradient, and outline effects.
4. **No repeated flat formula:** Two consecutive slides with a flat background, title, body, and one image on the right fail.
5. **No repeated skeleton:** Three consecutive structurally identical slides fail.
6. **No same-face output:** If thumbnails for different industries and tones are indistinguishable, redesign the deck.
7. **No fake text:** Prohibit decorative fake English, lorem ipsum, and gibberish. Every English phrase must have real meaning.
8. **Furniture layer required:** Use three to five consistently positioned page-furniture elements. This distinguishes designed output from generated output.

## B. Workflow

### 3. Step 1: Select a Visual Family and Record Differentiating Decisions

There is no global default. Select one family from Section 12: F1 Paper and Ink East, F2 Deep-Space Precision, F3 Warm-Earth Craft, F4 Clear Business, or F5 High-Tension Expression. The family governs foundation, typography, layout grammar, image signature, furniture, and palette logic, not only color values.

Immediately record **three visible decisions that distinguish this deck from the other families**, for example a dark atmospheric foundation instead of paper white, vertical oversized type instead of horizontal titles, or cinematic full-bleed imagery on 40% of slides. The decisions must be obvious in thumbnails.

Priority under conflict: explicit user instruction, then audience modulation, then industry family.

### 4. Step 2: Modulate for the Audience

The family determines how the industry looks. Audience modulation determines what this audience needs to see. The same industry for different audiences must produce visibly different thumbnails. Adjust sizes, palette, imagery, and density using Section 12.2.

**Audience same-face test:** Imagine changing to another audience tier in the same industry. If the design still works unchanged, audience modulation failed. Return to Section 12.2 and revise the three differentiating decisions.

### 5. Step 3: Build Every Slide in Five Layers

Plan each slide from bottom to top. Missing a required layer is a failure.

| Layer | Content | Requirement |
| --- | --- | --- |
| **L0 Foundation** | Base color, texture asset, full-bleed image, or color-field splice | At least 60% of slides must use more than a flat solid foundation. A flat slide requires oversized type or large-format imagery. |
| **L1 Graphic** | Ghost type at 120-400 pt and 6%-12% opacity, enlarged bleeding brand symbol, or large color-field division | Optional; primarily for section and visual slides. Upper images may partially cover ghost type. |
| **L2 Image** | One to six images | Specify source URL, crop ratio, position, share, and bleed edge. With multiple images, the main image must be at least 2.5 times the smallest and all images share one alignment axis. |
| **L3 Text** | Exact title, size, line breaks; exact body, column width, line spacing; bilingual pair; vertical instruction | Build vertical text as a narrow column with one CJK character per line. Do not rely on host vertical-text support. |
| **L4 Furniture** | Three to five fixed micro-elements such as section label, page number, edge rail, seal block, dot, corner mark, or hairline | Fix each element's position and size across the deck. |

### 6. Step 4: Select Layout Devices and Cross-Slide Rhythm

| Device | Composition | Usage |
| --- | --- | --- |
| **L21 Multi-image editorial collage** | Three to six varied crops, such as strips, squares, and banners, with one or two bleeding to edges | Share one alignment axis; main image at least 2.5 times smallest; 12-20 px gaps |
| **L22 Ghost type** | One character or word at 150-400 pt and 6%-12% opacity behind content | Use a section character or brand initial every four to six slides |
| **L23 Vertical text band** | A narrow band covering 8%-14% of width, with a short vertical title and tiny English | At most eight CJK characters; reserved for F1 and F3 |
| **L24 Vertical sliced strip** | Three to six equal-height vertical images for materials or details | Each strip has one subject and a 9-11 pt label; 8-14 px gaps |
| **L25 Oversized-number section slide** | 120-220 pt Arabic or formal numeral, section title, and one representative image or color field | Reuse one section skeleton but rotate imagery and lightness |
| **L26 Full-bleed breathing slide** | Full-bleed image with one short line or no text | Place after a high-density slide every four to six slides |

**Rhythm examples:**

- **F1:** `L01 -> L25 -> L21 -> L23+L04 -> L11 -> L26 -> L21 -> L16 -> L25 -> ... -> L01`. Alternate vertical bands and collages, with one full-bleed pause per section.
- **F2:** `L01 -> L08 -> L26 -> L04 -> L02 -> L16 -> L12 -> L26 -> L07 -> L20`. Maintain dark tone and use a light parameter slide as relief.
- **F3:** `L01 -> L25 -> L13 -> L14 -> L24 -> L02 -> L12 -> L26 -> L15 -> L20`. Move from wide to medium to close views; sliced strips provide material evidence.
- **F4:** `L01 -> L08 -> L07 -> L04 -> L10 -> L12 -> L26 -> L20`. Use hero imagery only at section starts and close, with dark slides for data peaks.
- **F5:** `L01 -> L03 -> L18 -> L02 -> L21 -> L26 -> L12 -> L20`. Alternate low-density declarations and dense collages sharply.

`L01-L20` are common layouts such as hero-full, hero-object, manifesto-type, split-evidence, metric-poster, timeline-ribbon, comparison-stage, matrix-with-proof, material-board, object-catalog, triptych-lens, process-strip, floorplan-callout, detail-zoom, portrait-quote, collage-field, chapter-index, and decision-roadmap. Select by slide role.

### 7. Step 5: Apply Layout Gates

- Decks with at least 22 slides need at least eight layout fingerprints. No fingerprint may exceed 20% of the deck.
- Decks with at least 10 slides need two to four section or breathing slides using L25, L26, or L03.
- Every image collage needs one dominant image at least 2.5 times the smallest, or one focal point created through position or lightness.
- Follow every high-density research slide with a low-density pause.
- At least 30% of slides must contain two or more images. On at least 25% of slides, imagery must occupy at least 70%.
- Size images by content. Preserve full limbs in human action, material detail in product close-ups, and entrances, circulation, and human scale in spatial images. Do not crop merely to fill a frame.
- Keep one contiguous empty area outside the main content frame equal to at least 30% of the slide. Give titles substantial negative space.
- If capacity is insufficient, delete, split, or change structure. Do not reduce font size.
- Between consecutive slides, change at least two of composition axis, image proportion, anchor, density, and lightness.

## C. Rule Library

### 8. Color: Material Color, Not Screen Color

- Use one primary color, a near-black-to-near-white neutral axis, and at most one accent.
- Explain the primary color through a material in the topic world, such as tea, wood, stone, ceramic, textile, metal, plant, soil, or product finish. Keep saturation generally at or below 60%.
- Avoid pure black and white. Use charcoal `#2A2A2A-#3A3A3A` for body; warm white, cream, or paper gray for light bases; and `#101216-#1E1B18` for dark bases.
- Keep accent area below 5% and use it only as a focal anchor.
- Do not use gradients, multicolor charts, or multicolor status blocks. Give every color a stable meaning.

### 9. Typography: Display and Body Must Differ

- **16:9 editorial scale:** 80-130 pt cover theme, 90-200 pt section type, 28-44 pt slide title, 18-22 pt lead, 14-16 pt body, and 9-12 pt note, source, or page number. Adjacent levels require at least 1.8x scale difference.
- Show large numbers in very large light weight and reduce units and definitions to 10-12 pt.
- Pair major Chinese type with a real 8-11 pt uppercase Latin micro-label at 200-300 tracking. Never use meaningless English.
- Break Chinese lines by meaning and avoid orphaned characters.
- Use vertical or rotated type only for short titles, indexes, or years. Keep body copy in the natural reading direction.
- Place text over images only in low-information regions and verify contrast at the lightest and darkest points. Define reading order, such as `01 -> 02 -> 03`.

### 10. Images: Make Them the Protagonist and Use More Than One

- Grade-A references use a median 55%-75% image area and two to five images per slide. If the full-deck median is below 45%, collect more imagery before writing slides.
- Use full bleed or at least 50% area for single-image slides. Use L21 for multi-image slides. A row of small images over a row of small labels resembles an e-commerce detail page and fails.
- Keep one photographic world across the deck through lighting, color temperature, lens language, and finishing.
- Fit text into the negative space created by the image composition. The space toward which a subject faces is a natural title area.

### 11. Composition and Visual Logic

- **Make an extreme choice:** oversized type, huge images, strong whitespace, dense multicolumn layouts, one vivid color, or heavy rules. Commit to a distinctive language such as old-newspaper front page, Memphis, Constructivism, or Swiss style. Reject safe, generic, conservative options. Distinctive imperfection is preferable to blandness.
- Give covers, opinion slides, data slides, and image slides distinct compositions. Consistency can come from palette, typography, scale, decoration, and grid rather than one repeated skeleton.
- Derive visual language from the topic, brand, industry, era, or material, and make it improve understanding.
- Select one layout mechanism for every slide. Between consecutive slides, change at least two of axis, image share, anchor, density, and lightness.
- Keep page numbers small and weak at 9-10 pt neutral gray. Use logos only on cover, back cover, and section slides.

## D. Visual References

### 12. Five Visual Families and One Reference Style

Use the fallback reference style only when no family fits.

#### 12.1 Family Overview

| Family | Suitable topics | L0 foundation | Typography | Image signature | Palette |
| --- | --- | --- | --- | --- | --- |
| **F1 Paper and Ink East** | Culture, East Asian space, cultural travel, objects, contemplation | Rice-paper or silk texture with local lattice light | Chinese serif and oversized vertical type | Morning mist, negative space, muted ink tone | Paper gray and cream, charcoal ink, material color such as wood brown, blue-black, moss, or ochre, plus vermilion seal |
| **F2 Deep-Space Precision** | Frontier technology, aerospace, energy, automotive, premium equipment | At least 60% dark with deep-space shading, metal, or carbon texture | Modern sans serif with extreme scale contrast and monospaced numbers | One strong rim light, scale reference, atmospheric detail | Space black-gray, warm white, and product color such as engine orange, signal red, titanium gold, or electric blue |
| **F3 Warm-Earth Craft** | Food, tea, coffee, craft retail, natural humanities, local travel | Warm paper or linen with deep brown and clay fields | Chinese serif, bracket numbering, small vertical labels | Steam, moisture, grain, fiber, hand action, dark still life | Warm cream or kraft, deep brown-charcoal, ingredient colors such as tea, matcha, roasted tea, or fruit red |
| **F4 Clear Business** | Corporate profile, platform, gentle consumer technology, modern retail, pitch | White or light gray with ghost geometry or oversized brand symbol; 20%-40% dark slides for data peaks | Modern sans serif, judgment titles, large light-weight numbers | Bright natural light, real business scenes, clean depth of field | White or light gray, deep charcoal, and 5%-10% brand color, including full color-field slides |
| **F5 High-Tension Expression** | Fashion, trend lifestyle, collectible IP, creative consumer | Alternating high-contrast bases with film grain or paper scan | Oversized cropped type and extreme Chinese-Latin contrast | Direct flash, hard-light street or room scenes, captured action | High-saturation primary color, exempt from the 60% limit, plus black-white axis |

**Family-specific prohibitions:**

- **F1:** Applied cloud or dragon motifs, gibberish calligraphy, festive red and gold, or an incorrect minimal white background with thin boxes.
- **F2:** Fake HUDs, neon circuits, random particles, blue-purple gradients, pale beige as the main stage, or manual-like pages with tiny images and excessive text.
- **F3:** White-background e-commerce product images, saturated candy color, cute stickers, plastic texture, or repeated centered-title posters.
- **F4:** Seas of cards, icon arrays, equal three columns, colorful titles, or decorative illustration.
- **F5:** Equal nine-cell grids, fake English, rainbow gradients, or kindergarten-style assets.

#### 12.2 Audience Modulation

| Audience | Family tendency | Key modulation | Prohibited |
| --- | --- | --- | --- |
| **Children ages 3-12 and families** | Bright F5 variant or F3 plus original illustration | Rounded sans or handwritten display; larger body; crayon, fruit, or clay colors; real children with illustrated characters | Piled cartoon assets, rainbow gradients, fluorescent colors, adult minimalism |
| **Teens and Gen Z** | F5 | Oversized cropped type, extreme bilingual contrast, saturated primary plus black-white, direct-flash street photography | Official-sounding titles, stock youth photos, forced slang |
| **Urban middle-class and mature consumers ages 30-55** | F1, F3, or F4 by industry | Serif display allowed, restrained hierarchy, muted material palette, editorial whitespace | Promotional styling, icon cards |
| **Older adults** | Warm F3 or bright F4 | Readability first: 16-20 pt body, line spacing at least 1.8, no 7-9 pt light-gray text, furniture at 10-12 pt or only two elements, warm stable palette, dark text on light background, at least 70% contrast, eye-level photography | Red and gold, calligraphic display, peony or cloud motifs, portraying older adults only as care recipients |
| **High-net-worth and luxury audience** | Dark F1 or luxury-maison structure | Fine serif weights, archival numbering, extreme whitespace, alternating cream archive and dark ritual pages, metallic color only in details | Large logos, promotional claims, bright-gold gradients |
| **Professional and B2B decision makers** | F2 or F4 | Declarative titles, large light-weight numbers, deep charcoal with at most 10% brand color, real business environments, native charts occupying at least 55% | Icon arrays, decorative illustration, empty vision images |

**Topic-to-family defaults:**

- `culture-craft`, East Asian `space-interior`, and East Asian resort `place-hospitality` -> F1. Modern spaces can use F4.
- `frontier-engineering`, automotive, and hard-core hardware -> F2.
- `human-centered-tech` -> F2 by default; gentle consumer products can use F4, but dark slides must still reach at least 30%.
- `food-craft-retail` and natural-humanities `place-hospitality` -> F3; premium dining can use F1.
- `enterprise-evidence` and modern retail -> F4.
- `expressive-lifestyle` and `playful-ip` -> F5.
- `luxury-maison` -> dark F1 with archival furniture; fashion can use F5.

#### 12.3 Reference Style: Hand-Trimmed Independent Magazine

**Core visual:** Make the deck feel like an independent magazine trimmed, scanned, and bound by hand. Use heavy poster type, two-color overprint, halftone images, cut-and-paste blocks, and slight rotation. Preserve paper and print imperfections rather than digital-interface polish.

**Palette:** warm-beige paper `#F1E2C2`; cobalt ink `#1646B8`; fluorescent pink spot color `#FF4F87`; ink black `#171512`; optional orange-yellow `#F1A51B` on one or two section slides covering under 5%. No transparent gradients; use flat fields, overprint, and halftone only.

**Type:** 88-120 pt extra-heavy condensed cover title, optionally rotated -3 degrees and bleeding beyond canvas; 42-58 pt page titles, including reversed white on black; 14-17 pt clear sans or serif body; 10-12 pt monospaced annotations like typewriter labels.

**Grid and geometry:** Use unequal two- and three-column layouts with cut-and-paste modules. Rotate images and text blocks from -4 to +4 degrees. Use 2-3 pt primary rules and 0.75 pt crop marks. Keep color blocks square. Local overflow and overlap are allowed.

**Image treatment:** Convert every photo to high-contrast monochrome, then apply blue or pink halftone. Keep dot size consistent and allow 2-4 px registration error. Roughly crop people and buildings only while preserving recognizability. Never insert full-color photography directly.

**Slide grammar:** Cover with title over half the page, a blue-pink duotone press or bookstore photograph at bottom, and a tilted label at upper right; contents with five colored paper strips, each holding one section number and short title; history timeline like tickets clipped to paper with 40-56 pt bold years; process with five horizontal steps, each containing one halftone, number, and description line; city case with a 60% main image and newspaper-like sidebar; map with black lines and solid pink city dots; close with four large numbered circles for actions and a black manifesto line at bottom.

**Repeating motifs:** Misregistered blue-pink overprint, crop line at upper left, and fixed volume or issue number.

**Avoid:** Glassmorphism, soft shadows, smooth gradients, refined rounded corners, full-color photography, business clip-art icons, and perfectly symmetric grids.

## 13. Delivery Review: Four Passes

1. **Title pass:** Read only titles. They must communicate causality and complete the decision loop.
2. **Thumbnail pass:** Check for visual peaks and rhythm changes, three consecutive identical structures, two consecutive flat-background right-image formulas, repeated imagery, and family or audience differentiation. Use a squint test for overall lightness, foundation texture, and furniture consistency. If the audience could change without redesign, modulation failed.
3. **Full-size pass:** Check every slide against Section 2: palette overflow, colorful titles, card arrays, hierarchy below 1.8x, text over budget, insufficient imagery, too many flat foundations, or missing and drifting furniture. Fix every failure.
4. **Retelling test:** A viewer unfamiliar with the project must be able to state the central tension, positioning, and three design actions.

After revisions, revalidate affected slides. Do not claim completion without a final read-back.
