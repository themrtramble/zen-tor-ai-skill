# Learning and Training

**Route here for:** lessons, vocational training, operating guides, teacher resources, learning handbooks, public education, onboarding, capacity building, and knowledge dissemination.

**Core position:** Educational material follows **question, thought, judgment, summary**. Questions pull learners forward; information must not simply push at them. Every slide must answer, "What thinking does this slide teach?" If no answer exists, add content, merge the slide, or delete it. Slide form is flexible and must serve instruction.

## A. Hard Prohibitions

- Do not build hierarchy with cards. Use lines, whitespace, and size or weight contrast.
- Do not use equal thirds, quarters, 2x2 matrices, or the formulaic "title plus three blocks plus conclusion."
- Do not use generic blue and white, blue-purple gradients, cyan-purple neon, rainbow glow, glassmorphism, or luminous borders.
- Do not mix conflicting styles, such as rounded components in a sharp system or realistic textures in a minimal system.
- Rebuild default SmartArt, rainbow colors, and thick black table borders.
- Do not conceal missing content with decoration or whitespace. Add the missing definition or example.
- Lines must never cross text.
- Keep body text at least 15 px for projection.
- Do not screenshot images containing text from course materials. Adapt the layout to the original image ratio.
- Avoid information overload. The core object and question must be obvious. When a slide asks a question, preferably answer it on the next slide.

## B. Required Workflow

### 1. Define the Learning Task and Build a Question Tree

Before designing, determine who the learner is, what they cannot yet do, what they will be able to do, and where they will use it. Then build:

- **Course driving question:** One complete question answered by the full deck.
- **Section questions:** Three to seven subquestions, one per section.
- **Slide questions:** Two to five per section, one for each content slide, including where the learner is likely to get stuck.

> **Warning:** Labels such as "Background," "Overview," or "Introduction" are not questions. Reconsider the teaching objective before continuing.

### 2. Create a Slide-by-Slide Outline

For every slide, define: **section, slide type, slide question or judgment, title, primary display, explanation or task, and source**.

- **Slide question:** A complete question from the question tree, not a section label.
- **Slide judgment:** One observable sentence the learner can repeat. Avoid unobservable verbs such as "understand" or "master." If the prior slide asks the question, place the answer on the next slide.
- **Title:** Write it after the question and judgment. Rewrite empty labels such as "Background," "Overview," and "Related Content."
- **Source:** Cite external facts and data. Label illustrative data "Illustrative material."

If a slide has no question or judgment, add content, merge it, or delete it.

### 3. Extract Reference Traits When Available

Extract only functional layout, such as grid, color coding, or step navigation; tone, such as restrained, approachable, or rigorous; and graphic grammar. Do not inherit brand marks, photos, people, exact copy, or proprietary color values. Take at most two or three mutually compatible traits from each source.

### 4. Prepare a Visual Brief

Define the audience and use environment; the main grid and five or six slide types; typography hierarchy; color semantics and contrast; graphic grammar; and fixed coordinates for header, footer, page number, and source.

### 5. Generate and Validate Each Slide

Write an outcome-oriented title, select one primary display, add definitions, boundaries, labels, tasks, and sources, apply the grid and hierarchy, and remove decoration without instructional purpose. Check content completeness before visual polish. Follow Step 7 in the main skill and run `layout_lint.py`.

## C. Rule Library

### Instructional Loop

Use the full learning arc: **motivate, build understanding, observe a process, attempt actively, receive feedback, transfer to practice**. Short materials need not dedicate one slide to every stage, but omissions must be deliberate.

| Stage | Required slide content |
| --- | --- |
| Motivate | The capability gained or consequence of not learning, grounded in a real situation rather than a slogan |
| Build understanding | A repeatable definition, then boundaries, components, and counterexamples; new terms cannot appear only in captions |
| Observe a process | The progression of judgment, including critical branches, trade-offs, and common errors in one reading path |
| Attempt actively | Input, action, and completion criteria; label invented situations "Practice scenario" |
| Receive feedback | Why the answer is correct, where an error occurs, and how to self-check next time; make answer and question slides visibly distinct |
| Transfer | A checklist, template, or action reference tied to a real situation, not a slogan |

### Slide-Type Catalog

Every slide needs a title, primary display, support layer, action or check, and source. It should perform one main learning action.

| Slide type | Learning action | Required structure |
| --- | --- | --- |
| Learning map | Know the starting point and destination | Learning question and section sequence |
| **Section question** | Develop a specific blocking question | Driving question as the first focal point and a confusion anchor |
| Concept | State what it is and its boundary | One definition, boundary or components, and intuitive example or diagram |
| Method map | Know current position and next steps | Overall framework, current-position marker, and preview |
| Method | Know when to choose it and how to decide | Criteria, conditions, and decision path |
| Process | Know order and acceptance | Step sequence, action per step, and acceptance criteria |
| Demonstration | Observe judgment progressing | Input, intermediate judgments, trade-off rationale, conclusion, and error branch |
| Case and evidence | Learn a transferable judgment | Role label, facts, interpretation, transferable judgment, and source |
| Comparison or common error | Distinguish methods or states | Two methods on one skeleton, criteria, and frequent mistakes |
| Practice | Perform an action or choose | Task, input or scenario, answer area, and completion criteria; no answer on the same slide |
| Feedback | Correct an error and extract a principle | Reference method, rationale, error location, and future self-check |
| **Section summary** | Answer the driving question | Repeat the exact question, one section judgment, two to four supporting judgments, and transfer boundary; do not list all titles |
| Transfer | Know what to do after the deck | Checklist, template, reference card, resource links, and next step |

**When to open and close a section:**

| Condition | Section-question slide | Section-summary slide |
| --- | --- | --- |
| **Open when any apply** | Section has at least four slides; a driving question creates useful tension; or at least three new concepts are introduced | A section-question slide exists; a complex judgment spans at least three slides; or later slides repeatedly cite the conclusion |
| **Do not open when any apply** | Full deck has at most six slides; section has only one or two slides; or section is only a transfer checklist | The final slide title already states the conclusion; or the section is transitional only |

Section-question and section-summary slides must appear as a pair or both be omitted.

### Density

Aim for an appropriately full slide: the core object is visible immediately and support is easy to find.

- Use three content levels: question or conclusion title, primary display, then explanation, task, check, and source.
- Effective learning content must fill at least 60% of the main content area. Whitespace guides attention; it is not the product.
- Outside covers, section slides, and closings, do not repeat "one line plus a large empty area" across consecutive slides.
- At high density, strengthen grouping labels. At low density, add definitions, examples, or checks, not decoration.

Use flows for sequence, trees or nesting for hierarchy, parallel regions for comparison, one-way chains for causality, and rings only for real cycles. Each diagram expresses one main relationship. Remove decorative arrows and meaningless nodes.

### Visual Quality Floor

- **Grid and hierarchy:** Fix the main content area, title anchor, alignment axes, and page or source location before variants. Use one primary focal point per slide. Use Noto Serif CJK SC and Noto Sans CJK SC as the two-family typography system. Use 13-15 px body text and at least 4.5:1 contrast without shadow or outline patches.
- **Color:** Use a brand or school logo's verified primary color when available. Otherwise adapt to topic and audience. Use high-contrast light text on dark backgrounds and near-black text on light backgrounds. Never put small type on saturated color.
- **Components:** Once corner style, border, shadow, or pill style is selected, apply it consistently. Keep shadows, textures, gradients, and decorative icons only when they support hierarchy or context.
- **Images and charts:** State what to observe in every image and why it is present. Charts show relationships; annotations explain how to read them and what to do next. Retain units, periods, legends, and sources while removing unnecessary grids. Without reliable data, use an illustrative structure and never fabricate precise-looking values.

### User-Provided PPTX Template

Inspect rendered slides, extract concise transferable layout, tone, and graphic grammar, and preserve primary fonts, slide-sized backgrounds, brand marks, real photographs, original copy, proprietary colors, and patterns. Apply observations only to matching slide types. If no slide is directly reusable, build with this design system and follow `workflow/template-editing.md`.

## D. Reference Directions

These are design directions, not fixed palettes or templates. If none fits, define a new direction by first stating what it helps the learner accomplish.

### A. Classroom Teaching

#### A-1.1 Primary School and Below: MBE Style

- **Character:** Friendly, interesting, and low in cognitive load, with images. Prefer generated cutout cartoons to shape-built entities. Use real or realistic images for people, objects, equipment, and scenes rather than abstract shapes.
- **Typography:** Use Noto Sans CJK SC. Create a friendly tone through larger type, generous spacing, and rounded containers.
- **MBE rules:** Use consistent 3-5 px black outlines with round caps; rounded rectangles, labels, buttons, and containers with at least 12 px radii; MBE illustrations with outline, fill, and offset shadow blocks; consistent outline weight and palette; background removal is allowed for white-background photos; rounded text at 16 px or larger with highlighted keywords; centered symmetry or image-left/text-right layouts; imagery over 40%-60% of the page; at most three information points; generous whitespace.
- **Avoid:** Sharp corners, dark backgrounds, dense text, or restrained adult-course styling.
- **Reference palettes when the user gives none:**
  - Orange `#E2883E`, dark blue `#3D547A`, light blue `#6BBFEA`, bright yellow `#F7D752`.
  - Rose `#DC6872`, cream yellow `#FAE47A`, lavender `#7D7AB7`, light pink `#EBA59A`.
  - Mint `#62B4A5`, light brown `#C6A163`, lemon `#FAE452`, pale cyan `#A2D2D2`.
  - Blue `#4583BD`, gray-brown `#C2AE9F`, orange-red `#D77653`, light blue `#B7D6E9`.
  - Grass green `#60AB70`, egg yellow `#F8E653`, orange `#EA9B46`, light green `#AECC73`.
  - Coral `#DB714F`, mint `#6DBA9C`, cream yellow `#FCF08F`, pale orange `#EBA17E`.
  Use warm white `#FFFDF5` or white `#FFFFFF` as the base. Use each group's darker colors for outlines and titles and lighter colors for fills and background zones.

#### A-1.2 Primary School and Below: Hand-Drawn Doodle Style

- Use simple hand-drawn doodles, thick black outlines, flat 2D cartoons, and childlike scrapbook details. Add cartoons instead of abstract shapes.
- Use bright high-saturation contrasts with soft macaron colors.
- Add sparse corner stickers such as clouds, stars, flowers, simple figures, and speech bubbles without competing with text.
- Use rounded-card zones, modular layout, clear text boxes, and newsletter-like composition.
- Keep the mood relaxed, youthful, informal, and suitable for classwork or group reports rather than business use.

#### A-2 Middle and High School: Question-Led

- **Character:** Clear and logical, guiding the student through one thinking task per slide.
- Every title must be a question or judgment, such as "Why does the Pythagorean theorem hold?" A topic label such as "Pythagorean Theorem" is empty and must be rewritten.
- Start every section with a complete driving question and confusion anchor. Do not place the answer on the same slide.
- End each section with a judgment that stands alone, such as "Area can stay constant while perimeter changes."
- Arrange figures, formulas, and tables in reasoning order: condition, process, conclusion. Do not show only the conclusion diagram.
- Use a neutral light-gray or warm-white base and one subject color for questions and emphasis. Prefer square corners, with small rounded labels allowed. Add illustrations only when useful.
- Use Noto Serif CJK SC for humanities and Noto Sans CJK SC for science. Keep medium density and use more slides rather than compressing derivations.
- **Reference palettes:** science: deep indigo `#1A2E4B`, cool gray `#F0F2F5`, orange `#E8720C`; humanities: ink `#2B2B2B`, warm white `#FAF7F2`, ochre `#9C5C38`; biology or geography: deep green `#2F4A3B`, pale grass `#F3F7F0`, earthy yellow `#C8A44A`; government topics: warm white `rgb(245,240,235)`, burgundy, and charcoal.

#### A-3 University and Vocational Education: Professional Question-Led

- **Character:** Rigorous, verifiable, and academic, with higher density and required sources, boundaries, and counterexamples. Use Noto Serif CJK SC. Verify the institution's logo and primary color before using reference colors.
- Build driving questions with conditions and boundaries. Classify slide questions as definition, mechanism, or application.
- Cite every external fact, value, and quotation with source, author, and year. Label illustrative data explicitly.
- Medium-high density and multi-step demonstrations are allowed, but each slide still answers one question.
- Text handles definitions, boundaries, and decision grounds; graphics handle relationships, structure, and flow.
- Alternate dark section slides with light content slides. Use five type levels: title, body, citation, source, and caption. Fine-line tables and data charts can be primary displays.
- Use monospace for code and formulas, light code-block backgrounds, and right-aligned formula numbers.
- Avoid unobservable verbs such as "understand," "master," or "be familiar with," unsourced data, and slogan closings.
- **Reference palettes:** engineering or computing: deep indigo `#0D1326`, cool white `#F2F4F8`, bright blue `#2563EB`; social science or humanities: ink `#2B2B2B`, light tea `#EFEAE0`, ochre `#A08968`; medicine or life science: deep teal `#0D2825`, warm white `#F9F7F3`, accent `#C8B896`; government topics: warm white `rgb(245,240,235)`, burgundy, and charcoal.

### B. Role or System Infographic

Use color coding for roles or modules, nesting, sectors, or interlocking blocks for relationships, and action text adjacent to its module. Suitable for multi-role collaboration, public education, and system explanations.

### C. Steps or Operating Record

Keep progress visible, number steps clearly, provide explicit containers for photos, screenshots, and worksheets, and separate actions, risks, and checks. Suitable for procedures, compliance, safety, and vocational skills.

### D. Evidence or Data Editing

Make charts, tables, or screenshots the slide's main body. Put the learning question or conclusion in the title and annotate measurement definitions and observation points. Suitable for professional education, result interpretation, and before-and-after comparison.
