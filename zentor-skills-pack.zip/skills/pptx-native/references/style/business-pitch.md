# Business Pitch

**Route here for:** business plans, venture-capital pitches, franchise or partnership proposals, startup fundraising, brand proposals, product launches, brand launches, and keynote-style releases.

## Scenario Types

These are all external proposals or launches, but their goals and audiences differ. Select the type before applying its guidance.

| Dimension | **A: Persuasion** (business plan, VC, franchise, fundraising, proposal) | **B: Launch** (product launch, brand launch, keynote) |
|---|---|---|
| Goal and audience | Persuade investors, partners, or franchisees to commit resources. | Communicate vision and build resonance with users, media, or the public. |
| Emotional path | Concern, hope, confidence, action through reason. | Anticipation, surprise, identification, aspiration through emotion. |
| Content density | Medium to high, with dense data, examples, and comparisons. | Very low, with one idea per slide. |
| Primary slide forms | Structural diagrams, charts, comparison tables, and case studies. | Full-bleed images, oversized statements, and generous whitespace. |
| Competitive comparison and cases | Required and detailed. | Use sparingly; turn cases into user stories. |
| Generated imagery | Use on section and emotional slides. | A primary technique used on almost every slide. |

## Core Narrative

- **Type A, three acts:** problem, solution and advantages, then value. Every advantage needs data, a case, or a comparison. Recommended sequence: cover, industry context, focused problem, solution overview, advantage details, **competitive comparison**, **representative cases**, partnership value, call to action, close.
- **Type B, keynote structure:** hook, conflict, reveal, meaning. Use one idea per slide and create tension through pauses. Recommended sequence: manifesto cover, scene setting, conflict, **full-bleed product reveal**, one slide per core feature, use cases, vision, close.

## Narrative Principles

- Maintain one clear narrative thread and an emotional curve. Give the central claim visual privilege as the slide's most prominent statement.
- **Type A:** Support every claim with evidence. Use real data and provide a source or measurement definition.
- **Type B:** Use only one idea per slide and at most one line of body copy. Prefer an image and short statement to a list.

## Competitive Comparison Slides

**Required for Type A and optional for Type B.** If used in Type B, make it minimal.

- **Choose advantage dimensions first:** Select three to five areas with clear leadership, such as price, efficiency, technology, service, coverage, or delivery time.
- **Make comparisons concrete:** Give every item a quantifiable measure such as a number, percentage, duration, or coverage rate. Do not use unsupported words such as "better," "stronger," or "leading." Use real operating definitions and cite sources.
- **Visual forms:** Use side-by-side columns, feature check tables, radar charts, or scoring matrices. Highlight the user's offering with the primary color and show the industry average in neutral gray.

## Representative Case Slides

**Required and detailed for Type A. For Type B, use one large portrait and one sentence as a user story.**

- Use one case per slide and explain it fully. Do not create a logo wall.
- Arrange by importance: customer identity in one line with logo, industry, and scale; one-sentence customer problem; one or two sentences or a small flow diagram for the solution; **before-and-after outcome data as the primary large-number visual**; and an optional customer quote.
- Three case slides are a useful default. If only one strong case exists, turn it into a full section covering context, solution, and results.

## Voice-of-Customer Slides

This independent slide type concentrates authentic user feedback and adds credibility and warmth. It works for both types.

- **Tone:** Minimal, premium, restrained, and spacious. Focus on tactile speech bubbles and realistic portraits.
- **Portraits:** Generate naturally lit, realistic portraits without artificial plastic skin or cartoon styling. Crop circular avatars at about 10%-15% of slide height. Vary gender, age, and professional character. Use three to five portraits for Type A and one or two close-ups for Type B.
- **Bubbles:** Place each bubble beside its avatar with a thin outline or very pale fill. Never use saturated blue or green chat-app defaults. Point the tail toward the avatar. Keep copy under three lines. Add one line of 12 pt light-gray identity text below with name, role, and company.
- **Staggered composition:** For multiple quotes, vary avatar size, bubble width, and horizontal position. Alternate left and right, and vary text length. Use the primary color only for outlines, quotation marks, or highlighted words.
- **Avoid:** Phone UI screenshots, nine-cell avatar walls, or more than five quotes on one slide.

## Generated Background Guidance

Use generated backgrounds for emotional Type A slides, including covers, sections, manifestos, problems, and value. Make them a primary technique for Type B manifestos, reveals, and feature slides.

- **Style:** Premium and restrained, with cinematic photography or minimal abstraction. Type B can go further with one subject, extensive negative space, material close-ups, and dramatic lighting.
- **Tone:** Match the theme colors. Include "use #XXXXXX as the primary tone" or an equivalent same-hue description in the prompt.
- **Overlay:** For Type A, add a 40%-70% brand-color or black gradient overlay for title readability. Type B can keep the image clean and place oversized type over it.
- **Motif consistency:** Reuse one or two visual languages for all backgrounds. Do not change artistic style from slide to slide.

## SmartArt-Like Structures

Use primarily for Type A and rarely for Type B. Identify sequence, contrast, cycle, or causal relationships and show them as structural diagrams. Lines must stop at node edges and never cross text. Use plain text only as a fallback.

## Visual Requirements

- **Typography:** Separate display roles, such as titles, statements, and large numbers, from body roles. Create strong contrast through size, weight, and tracking. Pair Noto Serif CJK SC with Noto Sans CJK SC to establish hierarchy. **Type B should use oversized type and asymmetric staggered layouts.**
- **Slide rhythm:** Never use the same skeleton on two consecutive slides. Type A problem, advantage, comparison, case, and value slides require distinct structures. Type B must include pause slides with only a statement, image, or large number.
- **Layout:** Create a composed visual experience, not merely arranged text. Type B emphasizes generous whitespace and one focal point.
- **Decorative motifs:** Establish two to five repeating motifs across decoration, icons, and illustration to create an artistic signature.
- **Charts and tables:** Draw colors from the brand palette. Label only key data points. Separate table rows with thin horizontal lines, not thick borders or zebra stripes. Ensure multi-series legends remain distinguishable. **Type B should use charts sparingly and retain only the most important numbers.**
- **Quality discipline:** Use pixel-level alignment and refined letter spacing. Build quality through restrained typography, alignment, color blocks, and lines. Do not use defaults.
- **Contents:** Common for Type A and optional for Type B. Use primary-color numbering, 22 pt section titles, and one 12 pt light-gray description line. Left-align entries and separate sections with 0.5 pt light-gray rules. Use a balanced two-column layout for more than five sections.

## User Template References

When the user asks to reference a PPTX style or use it as a template, do not copy slides one by one:

1. **Inspect rendered output first.** Open sample screenshots and understand the actual visual design. Extracting XML text alone is insufficient.
2. **Extract transferable ideas:** layout techniques such as grid, palette, navigation, and evidence zones; tone such as restrained, approachable, rigorous, live-event, or institutional; and graphic grammar such as parallel modules, timelines, nesting, and framing.
3. **Do not change:** primary fonts, background images that match the PPT dimensions, brand marks, real-person photography, original copy, proprietary color values, or decorative patterns.
4. Apply each observation only to the corresponding slide type. Do not turn a local trait into a universal rule. If no slide can be reused directly, build with this design system.

## Color

- **First principle:** Learn the primary color from the user's brand logo. When a brand is named or a logo is supplied, find or inspect the logo, extract its primary color, and construct the palette around it. Distinguish the user's organization from the user's customer and prioritize the user's organization. Use an explicit visual-identity color directly. Let AI choose based on industry tone only when no brand color exists.
- **Tone:** Be bold, distinctive, and premium. Consider nonstandard colors such as wine red, deep ink green, rust orange, grape purple, antique gold, mist teal, or ochre. Avoid overused industry colors. Use one dramatic lead color, one or two restrained support colors, and a neutral base such as warm white, cream, ivory, charcoal, or ink black. Do not distribute many colors evenly.
- **Specify all five roles:** Give explicit hexadecimal values for the theme, supporting, background, title, and body colors. Leave no defaults.
- **Closing slide:** The final slide, whether a close, call to action, or thank-you, **must use a dark background**, such as deep black, deep ink green, deep wine red, deep blue-gray, or deep charcoal. Use the theme color as an accent to contrast with earlier light backgrounds.
- **Avoid:** blue-purple technology gradients, hospital blue and white, festive red and gold, real-estate gold-brown, generic green-leaf environmental palettes, and all-gray business styling.

## Prohibited

**General:**

- Do not use rounded rectangles or rectangular cards for hierarchy. Organize with lines, whitespace, and typographic contrast.
- Do not use equal-split compositions such as thirds, quarters, 2x2 matrices, or "three columns plus title plus conclusion."
- Do not use formulaic palettes listed above.
- Do not use cheap business illustrations such as suited handshakes, gear globes, or rising-arrow figures, or glossy artificial generated backgrounds.
- Do not repeat the same slide skeleton on consecutive slides.
- Do not retain any default typography, fonts, chart colors, or alignment.

**Type A:**

- Do not make an advantage claim without data, a case, or a comparison.
- Do not use vague, nonquantified adjectives in competitive comparisons.
- Do not make a case slide into a logo wall. Explain only one or two cases per slide.

**Type B:**

- Do not place multiple ideas on one slide except for a deliberate multi-point display.
- Do not let a generated background overpower the main title unless text-over-image is an intentional design technique.
