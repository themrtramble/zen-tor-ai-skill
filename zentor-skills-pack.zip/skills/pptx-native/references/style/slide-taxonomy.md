# Design-System Overview and Scenario Routing

**This is the entry point for selecting a design system.** Choose one design system for a presentation. It governs color, typography, whitespace, layout, and every other visual decision.

Use it in three steps:

1. **Follow the general rules.** They apply to all slides in the seven named scenarios together with the selected scenario document. User-provided templates, layout instructions, brand rules, colors, fonts, and style references take precedence.
2. **Identify the scenario.** Select one primary scenario from the user's request.
3. **Read the scenario document.** Apply its communication priorities and methods.

> **The selected design system is the only authority on card use. No other document can add another card rule.**
>
> - If one of the seven scenarios matches, **do not use cards**. Use lines, whitespace, and type-size contrast.
> - If no scenario matches, use the fallback design system in [`fallback.md`](fallback.md).
> - If the user supplies a template, brand rules, colors, fonts, style reference, or another explicit requirement, follow the user.

## Step 1: General Rules

> These rules govern the seven named scenarios. When using [`fallback.md`](fallback.md), follow the fallback document instead. The **Visual Quality Floor** applies to every design system, including fallback.

### Requirements

1. **Give every slide a clear reader task.** Before designing, determine what the reader must understand, believe, decide, or do.
2. **Create rhythm across slides.** Decide whether contents and section slides are useful. Some slides should be understood instantly, while others reward close reading.
3. **Combine charts and shapes flexibly.** When the current chart grammar cannot express a complex relationship, construct it with shapes. Do not use shape-built diagrams on cover, closing, or section-divider slides.
4. **Generate images judiciously.** Use the platform-provided `GenerateImage`. Do not overuse imagery. Place useful images from user attachments on appropriate slides. Covers support only high-quality images.
5. **Follow the user and topic.** User-specified templates, brand rules, colors, fonts, references, and required attachments take precedence.
6. **Cite sources.** Slides with external facts or data must show the source, date or period, and measurement definition. Use a visible report name and URL in `shape` text, not HTML or XML tags.
7. **Balance peer layouts.** Same-level modules arranged horizontally on one row must use equal widths by default. Align their top, bottom, or content-start baselines. Use unequal widths only when width intentionally communicates hierarchy.
8. **Use native tables for structured information.** Use OfficeCLI `table` or `chart` elements for comparisons, metric lists, parameters, dimensional breakdowns, and other structured information. Never place a Markdown table such as `| Field | Value |` on a slide.
9. **Make charts professional.** Pie and doughnut legends need visually distinct colors. They may combine the primary color with other colors or use opacity steps. This is the only case where a deck can use colors outside the primary and supporting palette.
10. **Separate text roles clearly.** If a number and adjacent text share the same font size and baseline, separate them with a space. Put visible separation between a lead-in label, including bold text, and its explanation through a space, appropriate colon, or line break.
11. **Treat the contents slide as quality-critical.** Avoid both stacks of small text and large unused areas. Distribute section modules across the page. Switch to a balanced two-column layout when one column cannot remain open and even. A section can pair a large title with a smaller description. Keep section numbers and names in separate text boxes.
12. **Prioritize the user's institutional color.** If the user identifies a school, company, or institution, search for its logo and use its primary color before a style-document recommendation.
13. **Use punctuation consistently.** Use full-width punctuation in CJK prose and half-width punctuation in English words, numbers, code, URLs, file paths, and technical identifiers. Do not mix punctuation systems within one context.

### Strictly Prohibited

- **Cross the evidence boundary:** Never invent data, quotations, customer cases, experiment results, or sources. Label missing material as a placeholder, assumption, or item to confirm.
- **Use formulaic AI styling:** Unless the user requests it, do not build hierarchy or alignment with cards, including rounded rectangles, rectangular cards, or cards with color strips. Use lines, whitespace, and type-size contrast. Do not pile red, purple, yellow, and green onto one slide. Do not place an accent line, strip, or block under a title; use whitespace or background color for hierarchy.
- **Use rainbow palettes or poor contrast:** Unless a skill-defined reference palette says otherwise, use no more than three colors on one slide. Maintain clear text-to-background contrast.
- **Interpret "bright" as rainbow:** A bright request still uses at most three coordinated colors.
- **Crowd contents slides:** Avoid stacked small text and large empty areas. Fill the page evenly and switch to two columns when necessary. Keep section numbers and titles in separate text boxes.
- **Overuse shapes:** Do not use abstract shapes on cover or section slides. Prefer high-quality images.
- **Abuse screenshots:** Use images from user attachments intact. Do not crop them. Adapt the layout to the image, not the image to the layout.

### Visual Quality Floor

These are objective defects that must be removed, not matters of taste. `layout_lint.py` covers structural overflow, box overlaps, and blank slides. Use screenshots to assess contrast, visual cropping, alignment, and spacing. Judge intentional overlap in screenshots rather than separating it automatically. See [validation-visual.md](../workflow/validation-visual.md).

1. **Text overflow or clipping, checked first:** Text must stay inside its box and within the slide canvas.
2. **Unintended overlap:** Text must not cover other text or important regions of an image.
3. **Contrast:** Do not place light-gray text on a light background or dark icons on a dark background. Text must separate clearly from the background.
4. **Margins and block spacing:** Keep content at least 0.5 inches, about 1.27 cm, from slide edges and blocks at least 0.3 inches, about 0.76 cm, apart. Full-bleed cover images are exempt.
5. **Uneven gaps:** Do not leave one side largely empty while crowding the other.
6. **Peer alignment:** Align top, bottom, and start positions of same-row columns and modules. See requirement 7 for equal widths.
7. **Footers and sources:** Keep footers, citations, and source lines clear of content above.
8. **Decoration under titles:** Do not place underlines, strips, or blocks beneath titles for separation or decoration. Use whitespace or background color. Preserve elements supplied by a user template.
9. **Narrow text boxes:** Prevent excessive wrapping or one-word or one-character lines caused by insufficient width.
10. **Images:** Do not stretch images. Do not crop attached images; scale them. Keep text off faces, product subjects, and logos.
11. **Residue and emptiness:** Remove placeholders such as lorem ipsum, TODO, and "click to edit," broken images, and blank slides.

### Using an Uploaded PPTX Template

When the user uploads a PPTX and asks to reference its style or use it as a template, do not reuse it mechanically slide by slide. Apply this process before routing to the scenario design system:

1. **Inspect rendered output, not only text.** Open the sample and review screenshots. Text extraction alone does not reveal the template's design.
2. **Record a concise set of transferable traits:**
   - **Layout techniques:** grid structure, color rules, step navigation, evidence zones, and related structures.
   - **Tone:** restrained, approachable, rigorous, live-event, institutional, or another clear character.
   - **Graphic grammar:** parallel modules, timeline paths, nested hierarchy, framing devices, and similar forms.
3. **Preserve:** primary fonts, slide-sized background images, built-in brand marks, real people and photographs, original copy, proprietary colors, and decorative patterns. Recompose around them as needed.
4. Apply each trait to the corresponding slide type. Do not make a local observation a universal rule.
5. If no slide is directly reusable, build it with the appropriate design system.

## Step 2: Identify the Scenario

Analyze the audience and reader task, select one primary scenario, and read its style document. Add one supporting scenario only when necessary, and keep the primary scenario authoritative.

| Scenario | Typical request | Reader task | Style document |
|---|---|---|---|
| Strategy and decision analysis | Consulting, finance, industry research, strategy, market opportunity, business analysis, investment analysis | Compare options, form a judgment, support a decision | [`strategy-and-analysis.md`](strategy-and-analysis.md) |
| Business pitch | Marketing or sales proposal, fundraising pitch, franchise or investment proposal, product proposal, business plan | Understand value, trust the solution, take action | [`business-pitch.md`](business-pitch.md) |
| Management review | Work report, project retrospective, quarterly review, OKR, management brief, professional training | Understand status, expose problems, confirm action | [`business-review.md`](business-review.md) |
| Academic research | Graduate research, thesis defense, research project, proposal, interim review, final report | Evaluate the question, method, evidence, and contribution | [`academic-research.md`](academic-research.md) |
| Education and public knowledge | K-12 courseware, teaching presentation, patient education, professional explainer | Understand, remember, apply correctly, or act | [`learning-and-training.md`](learning-and-training.md) |
| Technology and engineering | Engineering plan, architecture review, R&D report, AI, data, operations, security | Understand structure, dependencies, metrics, and trade-offs | [`technical-presentation.md`](technical-presentation.md) |
| Brand and creative storytelling | Brand story, design proposal, portfolio, cultural event, person profile, film or art introduction | Build recognition, create memory, form affinity | [`brand-storytelling.md`](brand-storytelling.md) |

**Fallback:** If none of these scenarios clearly fits, do not force the nearest match. Use [`fallback.md`](fallback.md), the high-density visual-content card system.

## Font System

Use Simplified Chinese by default for Chinese content unless the user explicitly requests Traditional Chinese, the context is Hong Kong, Macau, or Taiwan, or the source material is already Traditional Chinese. Do not convert scripts merely for stylistic effect because missing glyphs and fallback fonts can cause inconsistent rendering.

Use only the font families in this table for newly created content. The Sandbox base image installs these families through Ubuntu 22.04 `fonts-noto-core`, `fonts-noto-cjk`, and `fonts-noto-color-emoji`. Preserve fonts from a user-provided template, but expect substitution when the Sandbox does not contain those fonts.

| Font | Language | Type | Character | Suitable scenarios |
|---|---|---|---|---|
| Noto Sans | Latin, Greek, Cyrillic | Sans serif | Neutral and highly readable | English, Portuguese, French, Spanish, Russian, German |
| Noto Serif | Latin, Greek, Cyrillic | Serif | Formal stroke contrast | Academic, cultural, and formal slides |
| Noto Sans CJK SC | Simplified Chinese | Sans serif | Structured and highly readable on screens | General, management, technical |
| Noto Serif CJK SC | Simplified Chinese | Serif | Formal stroke contrast | Academic, cultural, formal |
| Noto Sans Mono CJK SC | Simplified Chinese | Monospace | Stable alignment for code and identifiers | Technical, tables, code |
| Noto Sans CJK TC | Traditional Chinese | Sans serif | Structured and highly readable on screens | General, management, technical |
| Noto Serif CJK TC | Traditional Chinese | Serif | Formal stroke contrast | Academic, cultural, formal |
| Noto Sans Mono CJK TC | Traditional Chinese | Monospace | Stable alignment for code and identifiers | Technical, tables, code |
| Noto Sans CJK JP | Japanese | Sans serif | Structured and highly readable on screens | General Japanese slides |
| Noto Serif CJK JP | Japanese | Serif | Formal stroke contrast | Academic and cultural Japanese slides |
| Noto Sans Mono CJK JP | Japanese | Monospace | Stable alignment for code and identifiers | Technical Japanese slides |
| Noto Sans CJK KR | Korean | Sans serif | Structured and highly readable on screens | General Korean slides |
| Noto Serif CJK KR | Korean | Serif | Formal stroke contrast | Academic and cultural Korean slides |
| Noto Sans Mono CJK KR | Korean | Monospace | Stable alignment for code and identifiers | Technical Korean slides |
| Noto Color Emoji | Emoji | Color symbol | Broad emoji coverage | Inline symbols when the target viewer supports color emoji |
