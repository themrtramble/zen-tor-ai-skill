# Strategy and Decision Analysis

**Route here for:** industry research, consulting reports, strategic analysis, decision-support documents, competitive analysis, market analysis, investment or financial analysis, and other data-intensive content. Treat the deck as reading material unless the user explicitly says it is for a live presentation.

**User-uploaded PPT rule:** If an attachment template has no directly reusable slide, build with this design system and follow `workflow/template-editing.md`.

## Content Density

1. Unless intended for live delivery, design for reading and target the quality of leading research and consulting reports.
2. Give every slide real informational depth. The core conclusion must be visible immediately, while a complete reading can take about five minutes.
3. Expand the argument from conclusion to evidence. The title states the judgment. The slide supports it with several independently valid subclaims, each paired with one verifiable piece of evidence.
4. Prefer a declarative sentence for content-slide titles, such as "Core market share fell from 34% to 19% in three years because channels and pricing weakened, not demand." Adjust when the content requires another form.

## Data and Charts

1. Data forms the argument's backbone. Research sufficient real data, choose an appropriate chart, cite every source, and never invent values.
2. Include axes, units, legends, sources, and measurement definitions so each chart can be understood without body copy.
3. Mark key inflection points and values and explain their meaning. Beside every chart, state the claim it supports, visible findings, decision implications, data source, and limitations.
4. When information has sequence, contrast, cycle, or causality, prefer a structural diagram to prose.
5. Combine shapes to create complex charts or SmartArt-like structures when useful. Lines must stop at node edges and never cross text.
6. Use one hue family and its tonal steps for every chart in the deck. Do not introduce a second hue family. For multi-category charts such as pies, keep legend colors distinguishable within that family. Rebuild software defaults: remove default axes, gridlines, legend boxes, rainbow colors, thick black table borders, 3D columns, gradients, and shadows.

## Color

**Brand color first:** Use a supplied visual-identity primary color directly. If the user names a brand or supplies a logo, find and inspect the logo, extract its primary color, and build the full palette from its opacity steps. The cover can include the brand logo.

**Without a brand color:** Choose a premium, highly professional, restrained palette that fits the topic. Government or grand institutional narratives can use burgundy, deep wine red, or ochre. Other topics can use an unexpected but appropriate sophisticated color. Once selected, use **one primary color throughout the deck** for all structural expression.

**Tonal hierarchy:** Use the primary color at 15%, 30%, and 60% opacity for chart series, table headers, and background blocks. Do not exceed three steps.

**Neutral grays:** Divider `#D8D8D8`; supporting text `#767676`; light background block `#F4F4F4`.

**Accent:** Use one low-saturation contrasting color, such as warm red `#B84C3A` or amber `#C8861A`, only for a single-point highlight such as a maximum, critical gap, or risk. Use it at most three times in the deck and never as decoration.

**Background:** Use white `#FFFFFF` on all content slides. Do not use colored or gradient content-slide backgrounds. If the cover includes a brand logo, keep a white background.

## Visual Specification

- **Color framework:** Use the primary color for structural elements: title emphasis, table headers, active section navigation, main chart series, and number markers. Use grayscale for everything else. Never add a second primary color to one slide.
- **Titles:** Make every main title a complete judgment. Keep one title format across the deck, such as kicker, main title, then subtitle. Use bold serif titles and sans-serif body text as two distinct roles with consistent hierarchy.
- **Page framework:** Keep section navigation visible, highlighting the current section. Distinguish sections by position, not color switching. Fix a source line and slide number in the footer. Keep element coordinates consistent across slides.
- **Density rhythm:** Make content slides dense with charts, tables, and structural diagrams; text supports evidence. Use whitespace on covers, section dividers, and conclusion slides as breathing room.
- **Information zones:** Put conclusions in the title, evidence in central charts or tables, interpretation in adjacent annotations or sidebars, sources and definitions in the footer, and action recommendations only on closing slides.
- **Charts:** Assign every series a primary-color tone or gray. Remove vertical gridlines and retain at most very faint horizontal lines. Label only key points and endpoints. Distinguish actual and forecast values with solid versus dashed lines or hatching. Place source and measurement notes directly below each chart.
- **Chart annotations:** Show key totals as large numbers. Annotate inflection points, gaps, and growth rates with arrows or callouts. Place ratings such as Harvey balls or badges directly in the chart area instead of body paragraphs.
- **Tables:** Use dark headers with white text and very thin horizontal separators. Do not use vertical lines or thick borders. Right-align numbers and center text. Bold entity names in the first column. Add an interpretation panel beside large tables.
- **Alignment:** Align all elements to common left edges and invisible columns. Divide areas only with hairlines. Emphasize with a short primary-color rule or thick vertical rule, never a heavy frame. Use square-corner panels without shadows; only small labels may use rounded corners.
- **Cleanliness:** No shadows, gradients, textures, glow, or default colors. Create quality through whitespace, alignment, a single hue scale, and disciplined line work.
- **Contents:** Use the structure of a leading consulting report. Maintain both premium quality and clear navigation.

## Prohibited

- Rounded rectangles or rectangular cards for hierarchy and alignment. Use lines, whitespace, and type-size contrast.
- One basic chart occupying half or more of the slide width.
- Circular image crops, or any crop that removes image information.
- Equal-split compositions such as thirds, quarters, 2x2 grids, or the formulaic "three columns plus title plus conclusion."
- Any software default. Explicitly set colors, alignment, and chart styles.
- Rainbow or multi-hue charts. Use only primary-color tones plus gray.
